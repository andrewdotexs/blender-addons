"""Sketch CAD — sketch 2D parametrici con vincoli, stile CAD.

Punto di ingresso dell'extension: registra/deregistra i sottomoduli.
La logica geometrica vive in core/ (Python puro, niente bpy);
gli strati Blender (props, ops, ui, overlay) si registrano qui.
"""

from . import ops, overlay, props, ui

_modules = (
    props,    # per primo: ops e ui dipendono da Object.sketch_cad
    ops,
    ui,
    overlay,
)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
