"""Core geometrico di Sketch CAD — Python puro, nessuna dipendenza da bpy.

Tutto ciò che sta qui dentro è testabile con pytest senza aprire Blender.
"""
