"""Layout geometrico delle quote (dimensioni) — Python puro.

Produce la geometria 2D nel piano dello sketch: segmenti per le linee di
quota (estensioni, linea di misura, tacchette a 45°, archi) e posizione
del testo. Il rendering (GPU/blf) e la proiezione a schermo stanno nello
strato Blender.
"""

import math
from dataclasses import dataclass

from . import geom
from .constraints import ANGLE, DISTANCE, RADIUS

Vec2 = tuple[float, float]


@dataclass
class DimLayout:
    segments: list[tuple[Vec2, Vec2]]  # coppie (inizio, fine) nel piano sketch
    text_pos: Vec2
    text_dir: Vec2 | None  # direzione di lettura del testo; None = orizzontale
    text: str


def layout_linear(a: Vec2, b: Vec2, value: float, offset: float = 0.3) -> DimLayout | None:
    """Quota lineare classica: estensioni, linea di misura, tacchette a 45°."""
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    length = math.hypot(dx, dy)
    if length < 1e-12 or abs(offset) < 1e-12:
        return None
    ux, uy = dx / length, dy / length      # direzione della linea quotata
    nx, ny = -uy, ux                       # normale unitaria (sinistra)
    sign = 1.0 if offset >= 0 else -1.0
    gap = 0.12 * abs(offset)               # stacco delle estensioni dall'entità
    over = 0.15 * abs(offset)              # sporgenza oltre la linea di misura
    tick = 0.10 * abs(offset)              # mezza lunghezza delle tacchette

    dim_a = (ax + nx * offset, ay + ny * offset)
    dim_b = (bx + nx * offset, by + ny * offset)
    far = offset + over * sign
    ext_a = ((ax + nx * gap * sign, ay + ny * gap * sign),
             (ax + nx * far, ay + ny * far))
    ext_b = ((bx + nx * gap * sign, by + ny * gap * sign),
             (bx + nx * far, by + ny * far))

    # tacchette a 45° rispetto alla linea di misura
    tdx, tdy = ux + nx * sign, uy + ny * sign
    tnorm = math.hypot(tdx, tdy)
    tdx, tdy = tdx / tnorm * tick, tdy / tnorm * tick
    tick_a = ((dim_a[0] - tdx, dim_a[1] - tdy), (dim_a[0] + tdx, dim_a[1] + tdy))
    tick_b = ((dim_b[0] - tdx, dim_b[1] - tdy), (dim_b[0] + tdx, dim_b[1] + tdy))

    text_pos = ((dim_a[0] + dim_b[0]) / 2, (dim_a[1] + dim_b[1]) / 2)
    return DimLayout(
        [ext_a, ext_b, (dim_a, dim_b), tick_a, tick_b],
        text_pos, (ux, uy), f"{value:.2f}",
    )


def _ray_from_vertex(vertex: Vec2, a: Vec2, b: Vec2):
    """Direzione unitaria dal vertice verso la linea (a, b) e relativa distanza."""
    mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    rx, ry = mid[0] - vertex[0], mid[1] - vertex[1]
    dist = math.hypot(rx, ry)
    if dist < 1e-9:
        # midpoint coincidente col vertice: usa l'endpoint più lontano
        far = max((a, b), key=lambda p: math.hypot(p[0] - vertex[0], p[1] - vertex[1]))
        rx, ry = far[0] - vertex[0], far[1] - vertex[1]
        dist = math.hypot(rx, ry)
        if dist < 1e-9:
            return None
    return (rx / dist, ry / dist), dist


def layout_angular(a1: Vec2, b1: Vec2, a2: Vec2, b2: Vec2,
                   value_deg: float, radius_factor: float = 0.35) -> DimLayout | None:
    """Quota angolare: arco al vertice (intersezione delle rette) + testo.

    None se le rette sono parallele o degeneri.
    """
    d1x, d1y = b1[0] - a1[0], b1[1] - a1[1]
    d2x, d2y = b2[0] - a2[0], b2[1] - a2[1]
    det = d1x * d2y - d1y * d2x
    if abs(det) < 1e-9:
        return None
    t = ((a2[0] - a1[0]) * d2y - (a2[1] - a1[1]) * d2x) / det
    vertex = (a1[0] + d1x * t, a1[1] + d1y * t)

    ray1 = _ray_from_vertex(vertex, a1, b1)
    ray2 = _ray_from_vertex(vertex, a2, b2)
    if ray1 is None or ray2 is None:
        return None
    (r1, dist1), (r2, dist2) = ray1, ray2
    radius = radius_factor * min(dist1, dist2)
    if radius < 1e-9:
        return None

    theta1 = math.atan2(r1[1], r1[0])
    theta2 = math.atan2(r2[1], r2[0])
    sweep = (theta2 - theta1) % (2 * math.pi)
    if sweep > math.pi:
        sweep -= 2 * math.pi

    steps = max(8, int(24 * abs(sweep) / math.pi))
    arc = [
        (vertex[0] + radius * math.cos(theta1 + sweep * i / steps),
         vertex[1] + radius * math.sin(theta1 + sweep * i / steps))
        for i in range(steps + 1)
    ]
    segments = list(zip(arc, arc[1:]))

    mid_angle = theta1 + sweep / 2
    text_pos = (vertex[0] + radius * 1.3 * math.cos(mid_angle),
                vertex[1] + radius * 1.3 * math.sin(mid_angle))
    return DimLayout(segments, text_pos, None, f"{value_deg:.1f}°")


def layout_radial(center: Vec2, radius: float, value: float,
                  direction_rad: float = math.radians(45)) -> DimLayout | None:
    """Quota raggio: segmento dal centro oltre il bordo + testo "R…"."""
    if radius < 1e-9:
        return None
    dx, dy = math.cos(direction_rad), math.sin(direction_rad)
    end = (center[0] + dx * radius * 1.35, center[1] + dy * radius * 1.35)
    text_pos = (center[0] + dx * radius * 1.6, center[1] + dy * radius * 1.6)
    return DimLayout([(center, end)], text_pos, None, f"R{value:.2f}")


def iter_layouts(model) -> list[tuple[int, DimLayout]]:
    """Layout delle quote per tutti i vincoli DISTANCE e ANGLE del modello."""
    result = []
    for c in model.constraints.values():
        layout = None
        if c.type == DISTANCE:
            line = model.lines.get(c.a)
            if line is None:
                continue
            pa, pb = model.points[line.a], model.points[line.b]
            layout = layout_linear((pa.u, pa.v), (pb.u, pb.v), c.value, c.offset)
        elif c.type == ANGLE:
            l1, l2 = model.lines.get(c.a), model.lines.get(c.b)
            if l1 is None or l2 is None:
                continue
            p1a, p1b = model.points[l1.a], model.points[l1.b]
            p2a, p2b = model.points[l2.a], model.points[l2.b]
            layout = layout_angular(
                (p1a.u, p1a.v), (p1b.u, p1b.v),
                (p2a.u, p2a.v), (p2b.u, p2b.v), c.value)
            if layout is None:
                # linee parallele: niente arco, solo testo accanto alla prima linea
                mid = ((p1a.u + p1b.u) / 2, (p1a.v + p1b.v) / 2)
                layout = DimLayout([], mid, None, f"{c.value:.1f}°")
        elif c.type == RADIUS:
            circle = model.circles.get(c.a)
            if circle is not None:
                ctr = model.points[circle.center]
                layout = layout_radial((ctr.u, ctr.v), circle.radius, c.value)
            else:
                arc = model.arcs.get(c.a)
                if arc is None:
                    continue
                ctr = model.points[arc.center]
                start = model.points[arc.start]
                end = model.points[arc.end]
                radius = math.hypot(start.u - ctr.u, start.v - ctr.v)
                # direzione: bisettrice dell'arco
                t1 = math.atan2(start.v - ctr.v, start.u - ctr.u)
                sweep = geom.arc_sweep((ctr.u, ctr.v), (start.u, start.v),
                                       (end.u, end.v))
                layout = layout_radial((ctr.u, ctr.v), radius, c.value,
                                       t1 + sweep / 2)
        if layout is not None:
            result.append((c.id, layout))
    return result
