"""Operatori di Sketch CAD."""

from . import constrain, dimension, draw, edit, sketch, solidify

_modules = (
    sketch,
    draw,
    edit,
    constrain,
    dimension,
    solidify,
)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
