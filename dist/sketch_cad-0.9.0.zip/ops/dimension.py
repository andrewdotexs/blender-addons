"""Editing interattivo delle quote (click sul testo → dialog del valore)."""

import math

import bpy

from .. import convert, pick, props
from ..core import constraints as C
from ..core import solver


class SKETCHCAD_OT_edit_dimension(bpy.types.Operator):
    bl_idname = "sketch_cad.edit_dimension"
    bl_label = "Modifica quota"
    bl_description = "Click sul testo di una quota (distanza o angolo) per cambiarne il valore"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.sketch_cad.is_sketch
                and solver.available())

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set(
            "Click sul testo di una quota | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                model = props.load_model(self.obj)
                cid = pick.dimension_under_mouse(context, event, self.obj, model)
                if cid is None:
                    return {'RUNNING_MODAL'}
                self._finish(context)
                bpy.ops.sketch_cad.set_dimension_value(
                    'INVOKE_DEFAULT', constraint_id=cid)
                return {'FINISHED'}
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                self._finish(context)
                return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _finish(self, context):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()


class SKETCHCAD_OT_set_dimension_value(bpy.types.Operator):
    bl_idname = "sketch_cad.set_dimension_value"
    bl_label = "Valore quota"
    bl_description = "Imposta il valore di una quota e risolve lo sketch"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    constraint_id: bpy.props.IntProperty(options={'HIDDEN'})
    distance: bpy.props.FloatProperty(name="Distanza", min=0.0, subtype='DISTANCE')
    angle: bpy.props.FloatProperty(name="Angolo", subtype='ANGLE')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        model = props.load_model(context.active_object)
        c = model.constraints.get(self.constraint_id)
        if c is None or c.type not in (C.DISTANCE, C.ANGLE, C.RADIUS):
            return {'CANCELLED'}
        self._is_angle = c.type == C.ANGLE
        if self._is_angle:
            self.angle = math.radians(c.value)
        else:
            self.distance = c.value
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "angle" if self._is_angle else "distance")

    def execute(self, context):
        obj = context.active_object
        model = props.load_model(obj)
        c = model.constraints.get(self.constraint_id)
        if c is None or c.type not in (C.DISTANCE, C.ANGLE, C.RADIUS):
            self.report({'WARNING'}, "Quota non trovata")
            return {'CANCELLED'}
        old_value = c.value
        c.value = math.degrees(self.angle) if c.type == C.ANGLE else self.distance
        props.save_model(model, obj)

        result = convert.resolve_and_update(obj)
        if not result.ok:
            c.value = old_value
            props.save_model(model, obj)
            self.report({'ERROR'}, f"Valore rifiutato: {result.message}")
            return {'CANCELLED'}
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        self.report({'INFO'}, f"{C.LABELS[c.type]} aggiornato")
        return {'FINISHED'}


class SKETCHCAD_OT_move_dimension(bpy.types.Operator):
    bl_idname = "sketch_cad.move_dimension"
    bl_label = "Sposta quota"
    bl_description = (
        "Trascina il testo di una quota lineare per spostare la linea di "
        "misura dall'altra parte o più lontano"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        self.dragging_cid = None
        self.initial_offset = 0.0
        self.moved = False
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('SCROLL_XY')
        context.workspace.status_text_set(
            "Click su una quota lineare e trascina | Rilascia: conferma | Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE' and self.dragging_cid is not None:
            target = pick.mouse_to_plane(context, event, self.obj)
            if target is not None:
                self._drag_to(context, target)
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS' and self.dragging_cid is None:
                model = props.load_model(self.obj)
                cid = pick.dimension_under_mouse(
                    context, event, self.obj, model, types={C.DISTANCE})
                if cid is not None:
                    self.dragging_cid = cid
                    self.initial_offset = model.constraints[cid].offset
                return {'RUNNING_MODAL'}
            if event.value == 'RELEASE' and self.dragging_cid is not None:
                return self._finish(context, restore=False)

        if event.value == 'PRESS' and event.type in {'RIGHTMOUSE', 'ESC'}:
            return self._finish(context, restore=self.moved)

        return {'RUNNING_MODAL'}

    def _drag_to(self, context, target):
        model = props.load_model(self.obj)
        c = model.constraints.get(self.dragging_cid)
        if c is None:
            return
        line = model.lines.get(c.a)
        if line is None:
            return
        pa = model.points[line.a]
        pb = model.points[line.b]
        dx, dy = pb.u - pa.u, pb.v - pa.v
        length = math.hypot(dx, dy)
        if length < 1e-12:
            return
        # offset = proiezione del mouse sulla normale della linea (con segno)
        nx, ny = -dy / length, dx / length
        offset = (target[0] - pa.u) * nx + (target[1] - pa.v) * ny
        if abs(offset) < 0.05:
            offset = 0.05 if offset >= 0 else -0.05  # mai sopra l'entità
        c.offset = offset
        props.save_model(model, self.obj)
        self.moved = True
        context.area.tag_redraw()

    def _finish(self, context, *, restore):
        if restore and self.dragging_cid is not None:
            model = props.load_model(self.obj)
            c = model.constraints.get(self.dragging_cid)
            if c is not None:
                c.offset = self.initial_offset
                props.save_model(model, self.obj)
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.moved and not restore:
            return {'FINISHED'}
        return {'CANCELLED'}


_classes = (
    SKETCHCAD_OT_edit_dimension,
    SKETCHCAD_OT_set_dimension_value,
    SKETCHCAD_OT_move_dimension,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
