"""Dal profilo 2D al solido 3D."""

import bpy

from .. import convert


class SKETCHCAD_OT_extrude(bpy.types.Operator):
    bl_idname = "sketch_cad.extrude"
    bl_label = "Estrudi profilo"
    bl_description = (
        "Genera il solido estrudendo i profili chiusi dello sketch "
        "(parametrico: la profondità resta modificabile)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        n_profiles = convert.rebuild_profile_mesh(obj)
        if n_profiles == 0:
            self.report({'WARNING'}, "Nessun profilo chiuso nello sketch")
            return {'CANCELLED'}
        convert.ensure_extrude_modifier(obj)
        self.report({'INFO'}, f"Estrusi {n_profiles} profili")
        return {'FINISHED'}


class _BooleanBase(bpy.types.Operator):
    """Aggancia il solido estruso dello sketch alla mesh bersaglio.

    Il bersaglio riceve un modificatore Boolean che punta allo sketch:
    tutta la catena resta parametrica (quote → estrusione → booleana).
    """

    operation: str    # 'DIFFERENCE' | 'UNION'
    depth_sign: float  # -1 = dentro la mesh (cut), +1 = fuori (join)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        target = obj.sketch_cad.target_object
        if target is None or target.type != 'MESH':
            self.report({'ERROR'},
                        "Sketch non agganciato a una mesh: crealo con Sketch su faccia")
            return {'CANCELLED'}
        if convert.rebuild_profile_mesh(obj) == 0:
            self.report({'WARNING'}, "Nessun profilo chiuso nello sketch")
            return {'CANCELLED'}

        mod = convert.ensure_extrude_modifier(obj)
        identifier = convert.depth_prop_identifier(mod.node_group)
        if identifier is not None:
            current = mod.get(identifier, 0.2) or 0.2
            mod[identifier] = self.depth_sign * abs(current)
            obj.update_tag()

        name = f"SketchCAD Boolean {obj.name}"
        bool_mod = target.modifiers.get(name)
        if bool_mod is None or bool_mod.type != 'BOOLEAN':
            bool_mod = target.modifiers.new(name, 'BOOLEAN')
        bool_mod.operation = self.operation
        bool_mod.object = obj

        # lo sketch resta visibile come riferimento, non come solido
        obj.display_type = 'WIRE'
        obj.hide_render = True
        self.report({'INFO'}, f"{self.bl_label} su {target.name}")
        return {'FINISHED'}


class SKETCHCAD_OT_boolean_cut(_BooleanBase):
    bl_idname = "sketch_cad.boolean_cut"
    bl_label = "Taglia dal bersaglio"
    bl_description = (
        "Sottrae il solido estruso dalla mesh su cui è stato creato lo "
        "sketch (l'estrusione va verso l'interno: profondità negativa)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    operation = 'DIFFERENCE'
    depth_sign = -1.0


class SKETCHCAD_OT_boolean_join(_BooleanBase):
    bl_idname = "sketch_cad.boolean_join"
    bl_label = "Unisci al bersaglio"
    bl_description = (
        "Unisce il solido estruso alla mesh su cui è stato creato lo "
        "sketch (l'estrusione va verso l'esterno)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    operation = 'UNION'
    depth_sign = 1.0


_classes = (
    SKETCHCAD_OT_extrude,
    SKETCHCAD_OT_boolean_cut,
    SKETCHCAD_OT_boolean_join,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
