"""Operatori per aggiungere e rimuovere vincoli (pick di una linea in viewport)."""

import math

import bpy

from .. import convert, pick, props
from ..core import constraints as C
from ..core import solver


class _PickLineConstraintBase(bpy.types.Operator):
    """Modale comune: click su una linea → applica il vincolo → re-solve."""

    constraint_type: str  # nelle sottoclassi

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.sketch_cad.is_sketch
                and solver.available())

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        label = C.LABELS[self.constraint_type]
        context.workspace.status_text_set(
            f"{label}: click su una linea | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                model = props.load_model(self.obj)
                line_id = pick.line_under_mouse(context, event, self.obj, model)
                if line_id is None:
                    return {'RUNNING_MODAL'}  # click a vuoto: riprova
                return self._apply(context, model, line_id)
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish(context, {'CANCELLED'})
        return {'RUNNING_MODAL'}

    def _apply(self, context, model, line_id):
        value = 0.0
        if self.constraint_type == C.DISTANCE:
            line = model.lines[line_id]
            pa, pb = model.points[line.a], model.points[line.b]
            value = math.hypot(pb.u - pa.u, pb.v - pa.v)

        cid = model.add_constraint(self.constraint_type, line_id, value=value)
        props.save_model(model, self.obj)
        result = convert.resolve_and_update(self.obj)
        if not result.ok:
            # rollback: il vincolo renderebbe lo sketch irrisolvibile
            model.remove_constraint(cid)
            props.save_model(model, self.obj)
            self.report({'ERROR'}, f"Vincolo rifiutato: {result.message}")
            return self._finish(context, {'CANCELLED'})

        label = C.LABELS[self.constraint_type]
        self.report({'INFO'}, f"{label} applicato (gradi di libertà: {result.dof})")
        return self._finish(context, {'FINISHED'})

    def _finish(self, context, status):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        return status


class SKETCHCAD_OT_constrain_horizontal(_PickLineConstraintBase):
    bl_idname = "sketch_cad.constrain_horizontal"
    bl_label = "Vincolo orizzontale"
    bl_description = "Rende orizzontale una linea dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.HORIZONTAL


class SKETCHCAD_OT_constrain_vertical(_PickLineConstraintBase):
    bl_idname = "sketch_cad.constrain_vertical"
    bl_label = "Vincolo verticale"
    bl_description = "Rende verticale una linea dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.VERTICAL


class SKETCHCAD_OT_constrain_distance(_PickLineConstraintBase):
    bl_idname = "sketch_cad.constrain_distance"
    bl_label = "Vincolo distanza"
    bl_description = (
        "Vincola la lunghezza di una linea (parte dal valore attuale, "
        "modificabile poi dal pannello)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.DISTANCE


def _current_angle_deg(model, l1_id, l2_id) -> float:
    """Angolo corrente tra i vettori di due linee, in gradi [0, 180]."""
    l1, l2 = model.lines[l1_id], model.lines[l2_id]
    a1, b1 = model.points[l1.a], model.points[l1.b]
    a2, b2 = model.points[l2.a], model.points[l2.b]
    v1 = (b1.u - a1.u, b1.v - a1.v)
    v2 = (b2.u - a2.u, b2.v - a2.v)
    dot = v1[0] * v2[0] + v1[1] * v2[1]
    cross = v1[0] * v2[1] - v1[1] * v2[0]
    return abs(math.degrees(math.atan2(cross, dot)))


class _PickTwoLinesConstraintBase(bpy.types.Operator):
    """Modale comune: click su due linee → applica il vincolo → re-solve.

    La prima linea cliccata viene evidenziata usando la selezione.
    """

    constraint_type: str  # nelle sottoclassi

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.sketch_cad.is_sketch
                and solver.available())

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        self.first_line = None
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        label = C.LABELS[self.constraint_type]
        context.workspace.status_text_set(
            f"{label}: click sulla prima linea | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                return self._click(context, event)
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish(context, {'CANCELLED'})
        return {'RUNNING_MODAL'}

    def _click(self, context, event):
        model = props.load_model(self.obj)
        line_id = pick.line_under_mouse(context, event, self.obj, model)
        if line_id is None or line_id == self.first_line:
            return {'RUNNING_MODAL'}

        if self.first_line is None:
            self.first_line = line_id
            model.selection = {line_id}  # evidenzia la prima scelta
            props.save_model(model, self.obj)
            label = C.LABELS[self.constraint_type]
            context.workspace.status_text_set(
                f"{label}: click sulla seconda linea | Click dx / Esc: annulla")
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        value = 0.0
        if self.constraint_type == C.ANGLE:
            value = _current_angle_deg(model, self.first_line, line_id)
        cid = model.add_constraint(
            self.constraint_type, self.first_line, line_id, value=value)
        model.selection.clear()
        props.save_model(model, self.obj)

        result = convert.resolve_and_update(self.obj)
        if not result.ok:
            model.remove_constraint(cid)
            props.save_model(model, self.obj)
            self.report({'ERROR'}, f"Vincolo rifiutato: {result.message}")
            return self._finish(context, {'CANCELLED'})

        label = C.LABELS[self.constraint_type]
        self.report({'INFO'}, f"{label} applicato (gradi di libertà: {result.dof})")
        return self._finish(context, {'FINISHED'})

    def _finish(self, context, status):
        if status == {'CANCELLED'} and self.first_line is not None:
            model = props.load_model(self.obj)
            model.selection.discard(self.first_line)
            props.save_model(model, self.obj)
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        return status


class SKETCHCAD_OT_constrain_parallel(_PickTwoLinesConstraintBase):
    bl_idname = "sketch_cad.constrain_parallel"
    bl_label = "Vincolo parallele"
    bl_description = "Rende parallele due linee dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.PARALLEL


class SKETCHCAD_OT_constrain_perpendicular(_PickTwoLinesConstraintBase):
    bl_idname = "sketch_cad.constrain_perpendicular"
    bl_label = "Vincolo perpendicolari"
    bl_description = "Rende perpendicolari due linee dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.PERPENDICULAR


class SKETCHCAD_OT_constrain_equal(_PickTwoLinesConstraintBase):
    bl_idname = "sketch_cad.constrain_equal"
    bl_label = "Vincolo lunghezze uguali"
    bl_description = "Impone la stessa lunghezza a due linee dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.EQUAL_LENGTH


class SKETCHCAD_OT_constrain_angle(_PickTwoLinesConstraintBase):
    bl_idname = "sketch_cad.constrain_angle"
    bl_label = "Vincolo angolo"
    bl_description = (
        "Vincola l'angolo tra due linee (parte dal valore attuale, "
        "modificabile poi dal pannello)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.ANGLE


class SKETCHCAD_OT_constrain_radius(bpy.types.Operator):
    bl_idname = "sketch_cad.constrain_radius"
    bl_label = "Vincolo raggio"
    bl_description = (
        "Vincola il raggio di un cerchio o arco (parte dal valore attuale, "
        "modificabile poi dal pannello o con Modifica quota)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.sketch_cad.is_sketch
                and solver.available())

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set(
            "Raggio: click su un cerchio o un arco | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                model = props.load_model(self.obj)
                target = pick.circular_under_mouse(context, event, self.obj, model)
                if target is None:
                    return {'RUNNING_MODAL'}
                return self._apply(context, model, target)
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish(context, {'CANCELLED'})
        return {'RUNNING_MODAL'}

    def _apply(self, context, model, target):
        circle = model.circles.get(target)
        if circle is not None:
            value = circle.radius
        else:
            arc = model.arcs[target]
            center = model.points[arc.center]
            start = model.points[arc.start]
            value = math.hypot(start.u - center.u, start.v - center.v)

        cid = model.add_constraint(C.RADIUS, target, value=value)
        props.save_model(model, self.obj)
        result = convert.resolve_and_update(self.obj)
        if not result.ok:
            model.remove_constraint(cid)
            props.save_model(model, self.obj)
            self.report({'ERROR'}, f"Vincolo rifiutato: {result.message}")
            return self._finish(context, {'CANCELLED'})
        self.report({'INFO'}, f"Raggio applicato (gradi di libertà: {result.dof})")
        return self._finish(context, {'FINISHED'})

    def _finish(self, context, status):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        return status


class SKETCHCAD_OT_remove_constraint(bpy.types.Operator):
    bl_idname = "sketch_cad.remove_constraint"
    bl_label = "Rimuovi vincolo"
    bl_description = "Rimuove questo vincolo dallo sketch"
    bl_options = {'REGISTER', 'UNDO'}

    constraint_id: bpy.props.IntProperty()

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        model = props.load_model(obj)
        model.remove_constraint(self.constraint_id)
        props.save_model(model, obj)
        context.area.tag_redraw()
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_constrain_horizontal,
    SKETCHCAD_OT_constrain_vertical,
    SKETCHCAD_OT_constrain_distance,
    SKETCHCAD_OT_constrain_parallel,
    SKETCHCAD_OT_constrain_perpendicular,
    SKETCHCAD_OT_constrain_equal,
    SKETCHCAD_OT_constrain_angle,
    SKETCHCAD_OT_constrain_radius,
    SKETCHCAD_OT_remove_constraint,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
