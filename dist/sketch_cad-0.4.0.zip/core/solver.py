"""Adapter verso il solver geometrico SolveSpace (py-slvs).

py_slvs arriva come wheel bundled nell'extension (manifest) o via pip nei
test; l'import è guardato così il resto dell'addon funziona anche senza.
A ogni solve il sistema viene ricostruito da zero: con le entità di uno
sketch è economico e azzera i problemi di sincronizzazione degli handle.
"""

from dataclasses import dataclass, field

try:
    from py_slvs import slvs
except ImportError:  # wheel non installata: solver disattivo
    slvs = None

from . import constraints as C
from .model import SketchModel

_GROUP_FIXED = 1   # workplane
_GROUP_SKETCH = 2  # entità da risolvere

_MESSAGES = {
    0: "ok",
    1: "vincoli inconsistenti",
    2: "il solver non converge",
    3: "troppe incognite",
}


@dataclass
class SolveResult:
    ok: bool
    code: int
    dof: int
    failed: list[int] = field(default_factory=list)  # id dei vincoli falliti

    @property
    def message(self) -> str:
        return _MESSAGES.get(self.code, f"errore solver {self.code}")


def available() -> bool:
    return slvs is not None


def solve(model: SketchModel, dragged: dict[int, tuple[float, float]] | None = None) -> SolveResult:
    """Risolve i vincoli aggiornando le coordinate dei punti in place.

    dragged: {point_id: (u, v)} — punti che l'utente sta trascinando:
    partono dalla posizione richiesta e vengono ancorati con WHERE_DRAGGED,
    quindi si spostano solo se i vincoli lo impongono.

    Se la risoluzione fallisce il modello NON viene modificato.
    """
    if slvs is None:
        raise RuntimeError(
            "py-slvs non disponibile: reinstalla l'extension con la wheel inclusa")
    dragged = dragged or {}

    system = slvs.System()
    workplane = system.addWorkplane(
        system.addPoint3dV(0.0, 0.0, 0.0, _GROUP_FIXED),
        system.addNormal3dV(1.0, 0.0, 0.0, 0.0, _GROUP_FIXED),
        _GROUP_FIXED,
    )

    point_handles: dict[int, int] = {}
    for p in model.points.values():
        u, v = dragged.get(p.id, (p.u, p.v))
        point_handles[p.id] = system.addPoint2dV(workplane, u, v, _GROUP_SKETCH)
    for pid in dragged:
        handle = point_handles.get(pid)
        if handle is not None:
            system.addWhereDragged(handle, workplane, _GROUP_SKETCH)

    constraint_ids: dict[int, int] = {}  # handle slvs -> id vincolo nostro
    for c in model.constraints.values():
        handle = _add_constraint(system, workplane, model, point_handles, c)
        constraint_ids[handle] = c.id

    code = system.solve(_GROUP_SKETCH, True)
    ok = code == 0
    if ok:
        for pid, handle in point_handles.items():
            point = model.points[pid]
            point.u = system.getParam(system.getEntityParam(handle, 0)).val
            point.v = system.getParam(system.getEntityParam(handle, 1)).val
    failed = [constraint_ids[h] for h in system.Failed if h in constraint_ids]
    return SolveResult(ok, code, system.Dof, failed)


def _add_constraint(system, workplane, model, point_handles, c) -> int:
    """Traduce un nostro vincolo in un vincolo SolveSpace, ritorna l'handle."""
    if c.type == C.COINCIDENT:
        return system.addPointsCoincident(
            point_handles[c.a], point_handles[c.b], workplane, _GROUP_SKETCH)

    line = model.lines[c.a]
    pa, pb = point_handles[line.a], point_handles[line.b]
    if c.type == C.HORIZONTAL:
        return system.addPointsHorizontal(pa, pb, workplane, _GROUP_SKETCH)
    if c.type == C.VERTICAL:
        return system.addPointsVertical(pa, pb, workplane, _GROUP_SKETCH)
    if c.type == C.DISTANCE:
        return system.addPointsDistance(c.value, pa, pb, workplane, _GROUP_SKETCH)
    raise ValueError(f"Tipo vincolo sconosciuto: {c.type}")
