"""Definizione dei vincoli geometrici 2D.

I tipi sono stringhe stabili: vengono salvate così nei PropertyGroup,
quindi cambiarle richiederebbe una migrazione dello schema.
"""

from dataclasses import dataclass

COINCIDENT = 'COINCIDENT'
HORIZONTAL = 'HORIZONTAL'
VERTICAL = 'VERTICAL'
DISTANCE = 'DISTANCE'

TYPES = (COINCIDENT, HORIZONTAL, VERTICAL, DISTANCE)

LABELS = {
    COINCIDENT: "Coincidenti",
    HORIZONTAL: "Orizzontale",
    VERTICAL: "Verticale",
    DISTANCE: "Distanza",
}


@dataclass
class Constraint:
    id: int
    type: str
    a: int            # id linea (HORIZONTAL/VERTICAL/DISTANCE) o primo punto (COINCIDENT)
    b: int = 0        # secondo punto per COINCIDENT, altrimenti inutilizzato
    value: float = 0.0  # solo DISTANCE
