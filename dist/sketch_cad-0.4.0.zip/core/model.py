"""Modello dati 2D dello sketch.

Le entità vivono nel piano (u, v) dello sketch e si riferiscono tra loro
per id intero, mai per riferimento diretto: gli id sono stabili attraverso
la serializzazione nei PropertyGroup di Blender e, in futuro, verso il solver.
"""

from dataclasses import dataclass

from .constraints import COINCIDENT, TYPES, Constraint


@dataclass
class Point:
    id: int
    u: float
    v: float


@dataclass
class Line:
    id: int
    a: int  # id del punto iniziale
    b: int  # id del punto finale


class SketchModel:
    """Contenitore runtime delle entità di uno sketch."""

    def __init__(self):
        self.points: dict[int, Point] = {}
        self.lines: dict[int, Line] = {}
        self.constraints: dict[int, Constraint] = {}
        self.selection: set[int] = set()  # id di punti e linee selezionati
        self.next_id: int = 1

    def _new_id(self) -> int:
        new_id = self.next_id
        self.next_id += 1
        return new_id

    def add_point(self, u: float, v: float, *, merge_eps: float | None = None) -> int:
        """Aggiunge un punto e ne ritorna l'id.

        Con merge_eps, se esiste già un punto entro quella distanza viene
        riusato il suo id invece di crearne uno nuovo (merge degli endpoint).
        """
        if merge_eps is not None:
            existing = self.closest_point(u, v, merge_eps)
            if existing is not None:
                return existing
        pid = self._new_id()
        self.points[pid] = Point(pid, u, v)
        return pid

    def add_line(self, a: int, b: int) -> int | None:
        """Aggiunge un segmento tra due punti esistenti e ne ritorna l'id.

        Ritorna None per segmenti degeneri (a == b); se la coppia di punti
        è già collegata ritorna l'id della linea esistente.
        """
        if a == b:
            return None
        if a not in self.points or b not in self.points:
            raise KeyError(f"Punto inesistente: {a if a not in self.points else b}")
        for line in self.lines.values():
            if {line.a, line.b} == {a, b}:
                return line.id
        lid = self._new_id()
        self.lines[lid] = Line(lid, a, b)
        return lid

    def add_constraint(self, ctype: str, a: int, b: int = 0, *, value: float = 0.0) -> int:
        """Aggiunge un vincolo e ne ritorna l'id.

        Per COINCIDENT a e b sono id di punti; per gli altri tipi a è
        l'id della linea vincolata. Un duplicato esatto (stesso tipo
        sulle stesse entità) ritorna l'id del vincolo esistente.
        """
        if ctype not in TYPES:
            raise ValueError(f"Tipo vincolo sconosciuto: {ctype}")
        if ctype == COINCIDENT:
            if a not in self.points or b not in self.points:
                raise KeyError(f"Punto inesistente: {a if a not in self.points else b}")
            if a == b:
                raise ValueError("COINCIDENT richiede due punti distinti")
        else:
            if a not in self.lines:
                raise KeyError(f"Linea inesistente: {a}")
        for c in self.constraints.values():
            if c.type == ctype and {c.a, c.b} == {a, b}:
                return c.id
        cid = self._new_id()
        self.constraints[cid] = Constraint(cid, ctype, a, b, value)
        return cid

    def remove_constraint(self, cid: int) -> None:
        self.constraints.pop(cid, None)

    def delete_entities(self, ids: set[int]) -> tuple[int, int, int]:
        """Rimuove punti e/o linee con effetti a cascata; id ignoti ignorati.

        Cascata: un punto cancellato trascina le linee che lo usano; gli
        endpoint delle linee cancellate spariscono se nessun'altra linea
        li usa; i vincoli che riferiscono entità rimosse vengono rimossi.
        Ritorna (punti, linee, vincoli) rimossi.
        """
        doomed_points = {i for i in ids if i in self.points}
        doomed_lines = {i for i in ids if i in self.lines}
        doomed_lines |= {
            line.id for line in self.lines.values()
            if line.a in doomed_points or line.b in doomed_points
        }

        orphan_candidates: set[int] = set()
        for lid in doomed_lines:
            line = self.lines.pop(lid)
            orphan_candidates.add(line.a)
            orphan_candidates.add(line.b)

        still_used = set()
        for line in self.lines.values():
            still_used.add(line.a)
            still_used.add(line.b)
        doomed_points |= orphan_candidates - still_used

        for pid in doomed_points:
            self.points.pop(pid, None)

        doomed_constraints = set()
        for c in self.constraints.values():
            if c.type == COINCIDENT:
                if c.a not in self.points or c.b not in self.points:
                    doomed_constraints.add(c.id)
            elif c.a not in self.lines:
                doomed_constraints.add(c.id)
        for cid in doomed_constraints:
            del self.constraints[cid]

        self.selection -= doomed_points | doomed_lines | doomed_constraints
        return len(doomed_points), len(doomed_lines), len(doomed_constraints)

    def closest_point(self, u: float, v: float, max_dist: float) -> int | None:
        """Id del punto più vicino a (u, v) entro max_dist, o None."""
        best = None
        best_d2 = max_dist * max_dist
        for p in self.points.values():
            d2 = (p.u - u) ** 2 + (p.v - v) ** 2
            if d2 <= best_d2:
                best = p.id
                best_d2 = d2
        return best
