"""Picking screen-space delle entità sketch e proiezione mouse → piano."""

from bpy_extras import view3d_utils
from mathutils import Vector
from mathutils.geometry import intersect_line_plane


def mouse_to_plane(context, event, obj):
    """Proietta il mouse sul piano XY locale dello sketch → (u, v) o None."""
    region = context.region
    rv3d = context.region_data
    coord = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

    mw = obj.matrix_world
    plane_co = mw.translation
    plane_no = mw.col[2].to_3d().normalized()
    hit = intersect_line_plane(origin, origin + direction, plane_co, plane_no)
    if hit is None or (hit - origin).dot(direction) <= 0.0:
        return None  # vista parallela al piano, o piano dietro la camera
    local = mw.inverted() @ hit
    return (local.x, local.y)


def point_under_mouse(context, event, obj, model, max_px=14.0):
    """Id del punto del modello entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for p in model.points.values():
        world = mw @ Vector((p.u, p.v, 0.0))
        screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
        if screen is None:
            continue
        d = (screen - mouse).length
        if d < best_d:
            best = p.id
            best_d = d
    return best


def line_under_mouse(context, event, obj, model, max_px=10.0):
    """Id della linea del modello entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for line in model.lines.values():
        pa = model.points.get(line.a)
        pb = model.points.get(line.b)
        if pa is None or pb is None:
            continue
        sa = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((pa.u, pa.v, 0.0)))
        sb = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((pb.u, pb.v, 0.0)))
        if sa is None or sb is None:
            continue
        d = _dist_point_segment(mouse, sa, sb)
        if d < best_d:
            best = line.id
            best_d = d
    return best


def _dist_point_segment(p, a, b):
    ab = b - a
    if ab.length_squared == 0.0:
        return (p - a).length
    t = max(0.0, min(1.0, (p - a).dot(ab) / ab.length_squared))
    return (p - (a + ab * t)).length
