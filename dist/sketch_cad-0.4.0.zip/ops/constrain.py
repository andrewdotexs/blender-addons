"""Operatori per aggiungere e rimuovere vincoli (pick di una linea in viewport)."""

import math

import bpy

from .. import convert, pick, props
from ..core import constraints as C
from ..core import solver


class _PickLineConstraintBase(bpy.types.Operator):
    """Modale comune: click su una linea → applica il vincolo → re-solve."""

    constraint_type: str  # nelle sottoclassi

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.sketch_cad.is_sketch
                and solver.available())

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        label = C.LABELS[self.constraint_type]
        context.workspace.status_text_set(
            f"{label}: click su una linea | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                model = props.load_model(self.obj)
                line_id = pick.line_under_mouse(context, event, self.obj, model)
                if line_id is None:
                    return {'RUNNING_MODAL'}  # click a vuoto: riprova
                return self._apply(context, model, line_id)
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish(context, {'CANCELLED'})
        return {'RUNNING_MODAL'}

    def _apply(self, context, model, line_id):
        value = 0.0
        if self.constraint_type == C.DISTANCE:
            line = model.lines[line_id]
            pa, pb = model.points[line.a], model.points[line.b]
            value = math.hypot(pb.u - pa.u, pb.v - pa.v)

        cid = model.add_constraint(self.constraint_type, line_id, value=value)
        props.save_model(model, self.obj)
        result = convert.resolve_and_update(self.obj)
        if not result.ok:
            # rollback: il vincolo renderebbe lo sketch irrisolvibile
            model.remove_constraint(cid)
            props.save_model(model, self.obj)
            self.report({'ERROR'}, f"Vincolo rifiutato: {result.message}")
            return self._finish(context, {'CANCELLED'})

        label = C.LABELS[self.constraint_type]
        self.report({'INFO'}, f"{label} applicato (gradi di libertà: {result.dof})")
        return self._finish(context, {'FINISHED'})

    def _finish(self, context, status):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        return status


class SKETCHCAD_OT_constrain_horizontal(_PickLineConstraintBase):
    bl_idname = "sketch_cad.constrain_horizontal"
    bl_label = "Vincolo orizzontale"
    bl_description = "Rende orizzontale una linea dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.HORIZONTAL


class SKETCHCAD_OT_constrain_vertical(_PickLineConstraintBase):
    bl_idname = "sketch_cad.constrain_vertical"
    bl_label = "Vincolo verticale"
    bl_description = "Rende verticale una linea dello sketch"
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.VERTICAL


class SKETCHCAD_OT_constrain_distance(_PickLineConstraintBase):
    bl_idname = "sketch_cad.constrain_distance"
    bl_label = "Vincolo distanza"
    bl_description = (
        "Vincola la lunghezza di una linea (parte dal valore attuale, "
        "modificabile poi dal pannello)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    constraint_type = C.DISTANCE


class SKETCHCAD_OT_remove_constraint(bpy.types.Operator):
    bl_idname = "sketch_cad.remove_constraint"
    bl_label = "Rimuovi vincolo"
    bl_description = "Rimuove questo vincolo dallo sketch"
    bl_options = {'REGISTER', 'UNDO'}

    constraint_id: bpy.props.IntProperty()

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        model = props.load_model(obj)
        model.remove_constraint(self.constraint_id)
        props.save_model(model, obj)
        context.area.tag_redraw()
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_constrain_horizontal,
    SKETCHCAD_OT_constrain_vertical,
    SKETCHCAD_OT_constrain_distance,
    SKETCHCAD_OT_remove_constraint,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
