"""Disegno overlay degli sketch nella viewport 3D (modulo gpu).

Gli sketch non hanno geometria mesh visibile (Slice 1): tutto ciò che si
vede in viewport passa da qui. Per ora i batch vengono ricostruiti a ogni
redraw — con le quantità di entità di uno sketch è irrilevante; la cache
con dirty flag arriverà quando servirà.
"""

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

COL_LINE_ACTIVE = (0.92, 0.92, 0.92, 1.0)
COL_LINE_OTHER = (0.55, 0.55, 0.55, 0.5)
COL_POINT = (1.0, 0.62, 0.1, 1.0)
COL_RUBBER = (0.35, 0.7, 1.0, 0.9)
COL_SNAP = (0.3, 1.0, 0.45, 1.0)

_handle = None


def draw_lines(coords, color, width=2.0):
    """Disegna segmenti (coppie di Vector world) con spessore in pixel."""
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    shader.uniform_float("lineWidth", width)
    shader.uniform_float("color", color)
    batch.draw(shader)


def draw_points(coords, color, size=6.0):
    """Disegna punti (Vector world) con dimensione in pixel."""
    gpu.state.point_size_set(size)
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_sketches():
    context = bpy.context
    sketches = [o for o in context.visible_objects if o.sketch_cad.is_sketch]
    if not sketches:
        return

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')  # lo sketch resta visibile attraverso le mesh

    active = context.active_object
    for obj in sketches:
        data = obj.sketch_cad
        mw = obj.matrix_world
        world_points = {p.id: mw @ Vector((p.co[0], p.co[1], 0.0)) for p in data.points}

        line_coords = []
        for line in data.lines:
            a = world_points.get(line.a)
            b = world_points.get(line.b)
            if a is not None and b is not None:
                line_coords += [a, b]

        is_active = obj == active
        if line_coords:
            draw_lines(line_coords, COL_LINE_ACTIVE if is_active else COL_LINE_OTHER, 2.0)
        if is_active and world_points:
            draw_points(list(world_points.values()), COL_POINT, 6.0)

    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


def register():
    global _handle
    if bpy.app.background:
        return  # niente viewport in headless: lasciare l'handler spento
    _handle = bpy.types.SpaceView3D.draw_handler_add(_draw_sketches, (), 'WINDOW', 'POST_VIEW')


def unregister():
    global _handle
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, 'WINDOW')
        _handle = None
