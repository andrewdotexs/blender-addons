"""Riconoscimento dei profili chiusi (loop) nel grafo dello sketch.

Limiti correnti (Slice 2): vengono riconosciuti solo i cicli semplici —
componenti connesse in cui ogni punto ha grado 2 dopo la potatura delle
code (linee di costruzione appese). Punti di incrocio con grado > 2 e
fori (loop annidati) arriveranno con trim/booleane.
"""

from .model import SketchModel


def signed_area(model: SketchModel, loop: list[int]) -> float:
    """Area con segno del loop (shoelace): positiva se antiorario."""
    area = 0.0
    n = len(loop)
    for i in range(n):
        p = model.points[loop[i]]
        q = model.points[loop[(i + 1) % n]]
        area += p.u * q.v - q.u * p.v
    return area / 2.0


def find_closed_loops(model: SketchModel) -> list[list[int]]:
    """Ritorna i cicli semplici come liste ordinate di id punto.

    Ogni loop è normalizzato: parte dal punto con id minimo e procede
    in senso antiorario (area positiva → normale della faccia verso +Z).
    """
    adjacency: dict[int, set[int]] = {}
    for line in model.lines.values():
        adjacency.setdefault(line.a, set()).add(line.b)
        adjacency.setdefault(line.b, set()).add(line.a)

    # Potatura iterativa delle foglie: rimuove code e segmenti appesi,
    # lasciando solo la parte ciclica del grafo.
    leaves = [n for n, neighbors in adjacency.items() if len(neighbors) <= 1]
    while leaves:
        node = leaves.pop()
        neighbors = adjacency.pop(node, None)
        if neighbors is None:
            continue
        for nb in neighbors:
            remaining = adjacency.get(nb)
            if remaining is None:
                continue
            remaining.discard(node)
            if len(remaining) <= 1:
                leaves.append(nb)

    loops: list[list[int]] = []
    visited: set[int] = set()
    for start in sorted(adjacency):
        if start in visited:
            continue
        # Espandi la componente connessa e verifica che sia un ciclo semplice
        component: set[int] = set()
        stack = [start]
        degree_ok = True
        while stack:
            node = stack.pop()
            if node in component:
                continue
            component.add(node)
            if len(adjacency[node]) != 2:
                degree_ok = False
            stack.extend(adjacency[node] - component)
        visited |= component
        if not degree_ok or len(component) < 3:
            continue

        # Percorri il ciclo con direzione iniziale deterministica
        first = min(component)
        loop = [first]
        prev = first
        current = min(adjacency[first])
        while current != first:
            loop.append(current)
            prev, current = current, next(iter(adjacency[current] - {prev}))

        if signed_area(model, loop) < 0:
            loop.reverse()
            i = loop.index(first)
            loop = loop[i:] + loop[:i]
        loops.append(loop)

    return loops
