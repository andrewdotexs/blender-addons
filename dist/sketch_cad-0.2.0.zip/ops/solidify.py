"""Dal profilo 2D al solido 3D."""

import bpy

from .. import convert


class SKETCHCAD_OT_extrude(bpy.types.Operator):
    bl_idname = "sketch_cad.extrude"
    bl_label = "Estrudi profilo"
    bl_description = (
        "Genera il solido estrudendo i profili chiusi dello sketch "
        "(parametrico: la profondità resta modificabile)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        n_profiles = convert.rebuild_profile_mesh(obj)
        if n_profiles == 0:
            self.report({'WARNING'}, "Nessun profilo chiuso nello sketch")
            return {'CANCELLED'}
        convert.ensure_extrude_modifier(obj)
        self.report({'INFO'}, f"Estrusi {n_profiles} profili")
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_extrude,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
