"""Tool modali di disegno sullo sketch attivo."""

import bpy
import gpu
from bpy_extras import view3d_utils
from mathutils import Vector
from mathutils.geometry import intersect_line_plane

from .. import convert, overlay, props

SNAP_PX = 12.0  # raggio di aggancio agli endpoint esistenti, in pixel


class SKETCHCAD_OT_draw_line(bpy.types.Operator):
    bl_idname = "sketch_cad.draw_line"
    bl_label = "Disegna linee"
    bl_description = (
        "Disegna una polilinea sullo sketch attivo: click per aggiungere punti, "
        "click sul punto iniziale per chiudere, click destro/Invio/Esc per terminare"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}

        self.obj = context.active_object
        self.model = props.load_model(self.obj)
        self.first_pid = None    # primo punto della polilinea corrente
        self.prev_pid = None     # ultimo punto fissato
        self.preview_co = None   # (u, v) sotto il mouse
        self.snap_pid = None     # punto esistente agganciato
        self.lines_added = 0

        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_preview, (self,), 'WINDOW', 'POST_VIEW')
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set(
            "Click: aggiungi punto | click sul punto iniziale: chiudi profilo | "
            "Click dx / Invio / Esc: termina")
        self._update_preview(context, event)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        # Navigazione viewport sempre libera
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE':
            self._update_preview(context, event)
            return {'RUNNING_MODAL'}

        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                if self._place_point():
                    return self._finish(context)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}
            if event.type in {'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'}:
                return self._finish(context)

        return {'RUNNING_MODAL'}

    def _update_preview(self, context, event):
        self.preview_co = self._mouse_to_plane(context, event)
        self.snap_pid = None
        if self.preview_co is not None:
            self.snap_pid = self._find_snap(context, event)
            if self.snap_pid is not None:
                p = self.model.points[self.snap_pid]
                self.preview_co = (p.u, p.v)
        context.area.tag_redraw()

    def _mouse_to_plane(self, context, event):
        """Proietta il mouse sul piano XY locale dello sketch → (u, v) o None."""
        region = context.region
        rv3d = context.region_data
        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

        mw = self.obj.matrix_world
        plane_co = mw.translation
        plane_no = mw.col[2].to_3d().normalized()
        hit = intersect_line_plane(origin, origin + direction, plane_co, plane_no)
        if hit is None or (hit - origin).dot(direction) <= 0.0:
            return None  # vista parallela al piano, o piano dietro la camera
        local = mw.inverted() @ hit
        return (local.x, local.y)

    def _find_snap(self, context, event):
        """Id del punto del modello entro SNAP_PX pixel dal mouse, o None."""
        region = context.region
        rv3d = context.region_data
        mouse = Vector((event.mouse_region_x, event.mouse_region_y))
        mw = self.obj.matrix_world
        best = None
        best_d = SNAP_PX
        for p in self.model.points.values():
            world = mw @ Vector((p.u, p.v, 0.0))
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
            if screen is None:
                continue
            d = (screen - mouse).length
            if d < best_d:
                best = p.id
                best_d = d
        return best

    def _place_point(self):
        """Fissa un punto; ritorna True se la polilinea va chiusa qui."""
        if self.preview_co is None:
            return False
        pid = self.snap_pid if self.snap_pid is not None else self.model.add_point(*self.preview_co)

        if self.prev_pid is not None and pid != self.prev_pid:
            before = len(self.model.lines)
            self.model.add_line(self.prev_pid, pid)
            if len(self.model.lines) > before:
                self.lines_added += 1
                # I punti pending diventano persistenti solo qui, insieme
                # alla loro prima linea: niente punti orfani su Esc.
                props.save_model(self.model, self.obj)

        if self.first_pid is None:
            self.first_pid = pid
        elif pid == self.first_pid and self.lines_added > 0:
            return True  # profilo chiuso sul punto di partenza

        self.prev_pid = pid
        return False

    def _finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.lines_added:
            # La mesh-profilo segue sempre lo sketch: i profili chiusi
            # diventano facce (e alimentano l'eventuale estrusione GN).
            convert.rebuild_profile_mesh(self.obj)
            self.report({'INFO'}, f"Aggiunti {self.lines_added} segmenti")
            return {'FINISHED'}
        return {'CANCELLED'}


def _draw_preview(op):
    """Rubber band e marker di snap del tool attivo."""
    if op.preview_co is None:
        return
    mw = op.obj.matrix_world
    current = mw @ Vector((op.preview_co[0], op.preview_co[1], 0.0))

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')

    if op.prev_pid is not None:
        p = op.model.points[op.prev_pid]
        prev = mw @ Vector((p.u, p.v, 0.0))
        overlay.draw_lines([prev, current], overlay.COL_RUBBER, 1.5)

    if op.snap_pid is not None:
        overlay.draw_points([current], overlay.COL_SNAP, 11.0)
    else:
        overlay.draw_points([current], overlay.COL_RUBBER, 5.0)

    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


_classes = (
    SKETCHCAD_OT_draw_line,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
