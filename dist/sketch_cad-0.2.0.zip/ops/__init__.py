"""Operatori di Sketch CAD."""

from . import draw, sketch, solidify

_modules = (
    sketch,
    draw,
    solidify,
)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
