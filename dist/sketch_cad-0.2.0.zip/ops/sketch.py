"""Gestione del ciclo di vita degli sketch (creazione, in futuro edit/exit)."""

import bpy


class SKETCHCAD_OT_new_sketch(bpy.types.Operator):
    bl_idname = "sketch_cad.new_sketch"
    bl_label = "Nuovo sketch"
    bl_description = "Crea un nuovo sketch sul piano XY all'origine"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Un oggetto mesh vuoto: il piano dello sketch è il suo XY locale,
        # e dallo Slice 2 ospiterà la mesh-profilo e il modificatore GN.
        mesh = bpy.data.meshes.new("Sketch")
        obj = bpy.data.objects.new("Sketch", mesh)
        context.collection.objects.link(obj)
        obj.sketch_cad.is_sketch = True

        for other in context.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, f"Creato {obj.name}")
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_new_sketch,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
