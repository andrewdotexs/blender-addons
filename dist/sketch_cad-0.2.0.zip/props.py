"""Persistenza nel .blend: PropertyGroup su Object e sync col modello core.

I PropertyGroup sono lo storage (salvato nel .blend, integrato con l'undo);
SketchModel è la rappresentazione runtime su cui lavorano operatori e, in
futuro, il solver. load_model/save_model fanno la conversione completa.
"""

import bpy

from .core.model import Line, Point, SketchModel


class SketchPointProp(bpy.types.PropertyGroup):
    id: bpy.props.IntProperty()
    co: bpy.props.FloatVectorProperty(size=2)


class SketchLineProp(bpy.types.PropertyGroup):
    id: bpy.props.IntProperty()
    a: bpy.props.IntProperty()
    b: bpy.props.IntProperty()


class SketchCadObjectData(bpy.types.PropertyGroup):
    is_sketch: bpy.props.BoolProperty(default=False)
    schema_version: bpy.props.IntProperty(default=1)
    next_id: bpy.props.IntProperty(default=1)
    points: bpy.props.CollectionProperty(type=SketchPointProp)
    lines: bpy.props.CollectionProperty(type=SketchLineProp)


def load_model(obj) -> SketchModel:
    data = obj.sketch_cad
    model = SketchModel()
    for p in data.points:
        model.points[p.id] = Point(p.id, p.co[0], p.co[1])
    for line in data.lines:
        model.lines[line.id] = Line(line.id, line.a, line.b)
    model.next_id = max(data.next_id, 1)
    return model


def save_model(model: SketchModel, obj) -> None:
    data = obj.sketch_cad
    data.points.clear()
    data.lines.clear()
    for p in model.points.values():
        item = data.points.add()
        item.id = p.id
        item.co = (p.u, p.v)
    for line in model.lines.values():
        item = data.lines.add()
        item.id = line.id
        item.a = line.a
        item.b = line.b
    data.next_id = model.next_id


_classes = (
    SketchPointProp,
    SketchLineProp,
    SketchCadObjectData,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.sketch_cad = bpy.props.PointerProperty(type=SketchCadObjectData)


def unregister():
    del bpy.types.Object.sketch_cad
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
