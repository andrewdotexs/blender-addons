"""Pannelli e menu di Sketch CAD."""

import bpy

from . import convert


class SKETCHCAD_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sketch"
    bl_label = "Sketch CAD"

    def draw(self, context):
        layout = self.layout
        layout.operator("sketch_cad.new_sketch", icon='ADD')

        obj = context.active_object
        if obj is None or not obj.sketch_cad.is_sketch:
            layout.label(text="Nessuno sketch attivo", icon='INFO')
            return

        data = obj.sketch_cad
        box = layout.box()
        box.label(text=obj.name, icon='GREASEPENCIL')
        box.label(text=f"{len(data.points)} punti, {len(data.lines)} linee")
        box.operator("sketch_cad.draw_line", icon='IPO_LINEAR')

        solid = layout.box()
        n_profiles = len(obj.data.polygons)
        label = "1 profilo chiuso" if n_profiles == 1 else f"{n_profiles} profili chiusi"
        solid.label(text=label, icon='MESH_DATA')
        solid.operator("sketch_cad.extrude", icon='MOD_SOLIDIFY')

        mod = obj.modifiers.get(convert.MODIFIER_NAME)
        if mod is not None and mod.type == 'NODES' and mod.node_group is not None:
            identifier = convert.depth_prop_identifier(mod.node_group)
            if identifier is not None:
                solid.prop(mod, f'["{identifier}"]', text="Profondità")


_classes = (
    SKETCHCAD_PT_main,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
