"""Pannelli e menu di Sketch CAD."""

import bpy

from . import convert, props
from .core import constraints as C
from .core import expr, solver


class SKETCHCAD_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sketch"
    bl_label = "Sketch CAD"

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator("sketch_cad.new_sketch", icon='ADD')
        row.operator("sketch_cad.new_sketch_on_face", text="Su faccia",
                     icon='SNAP_FACE')

        obj = context.active_object
        if obj is not None and obj.sketch_cad.is_sketch and obj.mode == 'EDIT':
            warn = layout.box()
            warn.label(text="Sketch in Edit Mode", icon='ERROR')
            warn.label(text="Le modifiche manuali alla mesh")
            warn.label(text="verranno sovrascritte dai tool sketch.")
            warn.label(text="Per editare liberamente: Consolida.")
            return

        if obj is None or not obj.sketch_cad.is_sketch:
            source = convert.linked_source(obj) if obj is not None else None
            if source is not None:
                box = layout.box()
                box.label(text=f"Mesh collegata a: {source.name}", icon='LINKED')
                box.operator("sketch_cad.consolidate", icon='CHECKMARK')
            else:
                layout.label(text="Nessuno sketch attivo", icon='INFO')
            _draw_params(layout, context)
            return

        data = obj.sketch_cad
        box = layout.box()
        box.label(text=obj.name, icon='GREASEPENCIL')
        stats = [f"{len(data.points)} punti", f"{len(data.lines)} linee"]
        if len(data.circles):
            stats.append(f"{len(data.circles)} cerchi")
        if len(data.arcs):
            stats.append(f"{len(data.arcs)} archi")
        box.label(text=" · ".join(stats))
        box.operator("sketch_cad.draw_line", icon='IPO_LINEAR')
        row = box.row(align=True)
        row.operator("sketch_cad.draw_circle", text="Cerchio", icon='MESH_CIRCLE')
        row.operator("sketch_cad.draw_arc", text="Arco", icon='CURVE_NCIRCLE')
        box.operator("sketch_cad.move_point", icon='EMPTY_ARROWS')
        box.operator("sketch_cad.trim", icon='UNLINKED')

        n_selected = (sum(1 for p in data.points if p.selected)
                      + sum(1 for l in data.lines if l.selected)
                      + sum(1 for c in data.circles if c.selected)
                      + sum(1 for a in data.arcs if a.selected))
        row = box.row(align=True)
        row.operator("sketch_cad.select", icon='RESTRICT_SELECT_OFF')
        sub = row.row(align=True)
        sub.enabled = n_selected > 0
        sub.operator("sketch_cad.delete_selected", text="", icon='TRASH')
        if n_selected:
            box.label(text=f"{n_selected} entità selezionate")

        cons = layout.box()
        cons.label(text="Vincoli", icon='CONSTRAINT')
        if not solver.available():
            cons.label(text="Solver non disponibile", icon='ERROR')
        else:
            row = cons.row(align=True)
            row.operator("sketch_cad.constrain_horizontal", text="H")
            row.operator("sketch_cad.constrain_vertical", text="V")
            row.operator("sketch_cad.constrain_distance", text="Distanza")
            row = cons.row(align=True)
            row.operator("sketch_cad.constrain_parallel", text="Parallele")
            row.operator("sketch_cad.constrain_perpendicular", text="Perpend.")
            row = cons.row(align=True)
            row.operator("sketch_cad.constrain_equal", text="Uguali")
            row.operator("sketch_cad.constrain_angle", text="Angolo")
            row.operator("sketch_cad.constrain_radius", text="Raggio")
            row = cons.row(align=True)
            row.operator("sketch_cad.edit_dimension", icon='DRIVER_DISTANCE')
            row.operator("sketch_cad.move_dimension", text="", icon='ARROW_LEFTRIGHT')
        for c in data.constraints:
            row = cons.row(align=True)
            row.label(text=C.LABELS.get(c.type, c.type))
            if c.param:
                row.label(text=f"{c.param} = {c.value:.4g}", icon='DRIVER')
            elif c.type in (C.DISTANCE, C.RADIUS):
                row.prop(c, "value", text="")
            elif c.type == C.ANGLE:
                row.prop(c, "value_angle", text="")
            op = row.operator("sketch_cad.remove_constraint", text="", icon='X')
            op.constraint_id = c.id

        solid = layout.box()
        n_profiles = len(obj.data.polygons)
        label = "1 profilo chiuso" if n_profiles == 1 else f"{n_profiles} profili chiusi"
        solid.label(text=label, icon='MESH_DATA')
        solid.operator("sketch_cad.extrude", icon='MOD_SOLIDIFY')
        target = data.target_object
        if target is not None:
            solid.label(text=f"Su: {target.name}", icon='OBJECT_DATA')
            row = solid.row(align=True)
            row.operator("sketch_cad.boolean_cut", text="Taglia", icon='MOD_BOOLEAN')
            row.operator("sketch_cad.boolean_join", text="Unisci", icon='MOD_BOOLEAN')

        mod = obj.modifiers.get(convert.MODIFIER_NAME)
        if mod is not None and mod.type == 'NODES' and mod.node_group is not None:
            identifier = convert.depth_prop_identifier(mod.node_group)
            if identifier is not None:
                solid.prop(mod, f'["{identifier}"]', text="Profondità")
        row = solid.row(align=True)
        row.operator("sketch_cad.create_linked_mesh", text="Mesh collegata",
                     icon='LINKED')
        row.operator("sketch_cad.consolidate", text="Consolida", icon='CHECKMARK')

        _draw_params(layout, context)


def _draw_params(layout, context):
    """Tabella dei parametri di scena (condivisi da tutti gli sketch)."""
    box = layout.box()
    row = box.row(align=True)
    row.label(text="Parametri", icon='DRIVER')
    row.operator("sketch_cad.add_param", text="", icon='ADD')
    params = context.scene.sketch_cad_params
    errors = {}
    if len(params):
        _values, errors = expr.resolve_parameters(props.raw_parameters(context.scene))
    for p in params:
        row = box.row(align=True)
        row.label(text=p.name, icon='ERROR' if p.name in errors else 'NONE')
        if p.expression:
            row.label(text=f"= {p.expression}  ({p.value:.4g})")
        else:
            row.prop(p, "value", text="")
        op = row.operator("sketch_cad.edit_param", text="", icon='GREASEPENCIL')
        op.old_name = p.name
        op = row.operator("sketch_cad.remove_param", text="", icon='X')
        op.param_name = p.name


_classes = (
    SKETCHCAD_PT_main,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
