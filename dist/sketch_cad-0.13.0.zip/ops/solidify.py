"""Dal profilo 2D al solido 3D."""

import bpy

from .. import convert


class SKETCHCAD_OT_extrude(bpy.types.Operator):
    bl_idname = "sketch_cad.extrude"
    bl_label = "Estrudi profilo"
    bl_description = (
        "Genera il solido estrudendo i profili chiusi dello sketch "
        "(parametrico: la profondità resta modificabile)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        n_profiles = convert.rebuild_profile_mesh(obj)
        if n_profiles == 0:
            self.report({'WARNING'}, "Nessun profilo chiuso nello sketch")
            return {'CANCELLED'}
        convert.ensure_extrude_modifier(obj)
        self.report({'INFO'}, f"Estrusi {n_profiles} profili")
        return {'FINISHED'}


class _BooleanBase(bpy.types.Operator):
    """Aggancia il solido estruso dello sketch alla mesh bersaglio.

    Il bersaglio riceve un modificatore Boolean che punta allo sketch:
    tutta la catena resta parametrica (quote → estrusione → booleana).
    """

    operation: str    # 'DIFFERENCE' | 'UNION'
    depth_sign: float  # -1 = dentro la mesh (cut), +1 = fuori (join)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        obj = context.active_object
        target = obj.sketch_cad.target_object
        if target is None or target.type != 'MESH':
            self.report({'ERROR'},
                        "Sketch non agganciato a una mesh: crealo con Sketch su faccia")
            return {'CANCELLED'}
        if convert.rebuild_profile_mesh(obj) == 0:
            self.report({'WARNING'}, "Nessun profilo chiuso nello sketch")
            return {'CANCELLED'}

        mod = convert.ensure_extrude_modifier(obj)
        identifier = convert.depth_prop_identifier(mod.node_group)
        if identifier is not None:
            current = mod.get(identifier, 0.2) or 0.2
            mod[identifier] = self.depth_sign * abs(current)
            obj.update_tag()

        name = f"SketchCAD Boolean {obj.name}"
        bool_mod = target.modifiers.get(name)
        if bool_mod is None or bool_mod.type != 'BOOLEAN':
            bool_mod = target.modifiers.new(name, 'BOOLEAN')
        bool_mod.operation = self.operation
        bool_mod.object = obj

        # lo sketch resta visibile come riferimento, non come solido
        obj.display_type = 'WIRE'
        obj.hide_render = True
        self.report({'INFO'}, f"{self.bl_label} su {target.name}")
        return {'FINISHED'}


class SKETCHCAD_OT_boolean_cut(_BooleanBase):
    bl_idname = "sketch_cad.boolean_cut"
    bl_label = "Taglia dal bersaglio"
    bl_description = (
        "Sottrae il solido estruso dalla mesh su cui è stato creato lo "
        "sketch (l'estrusione va verso l'interno: profondità negativa)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    operation = 'DIFFERENCE'
    depth_sign = -1.0


class SKETCHCAD_OT_boolean_join(_BooleanBase):
    bl_idname = "sketch_cad.boolean_join"
    bl_label = "Unisci al bersaglio"
    bl_description = (
        "Unisce il solido estruso alla mesh su cui è stato creato lo "
        "sketch (l'estrusione va verso l'esterno)"
    )
    bl_options = {'REGISTER', 'UNDO'}
    operation = 'UNION'
    depth_sign = 1.0


def _sketches_collection(context):
    coll = bpy.data.collections.get("Sketches")
    if coll is None:
        coll = bpy.data.collections.new("Sketches")
        context.scene.collection.children.link(coll)
    return coll


def _move_to_sketches(context, obj):
    coll = _sketches_collection(context)
    for other in list(obj.users_collection):
        other.objects.unlink(obj)
    coll.objects.link(obj)
    obj.display_type = 'WIRE'
    obj.hide_render = True


class SKETCHCAD_OT_create_linked_mesh(bpy.types.Operator):
    bl_idname = "sketch_cad.create_linked_mesh"
    bl_label = "Crea mesh collegata"
    bl_description = (
        "Crea un oggetto mesh che segue lo sketch in tempo reale (sopra ci "
        "puoi mettere altri modificatori); lo sketch passa in wireframe "
        "nella collection Sketches"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        sketch = context.active_object
        convert.rebuild_profile_mesh(sketch)

        mesh = bpy.data.meshes.new(f"{sketch.name} Mesh")
        obj = bpy.data.objects.new(f"{sketch.name} Mesh", mesh)
        context.collection.objects.link(obj)
        mod = obj.modifiers.new("SketchCAD Linked", 'NODES')
        mod.node_group = convert.get_or_create_linked_group()
        identifier = convert.socket_identifier(mod.node_group, "Sketch")
        if identifier is not None:
            mod[identifier] = sketch

        _move_to_sketches(context, sketch)
        for other in context.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({'INFO'},
                    f"{obj.name} segue {sketch.name} (ora in 'Sketches')")
        return {'FINISHED'}


class SKETCHCAD_OT_consolidate(bpy.types.Operator):
    bl_idname = "sketch_cad.consolidate"
    bl_label = "Consolida in mesh"
    bl_description = (
        "Applica tutta la catena e converte in mesh pura e scollegata: da "
        "qui in poi modifiche libere (edit mode) ma non più parametriche"
    )
    bl_options = {'REGISTER', 'UNDO'}

    keep_sketch: bpy.props.BoolProperty(
        name="Conserva lo sketch",
        description="Lo sketch resta nella collection Sketches per poter "
                    "rigenerare in futuro",
        default=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and (
            obj.sketch_cad.is_sketch or convert.linked_source(obj) is not None)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        source = convert.linked_source(obj)
        was_sketch = obj.sketch_cad.is_sketch

        if was_sketch and self.keep_sketch:
            backup = obj.copy()
            backup.data = obj.data.copy()
            backup.name = f"{obj.name} Sketch"
            context.collection.objects.link(backup)
            _move_to_sketches(context, backup)

        # bake della geometria valutata (estrusione e modificatori inclusi)
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        new_mesh = bpy.data.meshes.new_from_object(
            eval_obj, preserve_all_data_layers=True, depsgraph=depsgraph)
        new_mesh.name = obj.name
        obj.modifiers.clear()
        old_mesh = obj.data
        obj.data = new_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

        if was_sketch:
            # non è più uno sketch: l'addon non deve più rigenerarlo
            data = obj.sketch_cad
            data.is_sketch = False
            data.points.clear()
            data.lines.clear()
            data.circles.clear()
            data.arcs.clear()
            data.constraints.clear()
            obj.display_type = 'TEXTURED'
            obj.hide_render = False
        elif not self.keep_sketch and source is not None:
            others = [o for o in bpy.data.objects
                      if o != obj and convert.linked_source(o) == source]
            if others:
                self.report({'INFO'},
                            "Sketch conservato: usato da altre mesh collegate")
            else:
                bpy.data.objects.remove(source)

        self.report({'INFO'}, f"{obj.name} consolidato in mesh pura")
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_extrude,
    SKETCHCAD_OT_boolean_cut,
    SKETCHCAD_OT_boolean_join,
    SKETCHCAD_OT_create_linked_mesh,
    SKETCHCAD_OT_consolidate,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
