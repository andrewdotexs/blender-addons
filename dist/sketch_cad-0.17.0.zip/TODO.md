# TODO

## Bug (priorità alta)

- ✅ **Risolto (Slice 10)** — Come vedi nell'immagine, ho disegnato un primo segmento, poi, partendo dal suo punto medio, ne ho disegnato un altro. Se provo a disegnare un segmento dalla metà del segmento già diviso non riesco (il segmento in rosso è quello che avrei voluto disegnare)
  → *ora esiste lo snap "su linea": si può partire da un punto qualsiasi di un segmento (marker azzurro piccolo), con vincolo "Punto su linea" automatico*
![bug001](..\static\images\bug001.png)

- ✅ **Risolto (Slice 10)** — Quando si inserisce un vincolo che comprende un segmento creato a partire dal punto medio di un altro segmento, questo non reta agganciato al punto medio (vedi cerchi in rosso)
  → *lo snap al punto medio ora crea il vincolo "Punto medio": il punto resta agganciato anche quando il solver muove la linea*
![bug002a](..\static\images\bug002a.png)
![bug002b](..\static\images\bug002b.png)

- ✅ **Risolto (Slice 10)** — Quando disegno una linea partendo dal punto medio di un segmento e poi successivamento muovo il vertice, questo non resta agganciato e si muove liberamente.
  → *stesso fix: il vincolo "Punto medio" tiene il punto al suo posto durante il drag*

- ✅ **Risolto (Slice 15, a737880)** — Quando creo un profilo chiuso nello sketch e poi lo estrudo, tornando allo scketch non è più evidenziata l'area del profilo chiuso
![bug003](..\static\images\bug003.png)
  → *lo sketch non passa più a wireframe dopo l'estrusione: l'area shaded dei profili resta visibile (e "Modifica sketch" ripara gli sketch dei file vecchi)*

- 🔜 **Diventa la feature "Dividi" (punto 3 qui sotto)** — Disegnando B dal punto medio di A, il segmento A NON si divide in A' e A'': il punto medio è un punto *vincolato sopra* A, che resta un'unica entità (è ciò che mantiene la parametricità). Per questo "il punto medio di A'" non esiste. Soluzione: operatore esplicito **Dividi** (lo Split/Break dei CAD) — vedi sotto.

## Migliorie (priorità media)

- ✅ **Risolto (Slice 10)** — Aggiungere lo snap dei vertici anche quando si spostano tramite la funzione "Muovi punto"
  → *magnetismo verso punti e punti medi durante il drag; al rilascio su uno snap viene creato il vincolo (Coincidenti / Punto medio)*

- ✅ **Risolto (541ddd7)** — Visualizzare le quote anche per il cerchio e l'arco quando si seleziona "Raggio"
  → *era un bug del filtro overlay: le quote raggio ora si disegnano (linea radiale + testo R…)*

- ✅ **Risolto (Slice 16)** — Aggiungere le curve come elemento nativo dello sketch
  → *curve di Bézier: tool "Curva" a 4 click (inizio, fine, due maniglie) con guide; partecipano ai profili (estrudibili), alla selezione/cancellazione e al drag dei punti; vincolo "Tangente" curva-linea e arco-linea nel punto condiviso. Fuori scope (dichiarato): trim su/con le curve*

- ✅ **Risolto (Slice 15, a737880)** — Ingrandire il font delle dimensioni
  → *13 → 16 px (costante FONT_SIZE in overlay.py)*

## Nuove funzionalità (**prima di implementarle ragioniamo assieme**) (priorità bassa)

- ✅ **Risolto (Slice 11 + 12)** — Aggiungere la gestione parametrica con la possibilità di assegnare lo stesso parametro a più dimensioni della geometria
  → *tabella parametri per scena (pannello "Parametri"); le quote si legano dal dialog Modifica quota; cambio → propagazione a tutti gli sketch. Con le espressioni: quote tipo `base*2+0.5` e parametri derivati (`doppio = base*2`) con dipendenze e cicli gestiti*

- ✅ **Risolto (Slice 13)** — Implementare la conversione da scketch a mesh di Blender nativa. Le modifiche fatte sullo sketch dovranno riflettersi sulla mesh nativa. Tutte le operazioni di modifica eseguite sulla mesh nativa, dovranno poter essere modificate (nei loro parametri) e/o cancellate (ritornando alla situazione pre-modifica)
  → *"Crea mesh collegata": oggetto mesh che segue lo sketch in tempo reale (modifiche sketch → riflesse); le operazioni sulla mesh = modificatori Blender (parametrici e cancellabili by design). "Consolida": bake esplicito a mesh pura per l'edit mode libero. Nota concordata: le modifiche manuali in edit mode non sono riparametrizzabili (limite di Blender, non aggirabile) — per quelle si consolida prima*

### Piano concordato (2026-06-12) — in ordine di lavoro

1. ✅ **Risolto (Slice 17)** — **Proietta geometria (stile Fusion "project geometry")**
   Operatore "Proietta": click su un lato o un vertice di una mesh 3D esistente (es. il solido sotto uno sketch-su-faccia) → l'elemento viene proiettato sul piano dello sketch e diventa una *entità vera* dello sketch (linea/punto), **bloccata** con un nuovo vincolo "Bloccato" (il riferimento non si muove). Da lì: snap, vincoli e quote verso il solido esistente.
   → *implementato: tool modale con priorità vertice > lato, merge dei punti condivisi (lati adiacenti riusano il vertice), punti bloccati in viola e immuni al drag*

2. **Linee di costruzione**
   Flag `construction` sulle entità: disegnate tratteggiate/colorate diverse, **escluse dai profili** (niente estrusione) ma piene partecipanti a snap e vincoli. Toggle nel tool di disegno o nel pannello per convertire entità esistenti.

3. **Dividi (Split/Break)**
   Operatore esplicito che spezza una linea (o un arco) nel punto cliccato, creando due entità reali con un punto condiviso — risolve il caso "voglio il punto medio di metà segmento": prima dividi A in A′/A″, poi i loro punti medi esistono. (La matematica c'è già nel trim: è un taglio senza rimozione. I vincoli sull'entità divisa vengono rimossi, come nel trim.)

4. **Altre funzionalità CAD da valutare** (punti separati, da prioritizzare assieme):
   - **Fillet/chamfer 2D** — raccordo automatico tra due linee che condividono un estremo: arco tangente + accorciamento; abbiamo già archi e tangenze
   - **Offset di profilo** — il profilo parallelo a distanza d (interno/esterno)
   - **Simmetria/mirror** — vincolo symmetric di SolveSpace rispetto a una linea
   - **Pattern lineari/circolari** — ripetizione di entità con passo/conteggio parametrico
   - **Export DXF** — esportazione 2D dello sketch per officina/laser
   - **Revolve** — solido di rivoluzione attorno a un asse, in alternativa all'estrusione (node group analogo)