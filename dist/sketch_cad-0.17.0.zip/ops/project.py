"""Proietta geometria: copia lati/vertici di mesh 3D nello sketch.

Stile Fusion "project geometry": l'elemento cliccato viene proiettato
ortogonalmente sul piano dello sketch e diventa un'entità vera (linea o
punto), bloccata con il vincolo FIXED — un riferimento stabile per snap,
vincoli e quote verso il solido esistente.
"""

import bpy
from bpy_extras import view3d_utils
from mathutils import Vector

from .. import convert, props
from ..core import constraints as C
from ..core import solver

_VERTEX_PX = 12.0
_EDGE_PX = 10.0


def project_world_segment(obj, model, world_a, world_b=None):
    """Proietta un segmento (o un punto, se world_b è None) nello sketch.

    Crea punti/linea con merge sugli esistenti e li blocca con FIXED.
    Ritorna il numero di entità create o riusate.
    """
    inv = obj.matrix_world.inverted()

    def add_fixed_point(world_co):
        local = inv @ Vector(world_co)
        pid = model.add_point(local.x, local.y, merge_eps=1e-6)
        try:
            model.add_constraint(C.FIXED, pid)
        except (KeyError, ValueError):
            pass
        return pid

    pid_a = add_fixed_point(world_a)
    if world_b is None:
        return 1
    pid_b = add_fixed_point(world_b)
    if pid_a != pid_b:
        model.add_line(pid_a, pid_b)
    return 2


class SKETCHCAD_OT_project_geometry(bpy.types.Operator):
    bl_idname = "sketch_cad.project_geometry"
    bl_label = "Proietta geometria"
    bl_description = (
        "Click su un lato o un vertice di una mesh 3D: viene proiettato sul "
        "piano dello sketch come entità bloccata (riferimento per snap, "
        "vincoli e quote)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        self.projected = 0
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('EYEDROPPER')
        context.workspace.status_text_set(
            "Click su un lato o un vertice di una mesh | "
            "Click dx / Esc: termina")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                self._click(context, event)
                return {'RUNNING_MODAL'}
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish(context)
        return {'RUNNING_MODAL'}

    def _click(self, context, event):
        element = self._pick_mesh_element(context, event)
        if element is None:
            return
        model = props.load_model(self.obj)
        project_world_segment(self.obj, model, *element)
        props.save_model(model, self.obj)
        if solver.available():
            convert.resolve_and_update(self.obj)
        else:
            convert.rebuild_profile_mesh(self.obj)
        self.projected += 1
        context.area.tag_redraw()

    def _pick_mesh_element(self, context, event):
        """(world_a, world_b) per un lato, (world_v, None) per un vertice."""
        region = context.region
        rv3d = context.region_data
        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        depsgraph = context.evaluated_depsgraph_get()
        hit, _location, _normal, index, target, matrix = context.scene.ray_cast(
            depsgraph, origin, direction)
        if (not hit or target is None or target.type != 'MESH'
                or target.original == self.obj):
            return None
        mesh = target.evaluated_get(depsgraph).data
        if index < 0 or index >= len(mesh.polygons):
            return None
        poly = mesh.polygons[index]
        mouse = Vector(coord)

        # priorità al vertice
        best_vertex = None
        best_d = _VERTEX_PX
        for vi in poly.vertices:
            world = matrix @ mesh.vertices[vi].co
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
            if screen is None:
                continue
            d = (screen - mouse).length
            if d < best_d:
                best_vertex, best_d = world, d
        if best_vertex is not None:
            return (best_vertex, None)

        # poi il lato più vicino
        best_edge = None
        best_d = _EDGE_PX
        for v1, v2 in poly.edge_keys:
            wa = matrix @ mesh.vertices[v1].co
            wb = matrix @ mesh.vertices[v2].co
            sa = view3d_utils.location_3d_to_region_2d(region, rv3d, wa)
            sb = view3d_utils.location_3d_to_region_2d(region, rv3d, wb)
            if sa is None or sb is None:
                continue
            seg = sb - sa
            if seg.length_squared < 1e-9:
                continue
            t = max(0.0, min(1.0, (mouse - sa).dot(seg) / seg.length_squared))
            d = (mouse - (sa + seg * t)).length
            if d < best_d:
                best_edge, best_d = (wa, wb), d
        return best_edge

    def _finish(self, context):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.projected:
            self.report({'INFO'}, f"Proiettati {self.projected} elementi")
            return {'FINISHED'}
        return {'CANCELLED'}


_classes = (
    SKETCHCAD_OT_project_geometry,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
