"""Dal profilo 2D al solido 3D.

Modello (dallo Slice 14): lo sketch resta SEMPRE un disegno 2D sul suo
piano; "Estrudi profilo" crea/aggiorna un oggetto mesh separato e
collegato (il solido), su cui si applicano i modificatori Blender. Le
booleane usano quella mesh come operando. "Consolida" la trasforma in
mesh pura e scollegata.
"""

import bpy

from .. import convert


def _move_to_sketches(context, obj):
    coll = convert.sketches_collection(context)
    for other in list(obj.users_collection):
        other.objects.unlink(obj)
    coll.objects.link(obj)
    # niente WIRE: la mesh-profilo shaded è l'evidenziazione dei
    # profili chiusi quando si riapre lo sketch
    obj.hide_render = True


def _set_hidden(obj, hidden):
    try:
        obj.hide_set(hidden)
    except RuntimeError:
        pass  # oggetto fuori dal view layer: lo gestisce l'utente


def _activate(context, obj):
    for other in context.selected_objects:
        other.select_set(False)
    _set_hidden(obj, False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


def ensure_solid(context, sketch):
    """La mesh estrusa dello sketch (creata se manca).

    Migra i file pre-0.14: se lo sketch ha ancora il vecchio modificatore
    di estrusione, ne eredita la profondità e lo rimuove (lo sketch torna
    un puro 2D).
    """
    legacy_depth = None
    legacy = sketch.modifiers.get(convert.MODIFIER_NAME)
    if legacy is not None:
        if legacy.type == 'NODES' and legacy.node_group is not None:
            identifier = convert.depth_prop_identifier(legacy.node_group)
            if identifier is not None:
                legacy_depth = legacy.get(identifier)
        sketch.modifiers.remove(legacy)

    meshes = convert.linked_meshes_of(context, sketch)
    if meshes:
        return meshes[0]

    mesh = bpy.data.meshes.new(f"{sketch.name} Mesh")
    solid = bpy.data.objects.new(f"{sketch.name} Mesh", mesh)
    convert.normal_collection(context).objects.link(solid)
    mod = solid.modifiers.new("SketchCAD Solid", 'NODES')
    mod.node_group = convert.get_or_create_solid_group()
    sketch_socket = convert.socket_identifier(mod.node_group, "Sketch")
    if sketch_socket is not None:
        mod[sketch_socket] = sketch
    if legacy_depth is not None:
        depth_socket = convert.socket_identifier(mod.node_group, "Depth")
        if depth_socket is not None:
            mod[depth_socket] = legacy_depth
    return solid


class SKETCHCAD_OT_extrude(bpy.types.Operator):
    bl_idname = "sketch_cad.extrude"
    bl_label = "Estrudi profilo"
    bl_description = (
        "Crea (o riapre) la mesh estrusa dai profili chiusi dello sketch: "
        "un oggetto separato e parametrico; lo sketch resta un disegno 2D "
        "nella collection Sketches"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        sketch = context.active_object
        n_profiles = convert.rebuild_profile_mesh(sketch)
        if n_profiles == 0:
            self.report({'WARNING'}, "Nessun profilo chiuso nello sketch")
            return {'CANCELLED'}
        solid = ensure_solid(context, sketch)
        _move_to_sketches(context, sketch)
        _activate(context, solid)
        sketch.hide_set(True)
        self.report({'INFO'}, f"{solid.name} estruso da {sketch.name}")
        return {'FINISHED'}


class SKETCHCAD_OT_consolidate(bpy.types.Operator):
    bl_idname = "sketch_cad.consolidate"
    bl_label = "Consolida in mesh"
    bl_description = (
        "Applica tutta la catena e converte la mesh estrusa in mesh pura "
        "e scollegata: da qui in poi modifiche libere (edit mode) ma non "
        "più parametriche"
    )
    bl_options = {'REGISTER', 'UNDO'}

    keep_sketch: bpy.props.BoolProperty(
        name="Conserva lo sketch",
        description="Lo sketch resta nella collection Sketches per poter "
                    "rigenerare in futuro",
        default=True)

    @classmethod
    def poll(cls, context):
        return convert.linked_source(context.active_object) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        source = convert.linked_source(obj)

        # bake della geometria valutata (estrusione e modificatori inclusi)
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        new_mesh = bpy.data.meshes.new_from_object(
            eval_obj, preserve_all_data_layers=True, depsgraph=depsgraph)
        new_mesh.name = obj.name
        obj.modifiers.clear()
        old_mesh = obj.data
        obj.data = new_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

        if not self.keep_sketch and source is not None:
            others = [o for o in bpy.data.objects
                      if o != obj and convert.linked_source(o) == source]
            if others:
                self.report({'INFO'},
                            "Sketch conservato: usato da altre mesh collegate")
            else:
                bpy.data.objects.remove(source)

        self.report({'INFO'}, f"{obj.name} consolidato in mesh pura")
        return {'FINISHED'}


class SKETCHCAD_OT_edit_linked_sketch(bpy.types.Operator):
    bl_idname = "sketch_cad.edit_linked_sketch"
    bl_label = "Modifica sketch"
    bl_description = (
        "Mostra e attiva lo sketch sorgente nascondendo la mesh estrusa "
        "(si torna con \"Torna alla mesh\")"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return convert.linked_source(context.active_object) is not None

    def execute(self, context):
        source = convert.linked_source(context.active_object)
        try:
            source.hide_set(False)
        except RuntimeError:
            self.report({'ERROR'},
                        "Lo sketch non è nel view layer: riattiva la collection Sketches")
            return {'CANCELLED'}
        source.display_type = 'TEXTURED'  # ripara gli sketch WIRE dei file vecchi
        _activate(context, source)
        for linked in convert.linked_meshes_of(context, source):
            _set_hidden(linked, True)
        return {'FINISHED'}


class SKETCHCAD_OT_back_to_linked(bpy.types.Operator):
    bl_idname = "sketch_cad.back_to_linked"
    bl_label = "Torna alla mesh"
    bl_description = "Nasconde lo sketch e riattiva la sua mesh estrusa"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        sketch = context.active_object
        linked_meshes = convert.linked_meshes_of(context, sketch)
        if not linked_meshes:
            self.report({'WARNING'}, "Nessuna mesh collegata a questo sketch")
            return {'CANCELLED'}
        normal = convert.normal_collection(context)
        for linked in linked_meshes:
            _set_hidden(linked, False)
            # auto-riparazione: una mesh estrusa non sta in Sketches
            if any(convert.is_sketches_collection(c)
                   for c in linked.users_collection):
                for coll in list(linked.users_collection):
                    coll.objects.unlink(linked)
                normal.objects.link(linked)
        _activate(context, linked_meshes[0])
        sketch.hide_set(True)
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_extrude,
    SKETCHCAD_OT_consolidate,
    SKETCHCAD_OT_edit_linked_sketch,
    SKETCHCAD_OT_back_to_linked,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
