"""Gestione del ciclo di vita degli sketch: creazione libera o su faccia."""

import bpy
from bpy_extras import view3d_utils
from mathutils import Matrix

from .. import convert


def sketch_matrix_for_face(center_world, normal_world) -> Matrix:
    """Matrice di uno sketch su una faccia: origine al centro, +Z = normale."""
    quat = normal_world.normalized().to_track_quat('Z', 'Y')
    return Matrix.LocRotScale(center_world, quat, None)


def create_sketch_object(context, matrix_world=None, target=None):
    """Crea l'oggetto sketch (mesh vuota: dallo Slice 2 ospita la
    mesh-profilo e il modificatore GN) nella collection Sketches e lo
    rende attivo."""
    mesh = bpy.data.meshes.new("Sketch")
    obj = bpy.data.objects.new("Sketch", mesh)
    convert.sketches_collection(context).objects.link(obj)
    if obj.name not in context.view_layer.objects:
        # la collection Sketches è esclusa dal view layer: garantisci
        # comunque la visibilità del nuovo sketch
        context.scene.collection.objects.link(obj)
    obj.sketch_cad.is_sketch = True
    if matrix_world is not None:
        obj.matrix_world = matrix_world
    if target is not None:
        obj.sketch_cad.target_object = target
    for other in context.selected_objects:
        other.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    return obj


class SKETCHCAD_OT_new_sketch(bpy.types.Operator):
    bl_idname = "sketch_cad.new_sketch"
    bl_label = "Nuovo sketch"
    bl_description = "Crea un nuovo sketch sul piano XY all'origine"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = create_sketch_object(context)
        self.report({'INFO'}, f"Creato {obj.name}")
        return {'FINISHED'}


class SKETCHCAD_OT_new_sketch_on_face(bpy.types.Operator):
    bl_idname = "sketch_cad.new_sketch_on_face"
    bl_label = "Sketch su faccia"
    bl_description = (
        "Crea uno sketch sul piano di una faccia esistente (click su una "
        "mesh): lo sketch ricorda la mesh di provenienza"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('EYEDROPPER')
        context.workspace.status_text_set(
            "Click su una faccia | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                hit = self._raycast(context, event)
                if hit is None:
                    return {'RUNNING_MODAL'}
                center, normal, target = hit
                self._finish(context)
                obj = create_sketch_object(
                    context, sketch_matrix_for_face(center, normal), target)
                self.report({'INFO'}, f"{obj.name} sulla faccia di {target.name}")
                return {'FINISHED'}
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                self._finish(context)
                return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _raycast(self, context, event):
        """(centro faccia, normale, oggetto originale) sotto il mouse, o None."""
        region = context.region
        rv3d = context.region_data
        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        depsgraph = context.evaluated_depsgraph_get()
        hit, _location, normal, index, target, matrix = context.scene.ray_cast(
            depsgraph, origin, direction)
        if not hit or target is None or target.type != 'MESH':
            return None
        eval_obj = target.evaluated_get(depsgraph)
        if index < 0 or index >= len(eval_obj.data.polygons):
            return None
        center = matrix @ eval_obj.data.polygons[index].center
        return center, normal, target.original

    def _finish(self, context):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)


_classes = (
    SKETCHCAD_OT_new_sketch,
    SKETCHCAD_OT_new_sketch_on_face,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
