"""Conversione sketch → geometria Blender.

La mesh dell'oggetto sketch contiene solo i profili chiusi (un ngon per
loop, normale +Z); le linee restano nell'overlay. L'estrusione è un
modificatore Geometry Nodes con input Depth: cambiando la profondità il
solido si aggiorna senza ricostruire nulla.
"""

import bmesh
import bpy

from . import props
from .core import geom, profile, solver

MODIFIER_NAME = "SketchCAD Extrude"      # legacy: estrusione sullo sketch (pre-0.14)
NODE_GROUP_NAME = "SketchCAD Extrude"    # legacy
LINKED_GROUP_NAME = "SketchCAD Linked"   # legacy: mesh collegata senza estrusione
SOLID_GROUP_NAME = "SketchCAD Solid"     # mesh estrusa: Object Info + estrusione


def rebuild_profile_mesh(obj) -> int:
    """Rigenera la mesh-profilo dai profili chiusi; ritorna quanti sono.

    Profili: i loop linee+archi (tessellati) e i cerchi (dischi).
    """
    model = props.load_model(obj)

    boundaries: list[list[tuple[float, float]]] = []
    for loop in profile.find_closed_loops(model):
        coords = profile.tessellate_loop(model, loop)
        if len(coords) >= 3:
            boundaries.append(coords)
    for circle in model.circles.values():
        if circle.radius < 1e-9:
            continue
        center = model.points[circle.center]
        boundaries.append(geom.circle_points((center.u, center.v), circle.radius))

    bm = bmesh.new()
    faces = 0
    for coords in boundaries:
        verts = [bm.verts.new((u, v, 0.0)) for u, v in coords]
        try:
            bm.faces.new(verts)
            faces += 1
        except ValueError:
            continue  # faccia degenere o duplicata: profilo ignorato
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return faces


def resolve_and_update(obj, dragged=None) -> solver.SolveResult:
    """Risolve i vincoli e, se ok, persiste e rigenera la mesh-profilo.

    Le quote legate a un parametro di scena ricevono il suo valore prima
    del solve. In caso di fallimento i props restano intatti: la geometria
    rimane all'ultima soluzione valida.
    """
    model = props.load_model(obj)
    scene = bpy.context.scene
    if scene is not None:
        model.apply_parameters(props.scene_parameters(scene))
    result = solver.solve(model, dragged)
    if result.ok:
        props.save_model(model, obj)
        rebuild_profile_mesh(obj)
    return result


def socket_identifier(group, name, in_out='INPUT') -> str | None:
    """Identifier della IDProperty del modifier per un socket del gruppo."""
    for item in group.interface.items_tree:
        if (item.item_type == 'SOCKET' and item.in_out == in_out
                and item.name == name):
            return item.identifier
    return None


def depth_prop_identifier(group) -> str | None:
    """Identifier della IDProperty del modifier che pilota Depth."""
    return socket_identifier(group, "Depth")


def get_or_create_solid_group():
    """Node group della mesh estrusa: lo sketch (profilo 2D) entra via
    Object Info e viene estruso qui, con base chiusa.

    La sincronizzazione è del depsgraph: la mesh mostra lo sketch valutato
    senza alcun codice di sync; lo sketch resta un puro disegno 2D.
    """
    group = bpy.data.node_groups.get(SOLID_GROUP_NAME)
    if group is not None:
        return group

    group = bpy.data.node_groups.new(SOLID_GROUP_NAME, 'GeometryNodeTree')
    group.interface.new_socket(
        "Sketch", in_out='INPUT', socket_type='NodeSocketObject')
    depth = group.interface.new_socket(
        "Depth", in_out='INPUT', socket_type='NodeSocketFloat')
    depth.subtype = 'DISTANCE'
    depth.default_value = 0.2
    group.interface.new_socket(
        "Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    group_in = group.nodes.new('NodeGroupInput')
    group_in.location = (-450, 0)
    group_out = group.nodes.new('NodeGroupOutput')
    group_out.location = (450, 0)
    info = group.nodes.new('GeometryNodeObjectInfo')
    info.location = (-250, 0)
    info.transform_space = 'RELATIVE'  # a trasformazione identità la mesh
    #                                    appare esattamente dove sta lo sketch
    extrude = group.nodes.new('GeometryNodeExtrudeMesh')
    extrude.location = (-50, 100)
    extrude.mode = 'FACES'
    flip = group.nodes.new('GeometryNodeFlipFaces')
    flip.location = (-50, -150)
    join = group.nodes.new('GeometryNodeJoinGeometry')
    join.location = (120, 0)
    merge = group.nodes.new('GeometryNodeMergeByDistance')
    merge.location = (290, 0)
    merge.inputs["Distance"].default_value = 1e-5

    group.links.new(group_in.outputs["Sketch"], info.inputs["Object"])
    group.links.new(info.outputs["Geometry"], extrude.inputs["Mesh"])
    group.links.new(group_in.outputs["Depth"], extrude.inputs["Offset Scale"])
    group.links.new(info.outputs["Geometry"], flip.inputs["Mesh"])
    group.links.new(extrude.outputs["Mesh"], join.inputs["Geometry"])
    group.links.new(flip.outputs["Mesh"], join.inputs["Geometry"])
    group.links.new(join.outputs["Geometry"], merge.inputs["Geometry"])
    group.links.new(merge.outputs["Geometry"], group_out.inputs["Geometry"])
    return group


def sketches_collection(context):
    """La collection "Sketches" (creata se manca): casa di tutti gli sketch."""
    coll = bpy.data.collections.get("Sketches")
    if coll is None:
        coll = bpy.data.collections.new("Sketches")
        context.scene.collection.children.link(coll)
    return coll


def is_sketches_collection(coll) -> bool:
    return coll.name == "Sketches" or coll.name.startswith("Sketches.")


def normal_collection(context):
    """Collection di destinazione per gli oggetti che NON sono sketch.

    Se la collection attiva è "Sketches", ripiega sulla prima collection
    normale della scena (es. "Collection"), o sulla scene collection.
    """
    coll = context.collection
    if coll is not None and not is_sketches_collection(coll):
        return coll
    for child in context.scene.collection.children:
        if not is_sketches_collection(child):
            return child
    return context.scene.collection


def solid_modifier(obj):
    """Il modificatore "mesh estrusa" di obj, o None."""
    if obj is None or obj.type != 'MESH':
        return None
    for mod in obj.modifiers:
        if (mod.type == 'NODES' and mod.node_group is not None
                and (mod.node_group.name.startswith(SOLID_GROUP_NAME)
                     or mod.node_group.name.startswith(LINKED_GROUP_NAME))):
            return mod
    return None


def linked_source(obj):
    """Lo sketch sorgente se obj è una mesh estrusa/collegata, altrimenti None."""
    mod = solid_modifier(obj)
    if mod is None:
        return None
    identifier = socket_identifier(mod.node_group, "Sketch")
    if identifier is None:
        return None
    return mod.get(identifier)


def linked_meshes_of(context, sketch):
    """Le mesh estruse/collegate che hanno sketch come sorgente."""
    return [o for o in context.scene.objects if linked_source(o) == sketch]
