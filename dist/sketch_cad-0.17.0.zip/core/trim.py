"""Trim: rimozione della porzione di un'entità compresa tra le intersezioni.

Il trim spezza solo l'entità bersaglio: le entità intersecanti restano
intere. I punti di taglio usano il merge (add_point con merge_eps), quindi
alle giunzioni esatte — per esempio una T su un endpoint esistente — la
topologia resta connessa. Un cerchio trimmato diventa un arco; con meno di
due intersezioni il trim equivale alla cancellazione. I vincoli che
riferiscono l'entità bersaglio vengono rimossi insieme ad essa.
"""

import math

from . import geom
from .intersect import circle_circle_points as _circle_circle_points
from .intersect import on_arc as _on_arc
from .intersect import seg_circle_params as _seg_circle_params
from .intersect import seg_seg_params as _seg_seg_params
from .model import SketchModel

_EPS_T = 1e-9      # tolleranza parametrica interna
_MERGE_EPS = 1e-6  # aggancio dei punti di taglio ai punti esistenti

_TAU = 2.0 * math.pi


def trim_at(model: SketchModel, eid: int, u: float, v: float) -> bool:
    """Rimuove la porzione dell'entità eid più vicina al punto (u, v)."""
    if eid in model.lines:
        return _trim_line(model, eid, (u, v))
    if eid in model.circles:
        return _trim_circle(model, eid, (u, v))
    if eid in model.arcs:
        return _trim_arc(model, eid, (u, v))
    return False


# --- helper -------------------------------------------------------------------

def _pt(model, pid):
    p = model.points[pid]
    return (p.u, p.v)


def _dedup_sorted(values, eps=1e-9):
    out = []
    for x in sorted(values):
        if not out or x - out[-1] > eps:
            out.append(x)
    return out


# --- raccolta dei tagli sul bersaglio ----------------------------------------

def _line_cuts(model, line):
    """Parametri t interni (0, 1) dove la linea è intersecata da altre entità."""
    a, b = _pt(model, line.a), _pt(model, line.b)
    cuts = []
    for other in model.lines.values():
        if other.id == line.id:
            continue
        r = _seg_seg_params(a, b, _pt(model, other.a), _pt(model, other.b))
        if r is None:
            continue
        t, s = r
        if _EPS_T < t < 1.0 - _EPS_T and -_EPS_T <= s <= 1.0 + _EPS_T:
            cuts.append(t)
    for circle in model.circles.values():
        center = _pt(model, circle.center)
        for t in _seg_circle_params(a, b, center, circle.radius):
            if _EPS_T < t < 1.0 - _EPS_T:
                cuts.append(t)
    for arc in model.arcs.values():
        center = _pt(model, arc.center)
        start = _pt(model, arc.start)
        radius = math.hypot(start[0] - center[0], start[1] - center[1])
        for t in _seg_circle_params(a, b, center, radius):
            if not (_EPS_T < t < 1.0 - _EPS_T):
                continue
            p = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            if _on_arc(model, arc, p):
                cuts.append(t)
    return _dedup_sorted(cuts)


def _circle_cuts(model, center, radius, exclude):
    """Angoli assoluti [0, 2π) dei tagli sul cerchio portante dato."""
    angles = []

    def add_point(p):
        angles.append(math.atan2(p[1] - center[1], p[0] - center[0]) % _TAU)

    for line in model.lines.values():
        a, b = _pt(model, line.a), _pt(model, line.b)
        for t in _seg_circle_params(a, b, center, radius):
            if -_EPS_T <= t <= 1.0 + _EPS_T:
                add_point((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    for circle in model.circles.values():
        if circle.id == exclude:
            continue
        for p in _circle_circle_points(
                center, radius, _pt(model, circle.center), circle.radius):
            add_point(p)
    for arc in model.arcs.values():
        if arc.id == exclude:
            continue
        arc_center = _pt(model, arc.center)
        arc_start = _pt(model, arc.start)
        arc_radius = math.hypot(arc_start[0] - arc_center[0],
                                arc_start[1] - arc_center[1])
        for p in _circle_circle_points(center, radius, arc_center, arc_radius):
            if _on_arc(model, arc, p):
                add_point(p)
    return _dedup_sorted(angles)


# --- trim per tipo di bersaglio ----------------------------------------------

def _trim_line(model, eid, click):
    line = model.lines[eid]
    a, b = _pt(model, line.a), _pt(model, line.b)
    dx, dy = b[0] - a[0], b[1] - a[1]
    length2 = dx * dx + dy * dy
    if length2 < 1e-18:
        model.delete_entities({eid})
        return True
    t_click = ((click[0] - a[0]) * dx + (click[1] - a[1]) * dy) / length2
    t_click = min(max(t_click, 0.0), 1.0)

    bounds = [0.0] + _line_cuts(model, line) + [1.0]
    lo, hi = 0.0, 1.0
    for i in range(len(bounds) - 1):
        if bounds[i] - _EPS_T <= t_click <= bounds[i + 1] + _EPS_T:
            lo, hi = bounds[i], bounds[i + 1]
            break

    end_a, end_b = line.a, line.b
    if lo > _EPS_T:
        p_lo = model.add_point(a[0] + dx * lo, a[1] + dy * lo,
                               merge_eps=_MERGE_EPS)
        if p_lo != end_a:
            model.add_line(end_a, p_lo)
    if hi < 1.0 - _EPS_T:
        p_hi = model.add_point(a[0] + dx * hi, a[1] + dy * hi,
                               merge_eps=_MERGE_EPS)
        if p_hi != end_b:
            model.add_line(p_hi, end_b)
    model.delete_entities({eid})
    return True


def _trim_circle(model, eid, click):
    circle = model.circles[eid]
    center = _pt(model, circle.center)
    angles = _circle_cuts(model, center, circle.radius, exclude=eid)
    if len(angles) < 2:
        model.delete_entities({eid})
        return True

    a_click = math.atan2(click[1] - center[1], click[0] - center[0]) % _TAU
    lo = hi = None
    n = len(angles)
    for i in range(n):
        lo_c, hi_c = angles[i], angles[(i + 1) % n]
        span = (hi_c - lo_c) % _TAU
        if span <= 1e-12:
            span = _TAU
        if (a_click - lo_c) % _TAU <= span:
            lo, hi = lo_c, hi_c
            break
    if lo is None:
        return False

    radius = circle.radius
    p_start = model.add_point(center[0] + radius * math.cos(hi),
                              center[1] + radius * math.sin(hi),
                              merge_eps=_MERGE_EPS)
    p_end = model.add_point(center[0] + radius * math.cos(lo),
                            center[1] + radius * math.sin(lo),
                            merge_eps=_MERGE_EPS)
    if p_start != p_end and circle.center not in (p_start, p_end):
        model.add_arc(circle.center, p_start, p_end)
    model.delete_entities({eid})
    return True


def _trim_arc(model, eid, click):
    arc = model.arcs[eid]
    center = _pt(model, arc.center)
    start = _pt(model, arc.start)
    end = _pt(model, arc.end)
    radius = math.hypot(start[0] - center[0], start[1] - center[1])
    theta0 = math.atan2(start[1] - center[1], start[0] - center[0])
    sweep = geom.arc_sweep(center, start, end)

    rel = [(ang - theta0) % _TAU
           for ang in _circle_cuts(model, center, radius, exclude=eid)]
    cuts = _dedup_sorted([x for x in rel if 1e-9 < x < sweep - 1e-9])
    bounds = [0.0] + cuts + [sweep]

    a_click = (math.atan2(click[1] - center[1], click[0] - center[0])
               - theta0) % _TAU
    a_click = min(a_click, sweep)
    lo, hi = 0.0, sweep
    for i in range(len(bounds) - 1):
        if bounds[i] - 1e-9 <= a_click <= bounds[i + 1] + 1e-9:
            lo, hi = bounds[i], bounds[i + 1]
            break

    def point_at(rel_ang):
        ang = theta0 + rel_ang
        return (center[0] + radius * math.cos(ang),
                center[1] + radius * math.sin(ang))

    if lo > 1e-9:
        p = model.add_point(*point_at(lo), merge_eps=_MERGE_EPS)
        if p not in (arc.start, arc.center):
            model.add_arc(arc.center, arc.start, p)
    if hi < sweep - 1e-9:
        p = model.add_point(*point_at(hi), merge_eps=_MERGE_EPS)
        if p not in (arc.end, arc.center):
            model.add_arc(arc.center, p, arc.end)
    model.delete_entities({eid})
    return True
