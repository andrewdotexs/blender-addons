"""Intersezioni tra entità dello sketch — Python puro.

Primitive geometriche condivise (usate anche dal trim) e la query delle
intersezioni del modello per lo snap.
"""

import math
from dataclasses import dataclass

from . import geom

_EPS = 1e-9
_TAU = 2.0 * math.pi

LINE = 'LINE'
CIRCLE = 'CIRCLE'
ARC = 'ARC'


def seg_seg_params(a1, b1, a2, b2):
    """(t1, t2) dell'intersezione tra le rette dei segmenti, o None."""
    d1x, d1y = b1[0] - a1[0], b1[1] - a1[1]
    d2x, d2y = b2[0] - a2[0], b2[1] - a2[1]
    det = d1x * d2y - d1y * d2x
    if abs(det) < 1e-12:
        return None
    rx, ry = a2[0] - a1[0], a2[1] - a1[1]
    t1 = (rx * d2y - ry * d2x) / det
    t2 = (rx * d1y - ry * d1x) / det
    return t1, t2


def seg_circle_params(a, b, center, radius):
    """Parametri t sulla retta di (a, b) dove interseca il cerchio."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    fx, fy = a[0] - center[0], a[1] - center[1]
    qa = dx * dx + dy * dy
    if qa < 1e-18:
        return []
    qb = 2.0 * (fx * dx + fy * dy)
    qc = fx * fx + fy * fy - radius * radius
    disc = qb * qb - 4.0 * qa * qc
    if disc < 0.0:
        return []
    s = math.sqrt(disc)
    ts = [(-qb - s) / (2.0 * qa), (-qb + s) / (2.0 * qa)]
    return ts if s > 1e-12 else ts[:1]  # tangente: un solo punto


def circle_circle_points(c1, r1, c2, r2):
    """Punti di intersezione tra due cerchi (0, 1 o 2)."""
    dx, dy = c2[0] - c1[0], c2[1] - c1[1]
    d = math.hypot(dx, dy)
    if d < 1e-12 or d > r1 + r2 + 1e-12 or d < abs(r1 - r2) - 1e-12:
        return []
    a = (r1 * r1 - r2 * r2 + d * d) / (2.0 * d)
    h = math.sqrt(max(0.0, r1 * r1 - a * a))
    mx, my = c1[0] + a * dx / d, c1[1] + a * dy / d
    if h < 1e-12:
        return [(mx, my)]
    ox, oy = -dy / d * h, dx / d * h
    return [(mx + ox, my + oy), (mx - ox, my - oy)]


def on_arc(model, arc, p):
    """True se il punto p (sul cerchio portante) cade dentro lo sweep dell'arco."""
    center = _pt(model, arc.center)
    start = _pt(model, arc.start)
    end = _pt(model, arc.end)
    sweep = geom.arc_sweep(center, start, end)
    ang = (math.atan2(p[1] - center[1], p[0] - center[0])
           - math.atan2(start[1] - center[1], start[0] - center[0])) % _TAU
    return ang <= sweep + 1e-9


def _pt(model, pid):
    p = model.points[pid]
    return (p.u, p.v)


def _circle_geom(model, kind, entity):
    """(centro, raggio) del cerchio portante di un CIRCLE o ARC."""
    if kind == CIRCLE:
        return _pt(model, entity.center), entity.radius
    center = _pt(model, entity.center)
    start = _pt(model, entity.start)
    return center, math.hypot(start[0] - center[0], start[1] - center[1])


@dataclass
class Intersection:
    co: tuple[float, float]
    a: tuple[str, int]  # (kind, id) della prima entità
    b: tuple[str, int]


def intersections(model) -> list[Intersection]:
    """Tutti i punti di intersezione tra coppie di entità del modello."""
    lines = list(model.lines.values())
    rounds = ([(CIRCLE, c) for c in model.circles.values()]
              + [(ARC, a) for a in model.arcs.values()])
    result: list[Intersection] = []

    def keep_on(kind, entity, p):
        return kind == CIRCLE or on_arc(model, entity, p)

    # linea × linea
    for i, la in enumerate(lines):
        a1, b1 = _pt(model, la.a), _pt(model, la.b)
        for lb in lines[i + 1:]:
            a2, b2 = _pt(model, lb.a), _pt(model, lb.b)
            r = seg_seg_params(a1, b1, a2, b2)
            if r is None:
                continue
            t1, t2 = r
            if -_EPS <= t1 <= 1.0 + _EPS and -_EPS <= t2 <= 1.0 + _EPS:
                co = (a1[0] + (b1[0] - a1[0]) * t1,
                      a1[1] + (b1[1] - a1[1]) * t1)
                result.append(Intersection(co, (LINE, la.id), (LINE, lb.id)))

    # linea × (cerchio | arco)
    for la in lines:
        a1, b1 = _pt(model, la.a), _pt(model, la.b)
        for kind, entity in rounds:
            center, radius = _circle_geom(model, kind, entity)
            for t in seg_circle_params(a1, b1, center, radius):
                if not (-_EPS <= t <= 1.0 + _EPS):
                    continue
                co = (a1[0] + (b1[0] - a1[0]) * t,
                      a1[1] + (b1[1] - a1[1]) * t)
                if keep_on(kind, entity, co):
                    result.append(
                        Intersection(co, (LINE, la.id), (kind, entity.id)))

    # (cerchio | arco) × (cerchio | arco)
    for i, (kind_a, ent_a) in enumerate(rounds):
        center_a, radius_a = _circle_geom(model, kind_a, ent_a)
        for kind_b, ent_b in rounds[i + 1:]:
            center_b, radius_b = _circle_geom(model, kind_b, ent_b)
            for co in circle_circle_points(center_a, radius_a,
                                           center_b, radius_b):
                if keep_on(kind_a, ent_a, co) and keep_on(kind_b, ent_b, co):
                    result.append(
                        Intersection(co, (kind_a, ent_a.id), (kind_b, ent_b.id)))

    return result
