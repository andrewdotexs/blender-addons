"""Candidati di snap del modello e vincoli automatici — Python puro.

I candidati dipendono solo dal modello (midpoint, quadranti, intersezioni);
gli snap dipendenti dal mouse (proiezioni su linea/cerchio, griglia) vivono
nello strato Blender. apply_constraints crea i vincoli che rendono lo snap
topologico: il punto resta agganciato quando il solver muove la geometria.
"""

import math
from dataclasses import dataclass

from . import constraints as C
from . import geom, intersect

# tipi di snap (kind)
POINT = 'POINT'
MID = 'MID'                  # punto medio di una linea
ARC_MID = 'ARC_MID'          # punto a metà di un arco
QUADRANT = 'QUADRANT'        # 0°/90°/180°/270° di cerchi e archi
INTERSECTION = 'INTERSECTION'
EDGE = 'EDGE'                # proiezione su una linea
ON_CIRCLE = 'ON_CIRCLE'      # proiezione su cerchio/arco
GRID = 'GRID'

LABELS = {
    POINT: "punto",
    MID: "punto medio",
    ARC_MID: "metà arco",
    QUADRANT: "quadrante",
    INTERSECTION: "intersezione",
    EDGE: "su linea",
    ON_CIRCLE: "su cerchio",
    GRID: "griglia",
}


@dataclass
class SnapCandidate:
    co: tuple[float, float]
    kind: str
    targets: list[tuple[str, int]]  # entità per i vincoli automatici


def candidates(model, exclude=None) -> list[SnapCandidate]:
    """Candidati di snap del modello (senza punti: hanno priorità a parte).

    exclude: insieme di id entità da ignorare (es. le entità incidenti al
    punto trascinato).
    """
    exclude = exclude or set()
    result: list[SnapCandidate] = []

    for line in model.lines.values():
        if line.id in exclude:
            continue
        pa = model.points.get(line.a)
        pb = model.points.get(line.b)
        if pa is None or pb is None:
            continue
        result.append(SnapCandidate(
            ((pa.u + pb.u) / 2, (pa.v + pb.v) / 2), MID, [('LINE', line.id)]))

    for circle in model.circles.values():
        if circle.id in exclude:
            continue
        center = model.points.get(circle.center)
        if center is None or circle.radius < 1e-9:
            continue
        for dx, dy in ((1, 0), (0, 1), (-1, 0), (0, -1)):
            result.append(SnapCandidate(
                (center.u + dx * circle.radius, center.v + dy * circle.radius),
                QUADRANT, [('CIRCLE', circle.id)]))

    for arc in model.arcs.values():
        if arc.id in exclude:
            continue
        center = model.points.get(arc.center)
        start = model.points.get(arc.start)
        end = model.points.get(arc.end)
        if center is None or start is None or end is None:
            continue
        c = (center.u, center.v)
        s = (start.u, start.v)
        radius = math.hypot(s[0] - c[0], s[1] - c[1])
        if radius < 1e-9:
            continue
        theta0 = math.atan2(s[1] - c[1], s[0] - c[0])
        sweep = geom.arc_sweep(c, s, (end.u, end.v))
        # metà arco
        mid_angle = theta0 + sweep / 2
        result.append(SnapCandidate(
            (c[0] + radius * math.cos(mid_angle),
             c[1] + radius * math.sin(mid_angle)),
            ARC_MID, [('ARC', arc.id)]))
        # quadranti dentro lo sweep
        for k in range(4):
            ang = k * math.pi / 2
            rel = (ang - theta0) % (2 * math.pi)
            if 1e-9 < rel < sweep - 1e-9:
                result.append(SnapCandidate(
                    (c[0] + radius * math.cos(ang),
                     c[1] + radius * math.sin(ang)),
                    QUADRANT, [('ARC', arc.id)]))

    for hit in intersect.intersections(model):
        if hit.a[1] in exclude or hit.b[1] in exclude:
            continue
        result.append(SnapCandidate(hit.co, INTERSECTION, [hit.a, hit.b]))

    return result


def _constraint_for(target):
    kind, eid = target
    if kind == 'LINE':
        return C.POINT_ON_LINE, eid
    return C.POINT_ON_CIRCLE, eid  # CIRCLE e ARC


def apply_constraints(model, point_id, kind, targets) -> int:
    """Crea i vincoli che corrispondono allo snap; ritorna quanti creati.

    MID lega al punto medio della linea; gli altri snap su entità legano
    il punto all'entità (su linea / su cerchio). Vincoli non applicabili
    (es. il punto è un estremo dell'entità stessa) vengono saltati.
    """
    created = 0
    for target in targets or []:
        if kind == MID and target[0] == 'LINE':
            ctype, eid = C.MIDPOINT, target[1]
        else:
            ctype, eid = _constraint_for(target)
        try:
            model.add_constraint(ctype, point_id, eid)
            created += 1
        except (KeyError, ValueError):
            continue
    return created
