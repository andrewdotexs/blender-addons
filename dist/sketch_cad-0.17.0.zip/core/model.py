"""Modello dati 2D dello sketch.

Le entità vivono nel piano (u, v) dello sketch e si riferiscono tra loro
per id intero, mai per riferimento diretto: gli id sono stabili attraverso
la serializzazione nei PropertyGroup di Blender e, in futuro, verso il solver.
"""

from dataclasses import dataclass

from . import expr
from .constraints import (CIRCULAR_TYPES, COINCIDENT, CURVE_LINE_TYPES,
                          LINE_LINE_TYPES, POINT_CIRCULAR_TYPES,
                          POINT_LINE_TYPES, POINT_POINT_TYPES, POINT_TYPES,
                          TYPES, Constraint)


@dataclass
class Point:
    id: int
    u: float
    v: float


@dataclass
class Line:
    id: int
    a: int  # id del punto iniziale
    b: int  # id del punto finale


@dataclass
class Circle:
    id: int
    center: int     # id del punto centro
    radius: float


@dataclass
class Arc:
    id: int
    center: int  # id punto centro
    start: int   # id punto iniziale
    end: int     # id punto finale (percorso CCW da start a end)


@dataclass
class Cubic:
    id: int
    p1: int  # ancora iniziale
    c1: int  # maniglia di p1
    c2: int  # maniglia di p2
    p2: int  # ancora finale


class SketchModel:
    """Contenitore runtime delle entità di uno sketch."""

    def __init__(self):
        self.points: dict[int, Point] = {}
        self.lines: dict[int, Line] = {}
        self.circles: dict[int, Circle] = {}
        self.arcs: dict[int, Arc] = {}
        self.cubics: dict[int, Cubic] = {}
        self.constraints: dict[int, Constraint] = {}
        self.selection: set[int] = set()  # id delle entità selezionate
        self.next_id: int = 1

    def _new_id(self) -> int:
        new_id = self.next_id
        self.next_id += 1
        return new_id

    def add_point(self, u: float, v: float, *, merge_eps: float | None = None) -> int:
        """Aggiunge un punto e ne ritorna l'id.

        Con merge_eps, se esiste già un punto entro quella distanza viene
        riusato il suo id invece di crearne uno nuovo (merge degli endpoint).
        """
        if merge_eps is not None:
            existing = self.closest_point(u, v, merge_eps)
            if existing is not None:
                return existing
        pid = self._new_id()
        self.points[pid] = Point(pid, u, v)
        return pid

    def add_line(self, a: int, b: int) -> int | None:
        """Aggiunge un segmento tra due punti esistenti e ne ritorna l'id.

        Ritorna None per segmenti degeneri (a == b); se la coppia di punti
        è già collegata ritorna l'id della linea esistente.
        """
        if a == b:
            return None
        if a not in self.points or b not in self.points:
            raise KeyError(f"Punto inesistente: {a if a not in self.points else b}")
        for line in self.lines.values():
            if {line.a, line.b} == {a, b}:
                return line.id
        lid = self._new_id()
        self.lines[lid] = Line(lid, a, b)
        return lid

    def add_circle(self, center: int, radius: float) -> int:
        """Aggiunge un cerchio con centro in un punto esistente."""
        if center not in self.points:
            raise KeyError(f"Punto inesistente: {center}")
        if radius <= 1e-9:
            raise ValueError("Il raggio deve essere positivo")
        cid = self._new_id()
        self.circles[cid] = Circle(cid, center, radius)
        return cid

    def add_arc(self, center: int, start: int, end: int) -> int:
        """Aggiunge un arco CCW da start a end attorno a center."""
        for pid in (center, start, end):
            if pid not in self.points:
                raise KeyError(f"Punto inesistente: {pid}")
        if len({center, start, end}) != 3:
            raise ValueError("L'arco richiede tre punti distinti")
        aid = self._new_id()
        self.arcs[aid] = Arc(aid, center, start, end)
        return aid

    def add_cubic(self, p1: int, c1: int, c2: int, p2: int) -> int:
        """Aggiunge una curva di Bézier (ancore p1/p2, maniglie c1/c2)."""
        for pid in (p1, c1, c2, p2):
            if pid not in self.points:
                raise KeyError(f"Punto inesistente: {pid}")
        if p1 == p2:
            raise ValueError("La curva richiede ancore distinte")
        cid = self._new_id()
        self.cubics[cid] = Cubic(cid, p1, c1, c2, p2)
        return cid

    def add_constraint(self, ctype: str, a: int, b: int = 0, *, value: float = 0.0) -> int:
        """Aggiunge un vincolo e ne ritorna l'id.

        Per COINCIDENT a e b sono id di punti; per i vincoli a due linee
        (PARALLEL, PERPENDICULAR, EQUAL_LENGTH, ANGLE) a e b sono id di
        linee; per gli altri tipi a è l'id della linea vincolata.
        Un duplicato esatto (stesso tipo sulle stesse entità) ritorna
        l'id del vincolo esistente.
        """
        if ctype not in TYPES:
            raise ValueError(f"Tipo vincolo sconosciuto: {ctype}")
        if ctype in POINT_POINT_TYPES:
            if a not in self.points or b not in self.points:
                raise KeyError(f"Punto inesistente: {a if a not in self.points else b}")
            if a == b:
                raise ValueError(f"{ctype} richiede due punti distinti")
        elif ctype in LINE_LINE_TYPES:
            if a not in self.lines or b not in self.lines:
                raise KeyError(f"Linea inesistente: {a if a not in self.lines else b}")
            if a == b:
                raise ValueError(f"{ctype} richiede due linee distinte")
        elif ctype in CIRCULAR_TYPES:
            if a not in self.circles and a not in self.arcs:
                raise KeyError(f"Cerchio o arco inesistente: {a}")
        elif ctype in POINT_LINE_TYPES:
            if a not in self.points:
                raise KeyError(f"Punto inesistente: {a}")
            if b not in self.lines:
                raise KeyError(f"Linea inesistente: {b}")
            line = self.lines[b]
            if a in (line.a, line.b):
                raise ValueError(
                    f"{ctype}: il punto non può essere un estremo della linea stessa")
        elif ctype in POINT_CIRCULAR_TYPES:
            if a not in self.points:
                raise KeyError(f"Punto inesistente: {a}")
            if b in self.circles:
                if a == self.circles[b].center:
                    raise ValueError(
                        f"{ctype}: il centro non può stare sul proprio cerchio")
            elif b in self.arcs:
                arc = self.arcs[b]
                if a in (arc.center, arc.start, arc.end):
                    raise ValueError(
                        f"{ctype}: il punto appartiene già all'arco")
            else:
                raise KeyError(f"Cerchio o arco inesistente: {b}")
        elif ctype in CURVE_LINE_TYPES:
            if b not in self.lines:
                raise KeyError(f"Linea inesistente: {b}")
            line = self.lines[b]
            if a in self.arcs:
                arc = self.arcs[a]
                shared = {arc.start, arc.end} & {line.a, line.b}
            elif a in self.cubics:
                cubic = self.cubics[a]
                shared = {cubic.p1, cubic.p2} & {line.a, line.b}
            else:
                raise KeyError(f"Arco o curva inesistente: {a}")
            if not shared:
                raise ValueError(
                    "Tangente: la curva e la linea devono condividere un estremo")
        elif ctype in POINT_TYPES:
            if a not in self.points:
                raise KeyError(f"Punto inesistente: {a}")
        else:
            if a not in self.lines:
                raise KeyError(f"Linea inesistente: {a}")
        for c in self.constraints.values():
            if c.type == ctype and {c.a, c.b} == {a, b}:
                return c.id
        cid = self._new_id()
        self.constraints[cid] = Constraint(cid, ctype, a, b, value)
        return cid

    def remove_constraint(self, cid: int) -> None:
        self.constraints.pop(cid, None)

    def apply_parameters(self, parameters: dict[str, float]) -> int:
        """Valuta le espressioni delle quote legate; ritorna quante aggiornate.

        c.param è un'espressione (un nome di parametro è il caso degenere).
        Espressioni non valutabili (parametro sparito, errore) lasciano il
        valore corrente: una tabella incompleta non rompe la geometria.
        """
        count = 0
        for c in self.constraints.values():
            if not c.param:
                continue
            try:
                c.value = expr.evaluate(c.param, parameters)
                count += 1
            except expr.ExprError:
                continue
        return count

    def unbind_parameter(self, name: str) -> int:
        """Slega le quote la cui espressione usa il parametro (il valore resta)."""
        count = 0
        for c in self.constraints.values():
            if not c.param:
                continue
            try:
                refers = name in expr.parse_names(c.param)
            except expr.ExprError:
                refers = c.param == name
            if refers:
                c.param = ""
                count += 1
        return count

    def rename_parameter(self, old: str, new: str) -> int:
        """Aggiorna le espressioni delle quote dopo il rename di un parametro."""
        count = 0
        for c in self.constraints.values():
            if not c.param:
                continue
            renamed = expr.rename_in_expression(c.param, old, new)
            if renamed != c.param:
                c.param = renamed
                count += 1
        return count

    def delete_entities(self, ids: set[int]) -> tuple[int, int, int]:
        """Rimuove entità (punti, linee, cerchi, archi) a cascata; id ignoti ignorati.

        Cascata: un punto cancellato trascina le geometrie che lo usano
        (linee, cerchi per centro, archi per centro/start/end); i punti
        delle geometrie cancellate spariscono se nessun'altra geometria
        li usa; i vincoli che riferiscono entità rimosse vengono rimossi.
        Ritorna (punti, geometrie, vincoli) rimossi.
        """
        doomed_points = {i for i in ids if i in self.points}
        doomed_lines = {i for i in ids if i in self.lines}
        doomed_circles = {i for i in ids if i in self.circles}
        doomed_arcs = {i for i in ids if i in self.arcs}
        doomed_cubics = {i for i in ids if i in self.cubics}
        doomed_lines |= {
            line.id for line in self.lines.values()
            if line.a in doomed_points or line.b in doomed_points
        }
        doomed_circles |= {
            c.id for c in self.circles.values() if c.center in doomed_points
        }
        doomed_arcs |= {
            a.id for a in self.arcs.values()
            if a.center in doomed_points or a.start in doomed_points
            or a.end in doomed_points
        }
        doomed_cubics |= {
            q.id for q in self.cubics.values()
            if doomed_points & {q.p1, q.c1, q.c2, q.p2}
        }

        orphan_candidates: set[int] = set()
        for lid in doomed_lines:
            line = self.lines.pop(lid)
            orphan_candidates.update((line.a, line.b))
        for cid in doomed_circles:
            orphan_candidates.add(self.circles.pop(cid).center)
        for aid in doomed_arcs:
            arc = self.arcs.pop(aid)
            orphan_candidates.update((arc.center, arc.start, arc.end))
        for qid in doomed_cubics:
            cubic = self.cubics.pop(qid)
            orphan_candidates.update((cubic.p1, cubic.c1, cubic.c2, cubic.p2))

        still_used = set()
        for line in self.lines.values():
            still_used.update((line.a, line.b))
        for circle in self.circles.values():
            still_used.add(circle.center)
        for arc in self.arcs.values():
            still_used.update((arc.center, arc.start, arc.end))
        for cubic in self.cubics.values():
            still_used.update((cubic.p1, cubic.c1, cubic.c2, cubic.p2))
        doomed_points |= orphan_candidates - still_used

        for pid in doomed_points:
            self.points.pop(pid, None)

        doomed_constraints = set()
        for c in self.constraints.values():
            if c.type == COINCIDENT:
                if c.a not in self.points or c.b not in self.points:
                    doomed_constraints.add(c.id)
            elif c.type in LINE_LINE_TYPES:
                if c.a not in self.lines or c.b not in self.lines:
                    doomed_constraints.add(c.id)
            elif c.type in CIRCULAR_TYPES:
                if c.a not in self.circles and c.a not in self.arcs:
                    doomed_constraints.add(c.id)
            elif c.type in POINT_LINE_TYPES:
                if c.a not in self.points or c.b not in self.lines:
                    doomed_constraints.add(c.id)
            elif c.type in POINT_CIRCULAR_TYPES:
                if c.a not in self.points or (c.b not in self.circles
                                              and c.b not in self.arcs):
                    doomed_constraints.add(c.id)
            elif c.type in CURVE_LINE_TYPES:
                if (c.a not in self.arcs and c.a not in self.cubics) \
                        or c.b not in self.lines:
                    doomed_constraints.add(c.id)
            elif c.type in POINT_TYPES:
                if c.a not in self.points:
                    doomed_constraints.add(c.id)
            elif c.a not in self.lines:
                doomed_constraints.add(c.id)
        for cid in doomed_constraints:
            del self.constraints[cid]

        doomed_geometry = (doomed_lines | doomed_circles | doomed_arcs
                           | doomed_cubics)
        self.selection -= doomed_points | doomed_geometry | doomed_constraints
        return len(doomed_points), len(doomed_geometry), len(doomed_constraints)

    def closest_point(self, u: float, v: float, max_dist: float) -> int | None:
        """Id del punto più vicino a (u, v) entro max_dist, o None."""
        best = None
        best_d2 = max_dist * max_dist
        for p in self.points.values():
            d2 = (p.u - u) ** 2 + (p.v - v) ** 2
            if d2 <= best_d2:
                best = p.id
                best_d2 = d2
        return best
