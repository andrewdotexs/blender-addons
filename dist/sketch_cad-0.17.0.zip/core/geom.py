"""Discretizzazione di archi e cerchi e utilità geometriche — Python puro.

Convenzione archi: percorsi in senso antiorario (CCW) da start a end
attorno al centro, raggio = |start - center| (come SolveSpace).
"""

import math

Vec2 = tuple[float, float]


def polygon_area(points: list[Vec2]) -> float:
    """Area con segno (shoelace): positiva se il poligono è antiorario."""
    area = 0.0
    n = len(points)
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return area / 2.0


def arc_sweep(center: Vec2, start: Vec2, end: Vec2) -> float:
    """Angolo CCW percorso dall'arco, in radianti [0, 2π)."""
    t1 = math.atan2(start[1] - center[1], start[0] - center[0])
    t2 = math.atan2(end[1] - center[1], end[0] - center[0])
    return (t2 - t1) % (2.0 * math.pi)


def arc_points(center: Vec2, start: Vec2, end: Vec2,
               max_step_deg: float = 8.0) -> list[Vec2]:
    """Punti dell'arco CCW da start a end, estremi inclusi ed esatti.

    Se start ed end non sono allo stesso raggio (sketch non risolto),
    l'arco viene tracciato al raggio di start e l'ultimo punto forzato
    su end per mantenere la continuità visiva del bordo.
    """
    cx, cy = center
    radius = math.hypot(start[0] - cx, start[1] - cy)
    if radius < 1e-12:
        return [tuple(start), tuple(end)]
    t1 = math.atan2(start[1] - cy, start[0] - cx)
    sweep = arc_sweep(center, start, end)
    steps = max(2, math.ceil(math.degrees(sweep) / max_step_deg))
    pts = [
        (cx + radius * math.cos(t1 + sweep * i / steps),
         cy + radius * math.sin(t1 + sweep * i / steps))
        for i in range(steps + 1)
    ]
    pts[0] = tuple(start)
    pts[-1] = tuple(end)
    return pts


def cubic_points(p1: Vec2, c1: Vec2, c2: Vec2, p2: Vec2,
                 steps: int = 24) -> list[Vec2]:
    """Punti della cubica di Bézier (Bernstein), estremi inclusi ed esatti."""
    pts = []
    for i in range(steps + 1):
        t = i / steps
        mt = 1.0 - t
        a = mt * mt * mt
        b = 3.0 * mt * mt * t
        c = 3.0 * mt * t * t
        d = t * t * t
        pts.append((a * p1[0] + b * c1[0] + c * c2[0] + d * p2[0],
                    a * p1[1] + b * c1[1] + c * c2[1] + d * p2[1]))
    pts[0] = tuple(p1)
    pts[-1] = tuple(p2)
    return pts


def circle_points(center: Vec2, radius: float, steps: int = 48) -> list[Vec2]:
    """Punti del cerchio in CCW, senza ripetere il primo."""
    cx, cy = center
    return [
        (cx + radius * math.cos(2.0 * math.pi * i / steps),
         cy + radius * math.sin(2.0 * math.pi * i / steps))
        for i in range(steps)
    ]
