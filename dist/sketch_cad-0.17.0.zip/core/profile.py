"""Riconoscimento dei profili chiusi (loop) nel grafo dello sketch.

Il grafo è un multigrafo: gli edge sono linee e archi (tra start ed end;
il centro dell'arco non fa parte del bordo). Vengono riconosciuti i cicli
semplici — componenti connesse in cui ogni punto ha grado 2 dopo la
potatura delle code — inclusi i loop di due soli punti (linea+arco, due
archi). I cerchi sono profili a sé e non passano da qui.

Limiti correnti: punti di incrocio con grado > 2 e fori (loop annidati)
arriveranno con trim/booleane.
"""

from dataclasses import dataclass

from . import geom
from .model import SketchModel

LINE = 'LINE'
ARC = 'ARC'
CUBIC = 'CUBIC'


@dataclass
class Loop:
    points: list[int]             # vertici del bordo in ordine
    edges: list[tuple[str, int]]  # edges[i] collega points[i] → points[(i+1) % n]


def signed_area(model: SketchModel, point_ids: list[int]) -> float:
    """Area con segno del poligono dei vertici (shoelace, archi come corde)."""
    return geom.polygon_area([(model.points[p].u, model.points[p].v)
                              for p in point_ids])


def find_closed_loops(model: SketchModel) -> list[Loop]:
    """Ritorna i cicli semplici del grafo linee+archi.

    Ogni loop parte dal punto con id minimo; l'orientamento NON è
    normalizzato (lo fa tessellate_loop sulla geometria reale).
    """
    # multigrafo: nodo → [(altro_nodo, kind, edge_id)]
    adjacency: dict[int, list[tuple[int, str, int]]] = {}

    def add_edge(kind, eid, a, b):
        adjacency.setdefault(a, []).append((b, kind, eid))
        adjacency.setdefault(b, []).append((a, kind, eid))

    for line in model.lines.values():
        add_edge(LINE, line.id, line.a, line.b)
    for arc in model.arcs.values():
        add_edge(ARC, arc.id, arc.start, arc.end)
    for cubic in model.cubics.values():
        add_edge(CUBIC, cubic.id, cubic.p1, cubic.p2)

    # potatura iterativa delle foglie (code, segmenti appesi)
    leaves = [n for n, edges in adjacency.items() if len(edges) <= 1]
    while leaves:
        node = leaves.pop()
        edges = adjacency.pop(node, None)
        if edges is None:
            continue
        for other, _kind, eid in edges:
            remaining = adjacency.get(other)
            if remaining is None:
                continue
            remaining[:] = [e for e in remaining if e[2] != eid]
            if len(remaining) <= 1:
                leaves.append(other)

    loops: list[Loop] = []
    visited: set[int] = set()
    for start in sorted(adjacency):
        if start in visited:
            continue
        component: set[int] = set()
        stack = [start]
        degree_ok = True
        while stack:
            node = stack.pop()
            if node in component:
                continue
            component.add(node)
            if len(adjacency[node]) != 2:
                degree_ok = False
            stack.extend(other for other, _k, _e in adjacency[node]
                         if other not in component)
        visited |= component
        if not degree_ok or len(component) < 2:
            continue  # incroci (grado != 2): ambiguo, non gestito

        # percorri il ciclo senza riusare gli edge (gestisce i multigrafi)
        first = min(component)
        first_edge = min(adjacency[first], key=lambda e: e[2])
        used_edges = {first_edge[2]}
        loop_points = [first]
        loop_edges = [(first_edge[1], first_edge[2])]
        current = first_edge[0]
        while current != first:
            loop_points.append(current)
            other, kind, eid = next(
                e for e in adjacency[current] if e[2] not in used_edges)
            used_edges.add(eid)
            loop_edges.append((kind, eid))
            current = other
        loops.append(Loop(loop_points, loop_edges))

    return loops


def tessellate_loop(model: SketchModel, loop: Loop) -> list[tuple[float, float]]:
    """Coordinate del bordo del loop, archi discretizzati, antiorario.

    L'orientamento viene normalizzato sulla geometria tessellata (area
    positiva → normale della faccia verso +Z), che resta corretto anche
    per loop di due punti dove il poligono dei vertici è degenere.
    """
    coords: list[tuple[float, float]] = []
    count = len(loop.points)
    for i, pid in enumerate(loop.points):
        p = model.points[pid]
        coords.append((p.u, p.v))
        kind, eid = loop.edges[i]
        if kind == ARC:
            arc = model.arcs[eid]
            center = model.points[arc.center]
            start = model.points[arc.start]
            end = model.points[arc.end]
            pts = geom.arc_points((center.u, center.v), (start.u, start.v),
                                  (end.u, end.v))
            if pid == arc.end:  # arco percorso al contrario nel loop
                pts = pts[::-1]
            coords.extend(pts[1:-1])  # gli estremi sono già vertici del loop
        elif kind == CUBIC:
            cubic = model.cubics[eid]
            pts = geom.cubic_points(
                *((model.points[q].u, model.points[q].v)
                  for q in (cubic.p1, cubic.c1, cubic.c2, cubic.p2)))
            if pid == cubic.p2:  # curva percorsa al contrario nel loop
                pts = pts[::-1]
            coords.extend(pts[1:-1])
    if count and geom.polygon_area(coords) < 0:
        coords.reverse()
    return coords