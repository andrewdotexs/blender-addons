"""Picking screen-space delle entità sketch e proiezione mouse → piano."""

from bpy_extras import view3d_utils
from mathutils import Vector
from mathutils.geometry import intersect_line_plane

from .core import dims, geom


def mouse_to_plane(context, event, obj):
    """Proietta il mouse sul piano XY locale dello sketch → (u, v) o None."""
    region = context.region
    rv3d = context.region_data
    coord = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

    mw = obj.matrix_world
    plane_co = mw.translation
    plane_no = mw.col[2].to_3d().normalized()
    hit = intersect_line_plane(origin, origin + direction, plane_co, plane_no)
    if hit is None or (hit - origin).dot(direction) <= 0.0:
        return None  # vista parallela al piano, o piano dietro la camera
    local = mw.inverted() @ hit
    return (local.x, local.y)


def point_under_mouse(context, event, obj, model, max_px=14.0):
    """Id del punto del modello entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for p in model.points.values():
        world = mw @ Vector((p.u, p.v, 0.0))
        screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
        if screen is None:
            continue
        d = (screen - mouse).length
        if d < best_d:
            best = p.id
            best_d = d
    return best


def line_under_mouse(context, event, obj, model, max_px=10.0):
    """Id della linea del modello entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for line in model.lines.values():
        pa = model.points.get(line.a)
        pb = model.points.get(line.b)
        if pa is None or pb is None:
            continue
        sa = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((pa.u, pa.v, 0.0)))
        sb = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((pb.u, pb.v, 0.0)))
        if sa is None or sb is None:
            continue
        d = _dist_point_segment(mouse, sa, sb)
        if d < best_d:
            best = line.id
            best_d = d
    return best


def circular_under_mouse(context, event, obj, model, max_px=10.0):
    """Id del cerchio o arco entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world

    def polyline_distance(pts2d, closed):
        screen_pts = []
        for u, v in pts2d:
            s = view3d_utils.location_3d_to_region_2d(
                region, rv3d, mw @ Vector((u, v, 0.0)))
            if s is None:
                return None
            screen_pts.append(s)
        if closed:
            screen_pts.append(screen_pts[0])
        return min(_dist_point_segment(mouse, a, b)
                   for a, b in zip(screen_pts, screen_pts[1:]))

    best = None
    best_d = max_px
    for circle in model.circles.values():
        center = model.points.get(circle.center)
        if center is None or circle.radius < 1e-9:
            continue
        d = polyline_distance(
            geom.circle_points((center.u, center.v), circle.radius, 32), True)
        if d is not None and d < best_d:
            best, best_d = circle.id, d
    for arc in model.arcs.values():
        center = model.points.get(arc.center)
        start = model.points.get(arc.start)
        end = model.points.get(arc.end)
        if center is None or start is None or end is None:
            continue
        d = polyline_distance(
            geom.arc_points((center.u, center.v), (start.u, start.v),
                            (end.u, end.v)), False)
        if d is not None and d < best_d:
            best, best_d = arc.id, d
    return best


def dimension_under_mouse(context, event, obj, model, max_px=18.0):
    """Id del vincolo la cui quota (testo) è entro max_px dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for cid, layout in dims.iter_layouts(model):
        world = mw @ Vector((layout.text_pos[0], layout.text_pos[1], 0.0))
        screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
        if screen is None:
            continue
        d = (screen - mouse).length
        if d < best_d:
            best = cid
            best_d = d
    return best


def _dist_point_segment(p, a, b):
    ab = b - a
    if ab.length_squared == 0.0:
        return (p - a).length
    t = max(0.0, min(1.0, (p - a).dot(ab) / ab.length_squared))
    return (p - (a + ab * t)).length
