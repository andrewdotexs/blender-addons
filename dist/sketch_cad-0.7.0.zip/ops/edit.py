"""Editing dello sketch: selezione, cancellazione e trascinamento punti."""

import bpy

from .. import convert, pick, props
from ..core import solver


def _delete_selection(obj) -> tuple[int, int, int] | None:
    """Cancella le entità selezionate; None se la selezione è vuota."""
    model = props.load_model(obj)
    if not model.selection:
        return None
    counts = model.delete_entities(model.selection)
    props.save_model(model, obj)
    convert.rebuild_profile_mesh(obj)
    return counts


class SKETCHCAD_OT_select(bpy.types.Operator):
    bl_idname = "sketch_cad.select"
    bl_label = "Seleziona"
    bl_description = (
        "Seleziona punti e linee: click (Shift estende, A tutto, click a "
        "vuoto azzera), X/Canc cancella la selezione, Esc esce"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set(
            "Click: seleziona | Shift+click: estendi | A: tutto | "
            "X/Canc: cancella | Esc: esci")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                self._click(context, event)
                return {'RUNNING_MODAL'}
            if event.type == 'A':
                model = props.load_model(self.obj)
                model.selection = (set(model.points) | set(model.lines)
                                   | set(model.circles) | set(model.arcs))
                props.save_model(model, self.obj)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}
            if event.type in {'X', 'DEL'}:
                counts = _delete_selection(self.obj)
                if counts is None:
                    self.report({'INFO'}, "Nessuna selezione")
                    return {'RUNNING_MODAL'}
                # chiudi il tool: la cancellazione resta un undo step pulito
                points, lines, constraints = counts
                self.report({'INFO'},
                            f"Rimossi {points} punti, {lines} linee, "
                            f"{constraints} vincoli")
                return self._finish(context, {'FINISHED'})
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish(context, {'FINISHED'})

        return {'RUNNING_MODAL'}

    def _click(self, context, event):
        model = props.load_model(self.obj)
        eid = pick.point_under_mouse(context, event, self.obj, model)
        if eid is None:
            eid = pick.line_under_mouse(context, event, self.obj, model)
        if eid is None:
            eid = pick.circular_under_mouse(context, event, self.obj, model)
        if event.shift:
            if eid is not None:
                model.selection.symmetric_difference_update({eid})  # toggle
        else:
            model.selection.clear()
            if eid is not None:
                model.selection.add(eid)
        props.save_model(model, self.obj)
        context.area.tag_redraw()

    def _finish(self, context, status):
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        return status


class SKETCHCAD_OT_delete_selected(bpy.types.Operator):
    bl_idname = "sketch_cad.delete_selected"
    bl_label = "Cancella selezionati"
    bl_description = (
        "Cancella le entità selezionate (a cascata: linee dei punti rimossi, "
        "punti rimasti orfani, vincoli che le riferiscono)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def execute(self, context):
        counts = _delete_selection(context.active_object)
        if counts is None:
            self.report({'WARNING'}, "Nessuna selezione")
            return {'CANCELLED'}
        points, lines, constraints = counts
        context.area.tag_redraw()
        self.report({'INFO'},
                    f"Rimossi {points} punti, {lines} linee, {constraints} vincoli")
        return {'FINISHED'}


class SKETCHCAD_OT_move_point(bpy.types.Operator):
    bl_idname = "sketch_cad.move_point"
    bl_label = "Muovi punto"
    bl_description = (
        "Trascina un punto dello sketch: i vincoli vengono risolti in tempo "
        "reale e la geometria segue"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        self.initial = props.load_model(self.obj)  # snapshot per Esc
        self.dragging_pid = None
        self.moved = False
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('SCROLL_XY')
        context.workspace.status_text_set(
            "Click su un punto e trascina | Rilascia: conferma | Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE' and self.dragging_pid is not None:
            target = pick.mouse_to_plane(context, event, self.obj)
            if target is not None:
                self._move_to(context, target)
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS' and self.dragging_pid is None:
                model = props.load_model(self.obj)
                self.dragging_pid = pick.point_under_mouse(
                    context, event, self.obj, model)
                return {'RUNNING_MODAL'}
            if event.value == 'RELEASE' and self.dragging_pid is not None:
                return self._finish(context, restore=False)

        if event.value == 'PRESS' and event.type in {'RIGHTMOUSE', 'ESC'}:
            return self._finish(context, restore=self.moved)

        return {'RUNNING_MODAL'}

    def _move_to(self, context, target):
        """Porta il punto trascinato verso target rispettando i vincoli.

        Se il solver rifiuta (es. drag oltre una distanza fissa) i props
        restano all'ultima soluzione valida: il punto "resiste".
        """
        if solver.available():
            result = convert.resolve_and_update(
                self.obj, dragged={self.dragging_pid: target})
            self.moved = self.moved or result.ok
        else:
            model = props.load_model(self.obj)
            if model.constraints:
                return  # senza solver non posso rispettare i vincoli: non muovo
            point = model.points[self.dragging_pid]
            point.u, point.v = target
            props.save_model(model, self.obj)
            convert.rebuild_profile_mesh(self.obj)
            self.moved = True
        context.area.tag_redraw()

    def _finish(self, context, *, restore):
        if restore:
            props.save_model(self.initial, self.obj)
            convert.rebuild_profile_mesh(self.obj)
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.moved and not restore:
            return {'FINISHED'}
        return {'CANCELLED'}


_classes = (
    SKETCHCAD_OT_select,
    SKETCHCAD_OT_delete_selected,
    SKETCHCAD_OT_move_point,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
