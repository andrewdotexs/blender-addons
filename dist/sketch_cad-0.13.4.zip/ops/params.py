"""Gestione dei parametri di scena (tabella nome → valore/espressione)."""

import bpy

from .. import props
from ..core import expr


def _sketches(scene):
    return [obj for obj in scene.objects if obj.sketch_cad.is_sketch]


class SKETCHCAD_OT_add_param(bpy.types.Operator):
    bl_idname = "sketch_cad.add_param"
    bl_label = "Aggiungi parametro"
    bl_description = "Aggiunge un parametro di scena utilizzabile dalle quote"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        params = context.scene.sketch_cad_params
        existing = {p.name for p in params}
        n = 1
        while f"param{n}" in existing:
            n += 1
        with props.suspended_updates():
            item = params.add()
            item.name = f"param{n}"
            item.value = 1.0
        return {'FINISHED'}


class SKETCHCAD_OT_remove_param(bpy.types.Operator):
    bl_idname = "sketch_cad.remove_param"
    bl_label = "Rimuovi parametro"
    bl_description = (
        "Rimuove il parametro; le quote che lo usano tornano a valore fisso "
        "(la geometria non cambia)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    param_name: bpy.props.StringProperty(options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        params = scene.sketch_cad_params
        index = next((i for i, p in enumerate(params)
                      if p.name == self.param_name), None)
        if index is None:
            return {'CANCELLED'}

        unbound = 0
        for obj in _sketches(scene):
            model = props.load_model(obj)
            count = model.unbind_parameter(self.param_name)
            if count:
                props.save_model(model, obj)
                unbound += count
        params.remove(index)
        props.refresh_parameters(scene)  # i derivati che lo usavano vanno in errore

        if unbound:
            self.report({'INFO'},
                        f"Parametro rimosso: {unbound} quote tornate a valore fisso")
        return {'FINISHED'}


class SKETCHCAD_OT_edit_param(bpy.types.Operator):
    bl_idname = "sketch_cad.edit_param"
    bl_label = "Modifica parametro"
    bl_description = (
        "Rinomina il parametro e/o lo definisce con un'espressione di altri "
        "parametri (es. base*2); il rename aggiorna tutte le quote e le "
        "espressioni che lo usano"
    )
    bl_options = {'REGISTER', 'UNDO'}

    old_name: bpy.props.StringProperty(options={'HIDDEN'})
    new_name: bpy.props.StringProperty(name="Nome")
    expression: bpy.props.StringProperty(
        name="Espressione",
        description="es. base*2 + 0.5 — vuoto = valore diretto")

    def invoke(self, context, event):
        target = next((p for p in context.scene.sketch_cad_params
                       if p.name == self.old_name), None)
        if target is None:
            return {'CANCELLED'}
        self.new_name = self.old_name
        self.expression = target.expression
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        target = next((p for p in scene.sketch_cad_params
                       if p.name == self.old_name), None)
        if target is None:
            return {'CANCELLED'}

        new = self.new_name.strip()
        expression = self.expression.strip()
        if not new.isidentifier():
            self.report({'ERROR'},
                        "Nome non valido: lettere, numeri e _ senza spazi")
            return {'CANCELLED'}
        if new != self.old_name and any(
                p.name == new for p in scene.sketch_cad_params):
            self.report({'ERROR'}, f"Esiste già un parametro '{new}'")
            return {'CANCELLED'}

        # prova di valutazione sulla tabella come risulterebbe dopo l'edit
        trial = props.raw_parameters(scene)
        del trial[self.old_name]
        trial[new] = (target.value, expression)
        if new != self.old_name:
            trial = {name: (val, expr.rename_in_expression(e, self.old_name, new))
                     for name, (val, e) in trial.items()}
        _values, errors = expr.resolve_parameters(trial)
        if new in errors:
            self.report({'ERROR'}, f"Espressione non valida: {errors[new]}")
            return {'CANCELLED'}

        with props.suspended_updates():
            target.name = new
            target.expression = (expr.rename_in_expression(
                expression, self.old_name, new) if new != self.old_name
                else expression)
            if new != self.old_name:
                for p in scene.sketch_cad_params:
                    if p != target and p.expression:
                        p.expression = expr.rename_in_expression(
                            p.expression, self.old_name, new)
        if new != self.old_name:
            for obj in _sketches(scene):
                model = props.load_model(obj)
                if model.rename_parameter(self.old_name, new):
                    props.save_model(model, obj)

        props.refresh_and_resolve(scene)
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_add_param,
    SKETCHCAD_OT_remove_param,
    SKETCHCAD_OT_edit_param,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
