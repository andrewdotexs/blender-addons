"""Operatori di Sketch CAD."""

from . import constrain, dimension, draw, edit, params, sketch, solidify

_modules = (
    sketch,
    draw,
    edit,
    constrain,
    dimension,
    params,
    solidify,
)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
