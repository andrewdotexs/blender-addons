"""Tool modali di disegno sullo sketch attivo."""

import math

import bpy
import gpu
from mathutils import Vector

from .. import convert, overlay, pick, props
from ..core import constraints as C
from ..core import geom, solver

SNAP_PX = 12.0   # raggio di aggancio agli endpoint esistenti, in pixel
GRID_STEP = 0.1  # passo della griglia (snap con Ctrl), in unità modello


class SKETCHCAD_OT_draw_line(bpy.types.Operator):
    bl_idname = "sketch_cad.draw_line"
    bl_label = "Disegna linee"
    bl_description = (
        "Disegna una polilinea sullo sketch attivo: click per aggiungere punti, "
        "click sul punto iniziale per chiudere, click destro/Invio/Esc per terminare"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}

        self.obj = context.active_object
        self.model = props.load_model(self.obj)
        self.first_pid = None    # primo punto della polilinea corrente
        self.prev_pid = None     # ultimo punto fissato
        self.preview_co = None   # (u, v) sotto il mouse
        self.snap_pid = None     # punto esistente agganciato
        self.snap_kind = None    # 'POINT' | 'MID' | 'EDGE' | 'GRID' | None
        self.snap_line = None    # linea dello snap MID/EDGE
        self.lines_added = 0

        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_preview, (self,), 'WINDOW', 'POST_VIEW')
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set(
            "Click: aggiungi punto | click sul punto iniziale: chiudi profilo | "
            "Ctrl: griglia | Click dx / Invio / Esc: termina")
        self._update_preview(context, event)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        # Navigazione viewport sempre libera
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE':
            self._update_preview(context, event)
            return {'RUNNING_MODAL'}

        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                if self._place_point():
                    return self._finish(context)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}
            if event.type in {'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'}:
                return self._finish(context)

        return {'RUNNING_MODAL'}

    def _update_preview(self, context, event):
        self.preview_co = pick.mouse_to_plane(context, event, self.obj)
        self.snap_pid = None
        self.snap_kind = None
        self.snap_line = None
        if self.preview_co is not None:
            self.snap_pid = pick.point_under_mouse(
                context, event, self.obj, self.model, SNAP_PX)
            if self.snap_pid is not None:
                p = self.model.points[self.snap_pid]
                self.preview_co = (p.u, p.v)
                self.snap_kind = 'POINT'
            else:
                hit = pick.midpoint_under_mouse(
                    context, event, self.obj, self.model, SNAP_PX)
                if hit is not None:
                    self.snap_line, self.preview_co = hit
                    self.snap_kind = 'MID'
                else:
                    hit = pick.line_projection_under_mouse(
                        context, event, self.obj, self.model, SNAP_PX * 0.75)
                    if hit is not None:
                        self.snap_line, self.preview_co = hit
                        self.snap_kind = 'EDGE'
                    elif event.ctrl:
                        self.preview_co = (
                            round(self.preview_co[0] / GRID_STEP) * GRID_STEP,
                            round(self.preview_co[1] / GRID_STEP) * GRID_STEP)
                        self.snap_kind = 'GRID'
        context.area.tag_redraw()

    def _place_point(self):
        """Fissa un punto; ritorna True se la polilinea va chiusa qui."""
        if self.preview_co is None:
            return False
        if self.snap_pid is not None:
            pid = self.snap_pid
        else:
            pid = self.model.add_point(*self.preview_co)
            # lo snap su una linea non è solo magnetismo: il punto nuovo
            # resta legato alla linea da un vincolo vero
            if self.snap_line is not None and solver.available():
                ctype = {'MID': C.MIDPOINT, 'EDGE': C.POINT_ON_LINE}.get(self.snap_kind)
                if ctype is not None:
                    try:
                        self.model.add_constraint(ctype, pid, self.snap_line)
                    except (KeyError, ValueError):
                        pass

        if self.prev_pid is not None and pid != self.prev_pid:
            before = len(self.model.lines)
            self.model.add_line(self.prev_pid, pid)
            if len(self.model.lines) > before:
                self.lines_added += 1
                # I punti pending diventano persistenti solo qui, insieme
                # alla loro prima linea: niente punti orfani su Esc.
                props.save_model(self.model, self.obj)

        if self.first_pid is None:
            self.first_pid = pid
        elif pid == self.first_pid and self.lines_added > 0:
            return True  # profilo chiuso sul punto di partenza

        self.prev_pid = pid
        return False

    def _finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.lines_added:
            # La mesh-profilo segue sempre lo sketch; il resolve fa entrare
            # subito nel sistema gli eventuali vincoli di snap creati.
            if solver.available():
                convert.resolve_and_update(self.obj)
            else:
                convert.rebuild_profile_mesh(self.obj)
            self.report({'INFO'}, f"Aggiunti {self.lines_added} segmenti")
            return {'FINISHED'}
        return {'CANCELLED'}


def _draw_preview(op):
    """Rubber band e marker di snap del tool attivo."""
    if op.preview_co is None:
        return
    mw = op.obj.matrix_world
    current = mw @ Vector((op.preview_co[0], op.preview_co[1], 0.0))

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')

    if op.prev_pid is not None:
        p = op.model.points[op.prev_pid]
        prev = mw @ Vector((p.u, p.v, 0.0))
        overlay.draw_lines([prev, current], overlay.COL_RUBBER, 1.5)

    snap_kind = getattr(op, 'snap_kind', 'POINT' if op.snap_pid else None)
    if snap_kind == 'POINT':
        overlay.draw_points([current], overlay.COL_SNAP, 11.0)
    elif snap_kind == 'MID':
        overlay.draw_points([current], overlay.COL_DIM, 9.0)
    elif snap_kind == 'EDGE':
        overlay.draw_points([current], overlay.COL_DIM, 6.5)
    elif snap_kind == 'GRID':
        overlay.draw_points([current], overlay.COL_LABEL, 7.0)
    else:
        overlay.draw_points([current], overlay.COL_RUBBER, 5.0)

    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


class SKETCHCAD_OT_draw_circle(bpy.types.Operator):
    bl_idname = "sketch_cad.draw_circle"
    bl_label = "Disegna cerchio"
    bl_description = (
        "Cerchio per centro e raggio: click per il centro, click per il "
        "raggio; click destro/Invio/Esc per terminare"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        self.model = props.load_model(self.obj)
        self.center_pid = None
        self.preview_co = None
        self.snap_pid = None
        self.created = 0
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_circle_preview, (self,), 'WINDOW', 'POST_VIEW')
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set(
            "Click: centro | Click dx / Invio / Esc: termina")
        self._update_preview(context, event)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.type == 'MOUSEMOVE':
            self._update_preview(context, event)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                self._click(context)
                return {'RUNNING_MODAL'}
            if event.type in {'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'}:
                return self._finish(context)
        return {'RUNNING_MODAL'}

    def _update_preview(self, context, event):
        self.preview_co = pick.mouse_to_plane(context, event, self.obj)
        self.snap_pid = None
        if self.preview_co is not None and self.center_pid is None:
            self.snap_pid = pick.point_under_mouse(
                context, event, self.obj, self.model, SNAP_PX)
            if self.snap_pid is not None:
                p = self.model.points[self.snap_pid]
                self.preview_co = (p.u, p.v)
        context.area.tag_redraw()

    def _click(self, context):
        if self.preview_co is None:
            return
        if self.center_pid is None:
            self.center_pid = (self.snap_pid if self.snap_pid is not None
                               else self.model.add_point(*self.preview_co))
            context.workspace.status_text_set(
                "Click: raggio | Click dx / Invio / Esc: termina")
            return
        center = self.model.points[self.center_pid]
        radius = math.hypot(self.preview_co[0] - center.u,
                            self.preview_co[1] - center.v)
        if radius < 1e-9:
            return
        self.model.add_circle(self.center_pid, radius)
        props.save_model(self.model, self.obj)
        convert.rebuild_profile_mesh(self.obj)
        self.created += 1
        self.center_pid = None
        context.workspace.status_text_set(
            "Click: centro | Click dx / Invio / Esc: termina")
        context.area.tag_redraw()

    def _finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.created:
            self.report({'INFO'}, f"Creati {self.created} cerchi")
            return {'FINISHED'}
        return {'CANCELLED'}


def _draw_circle_preview(op):
    if op.preview_co is None:
        return
    mw = op.obj.matrix_world
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')
    current = mw @ Vector((op.preview_co[0], op.preview_co[1], 0.0))
    if op.center_pid is None:
        color = overlay.COL_SNAP if op.snap_pid is not None else overlay.COL_RUBBER
        overlay.draw_points([current], color, 8.0 if op.snap_pid else 5.0)
    else:
        center = op.model.points[op.center_pid]
        radius = math.hypot(op.preview_co[0] - center.u, op.preview_co[1] - center.v)
        if radius > 1e-9:
            pts = geom.circle_points((center.u, center.v), radius, 48)
            coords = []
            for i in range(len(pts)):
                a, b = pts[i], pts[(i + 1) % len(pts)]
                coords.append(mw @ Vector((a[0], a[1], 0.0)))
                coords.append(mw @ Vector((b[0], b[1], 0.0)))
            overlay.draw_lines(coords, overlay.COL_RUBBER, 1.5)
        overlay.draw_points([mw @ Vector((center.u, center.v, 0.0))],
                            overlay.COL_RUBBER, 6.0)
    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


class SKETCHCAD_OT_draw_arc(bpy.types.Operator):
    bl_idname = "sketch_cad.draw_arc"
    bl_label = "Disegna arco"
    bl_description = (
        "Arco per centro, inizio e fine (senso antiorario): tre click; "
        "Esc annulla l'arco corrente, click destro/Invio termina"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        self.model = props.load_model(self.obj)
        self.center_pid = None
        self.start_pid = None
        self.preview_co = None
        self.snap_pid = None
        self.created = 0
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_arc_preview, (self,), 'WINDOW', 'POST_VIEW')
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        self._set_status(context)
        self._update_preview(context, event)
        return {'RUNNING_MODAL'}

    def _set_status(self, context):
        if self.center_pid is None:
            msg = "Click: centro dell'arco"
        elif self.start_pid is None:
            msg = "Click: punto iniziale (definisce il raggio)"
        else:
            msg = "Click: punto finale (antiorario)"
        context.workspace.status_text_set(
            f"{msg} | Esc: annulla arco | Click dx / Invio: termina")

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.type == 'MOUSEMOVE':
            self._update_preview(context, event)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                self._click(context, event)
                return {'RUNNING_MODAL'}
            if event.type == 'ESC':
                if self.center_pid is not None:
                    # annulla l'arco in corso (scarta i punti pending)
                    self.model = props.load_model(self.obj)
                    self.center_pid = None
                    self.start_pid = None
                    self._set_status(context)
                    context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
                return self._finish(context)
            if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
                return self._finish(context)
        return {'RUNNING_MODAL'}

    def _update_preview(self, context, event):
        self.preview_co = pick.mouse_to_plane(context, event, self.obj)
        self.snap_pid = None
        if self.preview_co is None:
            context.area.tag_redraw()
            return
        if self.start_pid is None:
            # centro e start agganciano i punti esistenti
            self.snap_pid = pick.point_under_mouse(
                context, event, self.obj, self.model, SNAP_PX)
            if self.snap_pid is not None:
                p = self.model.points[self.snap_pid]
                self.preview_co = (p.u, p.v)
        else:
            # end: candidato snap valido solo se vicino al cerchio guida
            # (il solver poi impone la coerenza esatta dell'arco)
            candidate = pick.point_under_mouse(
                context, event, self.obj, self.model, SNAP_PX)
            if candidate is not None and solver.available():
                center = self.model.points[self.center_pid]
                start = self.model.points[self.start_pid]
                radius = math.hypot(start.u - center.u, start.v - center.v)
                p = self.model.points[candidate]
                if abs(math.hypot(p.u - center.u, p.v - center.v) - radius) <= 0.1 * radius:
                    self.snap_pid = candidate
                    self.preview_co = (p.u, p.v)
        context.area.tag_redraw()

    def _click(self, context, event):
        if self.preview_co is None:
            return
        if self.center_pid is None:
            self.center_pid = (self.snap_pid if self.snap_pid is not None
                               else self.model.add_point(*self.preview_co))
        elif self.start_pid is None:
            pid = (self.snap_pid if self.snap_pid is not None
                   else self.model.add_point(*self.preview_co))
            center = self.model.points[self.center_pid]
            start = self.model.points[pid]
            if pid == self.center_pid or math.hypot(
                    start.u - center.u, start.v - center.v) < 1e-9:
                return
            self.start_pid = pid
        else:
            end_pid = self._end_point()
            if end_pid is None:
                return
            self.model.add_arc(self.center_pid, self.start_pid, end_pid)
            props.save_model(self.model, self.obj)
            if solver.available():
                convert.resolve_and_update(self.obj)
                self.model = props.load_model(self.obj)
            else:
                convert.rebuild_profile_mesh(self.obj)
            self.created += 1
            self.center_pid = None
            self.start_pid = None
        self._set_status(context)
        context.area.tag_redraw()

    def _end_point(self):
        """Punto finale: snap coerente oppure proiezione sul cerchio guida."""
        if self.snap_pid is not None and self.snap_pid not in (
                self.center_pid, self.start_pid):
            return self.snap_pid
        center = self.model.points[self.center_pid]
        start = self.model.points[self.start_pid]
        radius = math.hypot(start.u - center.u, start.v - center.v)
        angle = math.atan2(self.preview_co[1] - center.v,
                           self.preview_co[0] - center.u)
        end_co = (center.u + radius * math.cos(angle),
                  center.v + radius * math.sin(angle))
        sweep = geom.arc_sweep((center.u, center.v), (start.u, start.v), end_co)
        if sweep < 1e-6:
            return None  # end coincidente con start
        return self.model.add_point(*end_co)

    def _finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()
        if self.created:
            self.report({'INFO'}, f"Creati {self.created} archi")
            return {'FINISHED'}
        return {'CANCELLED'}


def _draw_arc_preview(op):
    if op.preview_co is None:
        return
    mw = op.obj.matrix_world
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')
    current = mw @ Vector((op.preview_co[0], op.preview_co[1], 0.0))

    def world_polyline(pts, closed=False):
        coords = []
        n = len(pts)
        last = n if closed else n - 1
        for i in range(last):
            a, b = pts[i], pts[(i + 1) % n]
            coords.append(mw @ Vector((a[0], a[1], 0.0)))
            coords.append(mw @ Vector((b[0], b[1], 0.0)))
        return coords

    if op.center_pid is None:
        color = overlay.COL_SNAP if op.snap_pid is not None else overlay.COL_RUBBER
        overlay.draw_points([current], color, 8.0 if op.snap_pid else 5.0)
    else:
        center = op.model.points[op.center_pid]
        center_world = mw @ Vector((center.u, center.v, 0.0))
        overlay.draw_points([center_world], overlay.COL_RUBBER, 6.0)
        if op.start_pid is None:
            overlay.draw_lines([center_world, current], overlay.COL_RUBBER, 1.0)
            color = overlay.COL_SNAP if op.snap_pid is not None else overlay.COL_RUBBER
            overlay.draw_points([current], color, 8.0 if op.snap_pid else 5.0)
        else:
            start = op.model.points[op.start_pid]
            radius = math.hypot(start.u - center.u, start.v - center.v)
            guide = geom.circle_points((center.u, center.v), radius, 48)
            overlay.draw_lines(world_polyline(guide, closed=True),
                               (*overlay.COL_RUBBER[:3], 0.25), 1.0)
            angle = math.atan2(op.preview_co[1] - center.v,
                               op.preview_co[0] - center.u)
            end_co = (center.u + radius * math.cos(angle),
                      center.v + radius * math.sin(angle))
            arc_pts = geom.arc_points((center.u, center.v),
                                      (start.u, start.v), end_co)
            overlay.draw_lines(world_polyline(arc_pts), overlay.COL_RUBBER, 2.0)
            color = overlay.COL_SNAP if op.snap_pid is not None else overlay.COL_RUBBER
            end_world = mw @ Vector((end_co[0], end_co[1], 0.0))
            overlay.draw_points([end_world], color, 8.0 if op.snap_pid else 5.0)
    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


_classes = (
    SKETCHCAD_OT_draw_line,
    SKETCHCAD_OT_draw_circle,
    SKETCHCAD_OT_draw_arc,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
