"""Valutatore sicuro di espressioni per quote e parametri.

L'espressione viene compilata in AST e valutata su una whitelist di nodi:
numeri, nomi di parametro, aritmetica (+ - * / // % **), parentesi, la
costante pi e poche funzioni (sqrt, abs, min, max). Niente attributi,
subscript, chiamate arbitrarie o altro Python.
"""

import ast
import math
import re


class ExprError(ValueError):
    """Espressione non valida o non valutabile."""


_FUNCTIONS = {
    'sqrt': math.sqrt,
    'abs': abs,
    'min': min,
    'max': max,
}

_CONSTANTS = {
    'pi': math.pi,
}

_BIN_OPS = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
    ast.FloorDiv: lambda a, b: a // b,
    ast.Mod: lambda a, b: a % b,
    ast.Pow: lambda a, b: a ** b,
}

_UNARY_OPS = {
    ast.UAdd: lambda a: a,
    ast.USub: lambda a: -a,
}


def _parse(expression: str) -> ast.Expression:
    try:
        return ast.parse(expression, mode='eval')
    except SyntaxError as e:
        raise ExprError(f"Sintassi non valida: {e.msg}") from None


def parse_names(expression: str) -> set[str]:
    """Nomi di parametro referenziati (funzioni e costanti escluse)."""
    tree = _parse(expression)
    return {node.id for node in ast.walk(tree)
            if isinstance(node, ast.Name)
            and node.id not in _CONSTANTS and node.id not in _FUNCTIONS}


def evaluate(expression: str, variables: dict[str, float]) -> float:
    """Valuta l'espressione con i parametri dati; ExprError se non valida."""
    result = _eval_node(_parse(expression).body, variables)
    if isinstance(result, float) and (math.isnan(result) or math.isinf(result)):
        raise ExprError("Risultato non finito")
    return float(result)


def _eval_node(node, variables):
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return node.value
        raise ExprError("Sono ammessi solo numeri")
    if isinstance(node, ast.Name):
        if node.id in variables:
            return variables[node.id]
        if node.id in _CONSTANTS:
            return _CONSTANTS[node.id]
        raise ExprError(f"Parametro sconosciuto: {node.id}")
    if isinstance(node, ast.BinOp):
        op = _BIN_OPS.get(type(node.op))
        if op is None:
            raise ExprError("Operatore non ammesso")
        left = _eval_node(node.left, variables)
        right = _eval_node(node.right, variables)
        try:
            return op(left, right)
        except ZeroDivisionError:
            raise ExprError("Divisione per zero") from None
    if isinstance(node, ast.UnaryOp):
        op = _UNARY_OPS.get(type(node.op))
        if op is None:
            raise ExprError("Operatore non ammesso")
        return op(_eval_node(node.operand, variables))
    if isinstance(node, ast.Call):
        if (isinstance(node.func, ast.Name) and node.func.id in _FUNCTIONS
                and not node.keywords):
            args = [_eval_node(a, variables) for a in node.args]
            try:
                return _FUNCTIONS[node.func.id](*args)
            except (TypeError, ValueError) as e:
                raise ExprError(str(e)) from None
        raise ExprError("Funzione non ammessa")
    raise ExprError(f"Elemento non ammesso: {type(node).__name__}")


def rename_in_expression(expression: str, old: str, new: str) -> str:
    """Sostituisce il nome di un parametro nell'espressione (word boundary)."""
    return re.sub(rf'(?<!\w){re.escape(old)}(?!\w)', new, expression)


def resolve_parameters(
        raw: dict[str, tuple[float, str]]) -> tuple[dict[str, float], dict[str, str]]:
    """Valuta la tabella parametri {nome: (valore_cache, espressione)}.

    Le espressioni possono riferire altri parametri e vengono valutate in
    ordine di dipendenza. Ritorna ({nome: valore}, {nome: errore}): i
    parametri con ciclo, riferimento mancante o espressione invalida
    restano al valore cache e compaiono tra gli errori.
    """
    values: dict[str, float] = {}
    errors: dict[str, str] = {}
    pending: dict[str, set[str]] = {}
    for name, (cache, expression) in raw.items():
        if not expression.strip():
            values[name] = cache
            continue
        try:
            pending[name] = parse_names(expression) & set(raw)
        except ExprError as e:
            values[name] = cache
            errors[name] = str(e)

    while pending:
        ready = [n for n, deps in pending.items() if deps <= set(values)]
        if not ready:
            for name in pending:  # ciclo (o dipendenza da un parametro in ciclo)
                values[name] = raw[name][0]
                errors[name] = "Dipendenza circolare"
            break
        for name in ready:
            del pending[name]
            try:
                values[name] = evaluate(raw[name][1], values)
            except ExprError as e:
                values[name] = raw[name][0]
                errors[name] = str(e)
    return values, errors
