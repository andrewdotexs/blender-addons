"""Conversione sketch → geometria Blender.

La mesh dell'oggetto sketch contiene solo i profili chiusi (un ngon per
loop, normale +Z); le linee restano nell'overlay. L'estrusione è un
modificatore Geometry Nodes con input Depth: cambiando la profondità il
solido si aggiorna senza ricostruire nulla.
"""

import bmesh
import bpy

from . import props
from .core import geom, profile, solver

MODIFIER_NAME = "SketchCAD Extrude"
NODE_GROUP_NAME = "SketchCAD Extrude"


def rebuild_profile_mesh(obj) -> int:
    """Rigenera la mesh-profilo dai profili chiusi; ritorna quanti sono.

    Profili: i loop linee+archi (tessellati) e i cerchi (dischi).
    """
    model = props.load_model(obj)

    boundaries: list[list[tuple[float, float]]] = []
    for loop in profile.find_closed_loops(model):
        coords = profile.tessellate_loop(model, loop)
        if len(coords) >= 3:
            boundaries.append(coords)
    for circle in model.circles.values():
        if circle.radius < 1e-9:
            continue
        center = model.points[circle.center]
        boundaries.append(geom.circle_points((center.u, center.v), circle.radius))

    bm = bmesh.new()
    faces = 0
    for coords in boundaries:
        verts = [bm.verts.new((u, v, 0.0)) for u, v in coords]
        try:
            bm.faces.new(verts)
            faces += 1
        except ValueError:
            continue  # faccia degenere o duplicata: profilo ignorato
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return faces


def resolve_and_update(obj, dragged=None) -> solver.SolveResult:
    """Risolve i vincoli e, se ok, persiste e rigenera la mesh-profilo.

    Le quote legate a un parametro di scena ricevono il suo valore prima
    del solve. In caso di fallimento i props restano intatti: la geometria
    rimane all'ultima soluzione valida.
    """
    model = props.load_model(obj)
    scene = bpy.context.scene
    if scene is not None:
        model.apply_parameters(props.scene_parameters(scene))
    result = solver.solve(model, dragged)
    if result.ok:
        props.save_model(model, obj)
        rebuild_profile_mesh(obj)
    return result


def get_or_create_extrude_group():
    group = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if group is not None:
        return group

    group = bpy.data.node_groups.new(NODE_GROUP_NAME, 'GeometryNodeTree')
    group.interface.new_socket(
        "Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    depth = group.interface.new_socket(
        "Depth", in_out='INPUT', socket_type='NodeSocketFloat')
    depth.subtype = 'DISTANCE'
    depth.default_value = 0.2
    group.interface.new_socket(
        "Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    # Extrude Mesh da solo lascia il solido aperto sotto (sposta la faccia
    # e crea i lati): la base è la faccia originale flippata (normale -Z),
    # unita e saldata con Merge by Distance.
    group_in = group.nodes.new('NodeGroupInput')
    group_in.location = (-400, 0)
    group_out = group.nodes.new('NodeGroupOutput')
    group_out.location = (400, 0)
    extrude = group.nodes.new('GeometryNodeExtrudeMesh')
    extrude.location = (-150, 100)
    extrude.mode = 'FACES'
    flip = group.nodes.new('GeometryNodeFlipFaces')
    flip.location = (-150, -150)
    join = group.nodes.new('GeometryNodeJoinGeometry')
    join.location = (50, 0)
    merge = group.nodes.new('GeometryNodeMergeByDistance')
    merge.location = (220, 0)
    merge.inputs["Distance"].default_value = 1e-5

    group.links.new(group_in.outputs["Geometry"], extrude.inputs["Mesh"])
    group.links.new(group_in.outputs["Depth"], extrude.inputs["Offset Scale"])
    group.links.new(group_in.outputs["Geometry"], flip.inputs["Mesh"])
    group.links.new(extrude.outputs["Mesh"], join.inputs["Geometry"])
    group.links.new(flip.outputs["Mesh"], join.inputs["Geometry"])
    group.links.new(join.outputs["Geometry"], merge.inputs["Geometry"])
    group.links.new(merge.outputs["Geometry"], group_out.inputs["Geometry"])
    return group


def ensure_extrude_modifier(obj):
    mod = obj.modifiers.get(MODIFIER_NAME)
    if mod is None:
        mod = obj.modifiers.new(MODIFIER_NAME, 'NODES')
        mod.node_group = get_or_create_extrude_group()
    return mod


def depth_prop_identifier(group) -> str | None:
    """Identifier della IDProperty del modifier che pilota Depth."""
    for item in group.interface.items_tree:
        if (item.item_type == 'SOCKET' and item.in_out == 'INPUT'
                and item.name == "Depth"):
            return item.identifier
    return None
