"""Conversione sketch → geometria Blender.

La mesh dell'oggetto sketch contiene solo i profili chiusi (un ngon per
loop, normale +Z); le linee restano nell'overlay. L'estrusione è un
modificatore Geometry Nodes con input Depth: cambiando la profondità il
solido si aggiorna senza ricostruire nulla.
"""

import bmesh
import bpy

from . import props
from .core import geom, profile, solver

MODIFIER_NAME = "SketchCAD Extrude"
NODE_GROUP_NAME = "SketchCAD Extrude"
LINKED_GROUP_NAME = "SketchCAD Linked"


def rebuild_profile_mesh(obj) -> int:
    """Rigenera la mesh-profilo dai profili chiusi; ritorna quanti sono.

    Profili: i loop linee+archi (tessellati) e i cerchi (dischi).
    """
    model = props.load_model(obj)

    boundaries: list[list[tuple[float, float]]] = []
    for loop in profile.find_closed_loops(model):
        coords = profile.tessellate_loop(model, loop)
        if len(coords) >= 3:
            boundaries.append(coords)
    for circle in model.circles.values():
        if circle.radius < 1e-9:
            continue
        center = model.points[circle.center]
        boundaries.append(geom.circle_points((center.u, center.v), circle.radius))

    bm = bmesh.new()
    faces = 0
    for coords in boundaries:
        verts = [bm.verts.new((u, v, 0.0)) for u, v in coords]
        try:
            bm.faces.new(verts)
            faces += 1
        except ValueError:
            continue  # faccia degenere o duplicata: profilo ignorato
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return faces


def resolve_and_update(obj, dragged=None) -> solver.SolveResult:
    """Risolve i vincoli e, se ok, persiste e rigenera la mesh-profilo.

    Le quote legate a un parametro di scena ricevono il suo valore prima
    del solve. In caso di fallimento i props restano intatti: la geometria
    rimane all'ultima soluzione valida.
    """
    model = props.load_model(obj)
    scene = bpy.context.scene
    if scene is not None:
        model.apply_parameters(props.scene_parameters(scene))
    result = solver.solve(model, dragged)
    if result.ok:
        props.save_model(model, obj)
        rebuild_profile_mesh(obj)
    return result


def get_or_create_extrude_group():
    group = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if group is not None:
        return group

    group = bpy.data.node_groups.new(NODE_GROUP_NAME, 'GeometryNodeTree')
    group.interface.new_socket(
        "Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    depth = group.interface.new_socket(
        "Depth", in_out='INPUT', socket_type='NodeSocketFloat')
    depth.subtype = 'DISTANCE'
    depth.default_value = 0.2
    group.interface.new_socket(
        "Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    # Extrude Mesh da solo lascia il solido aperto sotto (sposta la faccia
    # e crea i lati): la base è la faccia originale flippata (normale -Z),
    # unita e saldata con Merge by Distance.
    group_in = group.nodes.new('NodeGroupInput')
    group_in.location = (-400, 0)
    group_out = group.nodes.new('NodeGroupOutput')
    group_out.location = (400, 0)
    extrude = group.nodes.new('GeometryNodeExtrudeMesh')
    extrude.location = (-150, 100)
    extrude.mode = 'FACES'
    flip = group.nodes.new('GeometryNodeFlipFaces')
    flip.location = (-150, -150)
    join = group.nodes.new('GeometryNodeJoinGeometry')
    join.location = (50, 0)
    merge = group.nodes.new('GeometryNodeMergeByDistance')
    merge.location = (220, 0)
    merge.inputs["Distance"].default_value = 1e-5

    group.links.new(group_in.outputs["Geometry"], extrude.inputs["Mesh"])
    group.links.new(group_in.outputs["Depth"], extrude.inputs["Offset Scale"])
    group.links.new(group_in.outputs["Geometry"], flip.inputs["Mesh"])
    group.links.new(extrude.outputs["Mesh"], join.inputs["Geometry"])
    group.links.new(flip.outputs["Mesh"], join.inputs["Geometry"])
    group.links.new(join.outputs["Geometry"], merge.inputs["Geometry"])
    group.links.new(merge.outputs["Geometry"], group_out.inputs["Geometry"])
    return group


def ensure_extrude_modifier(obj):
    mod = obj.modifiers.get(MODIFIER_NAME)
    if mod is None:
        mod = obj.modifiers.new(MODIFIER_NAME, 'NODES')
        mod.node_group = get_or_create_extrude_group()
    return mod


def socket_identifier(group, name, in_out='INPUT') -> str | None:
    """Identifier della IDProperty del modifier per un socket del gruppo."""
    for item in group.interface.items_tree:
        if (item.item_type == 'SOCKET' and item.in_out == in_out
                and item.name == name):
            return item.identifier
    return None


def depth_prop_identifier(group) -> str | None:
    """Identifier della IDProperty del modifier che pilota Depth."""
    return socket_identifier(group, "Depth")


def get_or_create_linked_group():
    """Node group della mesh collegata: Object Info realizzato sullo sketch.

    La sincronizzazione è del depsgraph: la mesh collegata mostra lo sketch
    valutato (estrusione inclusa) senza alcun codice di sync.
    """
    group = bpy.data.node_groups.get(LINKED_GROUP_NAME)
    if group is not None:
        return group

    group = bpy.data.node_groups.new(LINKED_GROUP_NAME, 'GeometryNodeTree')
    group.interface.new_socket(
        "Sketch", in_out='INPUT', socket_type='NodeSocketObject')
    group.interface.new_socket(
        "Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    group_in = group.nodes.new('NodeGroupInput')
    group_in.location = (-250, 0)
    group_out = group.nodes.new('NodeGroupOutput')
    group_out.location = (250, 0)
    info = group.nodes.new('GeometryNodeObjectInfo')
    info.location = (0, 0)
    info.transform_space = 'RELATIVE'  # a trasformazione identità la mesh
    #                                    appare esattamente dove sta lo sketch

    group.links.new(group_in.outputs["Sketch"], info.inputs["Object"])
    group.links.new(info.outputs["Geometry"], group_out.inputs["Geometry"])
    return group


def linked_source(obj):
    """Lo sketch sorgente se obj è una mesh collegata, altrimenti None."""
    if obj is None or obj.type != 'MESH':
        return None
    for mod in obj.modifiers:
        if (mod.type == 'NODES' and mod.node_group is not None
                and mod.node_group.name.startswith(LINKED_GROUP_NAME)):
            identifier = socket_identifier(mod.node_group, "Sketch")
            if identifier is not None:
                return mod.get(identifier)
    return None
