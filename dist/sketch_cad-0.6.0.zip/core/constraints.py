"""Definizione dei vincoli geometrici 2D.

I tipi sono stringhe stabili: vengono salvate così nei PropertyGroup,
quindi cambiarle richiederebbe una migrazione dello schema.
"""

from dataclasses import dataclass

COINCIDENT = 'COINCIDENT'
HORIZONTAL = 'HORIZONTAL'
VERTICAL = 'VERTICAL'
DISTANCE = 'DISTANCE'
PARALLEL = 'PARALLEL'
PERPENDICULAR = 'PERPENDICULAR'
EQUAL_LENGTH = 'EQUAL_LENGTH'
ANGLE = 'ANGLE'

# Classificazione per arità/entità riferite: guida validazione, solver e UI.
POINT_POINT_TYPES = frozenset({COINCIDENT})          # a, b = punti
LINE_TYPES = frozenset({HORIZONTAL, VERTICAL, DISTANCE})  # a = linea
LINE_LINE_TYPES = frozenset({PARALLEL, PERPENDICULAR, EQUAL_LENGTH, ANGLE})  # a, b = linee

TYPES = POINT_POINT_TYPES | LINE_TYPES | LINE_LINE_TYPES

LABELS = {
    COINCIDENT: "Coincidenti",
    HORIZONTAL: "Orizzontale",
    VERTICAL: "Verticale",
    DISTANCE: "Distanza",
    PARALLEL: "Parallele",
    PERPENDICULAR: "Perpendicolari",
    EQUAL_LENGTH: "Lunghezze uguali",
    ANGLE: "Angolo",
}


@dataclass
class Constraint:
    id: int
    type: str
    a: int            # linea (LINE/LINE_LINE) o primo punto (COINCIDENT)
    b: int = 0        # seconda linea (LINE_LINE) o secondo punto (COINCIDENT)
    value: float = 0.0  # lunghezza per DISTANCE, gradi per ANGLE
    offset: float = 0.3  # distanza della linea di quota dall'entità (DISTANCE)
