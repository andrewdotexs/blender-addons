"""Editing interattivo delle quote (click sul testo → dialog del valore)."""

import math

import bpy

from .. import convert, pick, props
from ..core import constraints as C
from ..core import solver


class SKETCHCAD_OT_edit_dimension(bpy.types.Operator):
    bl_idname = "sketch_cad.edit_dimension"
    bl_label = "Modifica quota"
    bl_description = "Click sul testo di una quota (distanza o angolo) per cambiarne il valore"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.sketch_cad.is_sketch
                and solver.available())

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Da lanciare nella viewport 3D")
            return {'CANCELLED'}
        self.obj = context.active_object
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set(
            "Click sul testo di una quota | Click dx / Esc: annulla")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            if event.type == 'LEFTMOUSE':
                model = props.load_model(self.obj)
                cid = pick.dimension_under_mouse(context, event, self.obj, model)
                if cid is None:
                    return {'RUNNING_MODAL'}
                self._finish(context)
                bpy.ops.sketch_cad.set_dimension_value(
                    'INVOKE_DEFAULT', constraint_id=cid)
                return {'FINISHED'}
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                self._finish(context)
                return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _finish(self, context):
        context.window.cursor_modal_restore()
        context.workspace.status_text_set(None)
        context.area.tag_redraw()


class SKETCHCAD_OT_set_dimension_value(bpy.types.Operator):
    bl_idname = "sketch_cad.set_dimension_value"
    bl_label = "Valore quota"
    bl_description = "Imposta il valore di una quota e risolve lo sketch"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    constraint_id: bpy.props.IntProperty(options={'HIDDEN'})
    distance: bpy.props.FloatProperty(name="Distanza", min=0.0, subtype='DISTANCE')
    angle: bpy.props.FloatProperty(name="Angolo", subtype='ANGLE')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.sketch_cad.is_sketch

    def invoke(self, context, event):
        model = props.load_model(context.active_object)
        c = model.constraints.get(self.constraint_id)
        if c is None or c.type not in (C.DISTANCE, C.ANGLE):
            return {'CANCELLED'}
        self._is_angle = c.type == C.ANGLE
        if self._is_angle:
            self.angle = math.radians(c.value)
        else:
            self.distance = c.value
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "angle" if self._is_angle else "distance")

    def execute(self, context):
        obj = context.active_object
        model = props.load_model(obj)
        c = model.constraints.get(self.constraint_id)
        if c is None or c.type not in (C.DISTANCE, C.ANGLE):
            self.report({'WARNING'}, "Quota non trovata")
            return {'CANCELLED'}
        old_value = c.value
        c.value = math.degrees(self.angle) if c.type == C.ANGLE else self.distance
        props.save_model(model, obj)

        result = convert.resolve_and_update(obj)
        if not result.ok:
            c.value = old_value
            props.save_model(model, obj)
            self.report({'ERROR'}, f"Valore rifiutato: {result.message}")
            return {'CANCELLED'}
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        self.report({'INFO'}, f"{C.LABELS[c.type]} aggiornato")
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_edit_dimension,
    SKETCHCAD_OT_set_dimension_value,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
