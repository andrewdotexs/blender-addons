"""Disegno overlay degli sketch nella viewport 3D (modulo gpu).

Gli sketch non hanno geometria mesh visibile (Slice 1): tutto ciò che si
vede in viewport passa da qui. Per ora i batch vengono ricostruiti a ogni
redraw — con le quantità di entità di uno sketch è irrilevante; la cache
con dirty flag arriverà quando servirà.
"""

import math

import blf
import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from .core import constraints as C

COL_LINE_ACTIVE = (0.92, 0.92, 0.92, 1.0)
COL_LINE_OTHER = (0.55, 0.55, 0.55, 0.5)
COL_POINT = (0.85, 0.85, 0.88, 1.0)
COL_SELECTED = (1.0, 0.55, 0.12, 1.0)
COL_RUBBER = (0.35, 0.7, 1.0, 0.9)
COL_SNAP = (0.3, 1.0, 0.45, 1.0)
COL_LABEL = (1.0, 0.62, 0.1, 1.0)

# glifi ASCII-safe (niente simboli unicode: dipendono dal font UI)
_CONSTRAINT_GLYPHS = {
    C.HORIZONTAL: "H",
    C.VERTICAL: "V",
    C.PARALLEL: "//",
    C.PERPENDICULAR: "90°",
    C.EQUAL_LENGTH: "=",
}

_handle = None
_handle_labels = None


def draw_lines(coords, color, width=2.0):
    """Disegna segmenti (coppie di Vector world) con spessore in pixel."""
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    shader.uniform_float("lineWidth", width)
    shader.uniform_float("color", color)
    batch.draw(shader)


def draw_points(coords, color, size=6.0):
    """Disegna punti (Vector world) con dimensione in pixel."""
    gpu.state.point_size_set(size)
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_sketches():
    context = bpy.context
    sketches = [o for o in context.visible_objects if o.sketch_cad.is_sketch]
    if not sketches:
        return

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')  # lo sketch resta visibile attraverso le mesh

    active = context.active_object
    for obj in sketches:
        data = obj.sketch_cad
        mw = obj.matrix_world
        is_active = obj == active
        world_points = {p.id: mw @ Vector((p.co[0], p.co[1], 0.0)) for p in data.points}

        line_coords = []
        line_coords_selected = []
        for line in data.lines:
            a = world_points.get(line.a)
            b = world_points.get(line.b)
            if a is None or b is None:
                continue
            target = line_coords_selected if (is_active and line.selected) else line_coords
            target += [a, b]

        if line_coords:
            draw_lines(line_coords, COL_LINE_ACTIVE if is_active else COL_LINE_OTHER, 2.0)
        if line_coords_selected:
            draw_lines(line_coords_selected, COL_SELECTED, 3.0)

        if is_active and world_points:
            normal_pts = [world_points[p.id] for p in data.points if not p.selected]
            selected_pts = [world_points[p.id] for p in data.points if p.selected]
            if normal_pts:
                draw_points(normal_pts, COL_POINT, 6.0)
            if selected_pts:
                draw_points(selected_pts, COL_SELECTED, 9.0)

    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


def _draw_constraint_labels():
    """Glifi dei vincoli (H/V, valore distanza) al midpoint della linea."""
    context = bpy.context
    obj = context.active_object
    if obj is None or not obj.sketch_cad.is_sketch:
        return
    data = obj.sketch_cad
    if not data.constraints:
        return
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return

    mw = obj.matrix_world
    points = {p.id: (p.co[0], p.co[1]) for p in data.points}
    lines = {l.id: (l.a, l.b) for l in data.lines}

    font = 0
    blf.size(font, 13.0)
    blf.color(font, *COL_LABEL)
    stacked: dict[int, int] = {}  # più vincoli sulla stessa linea: impila i glifi
    for c in data.constraints:
        if c.type == C.DISTANCE:
            glyph = f"{c.value:.2f}"
        elif c.type == C.ANGLE:
            glyph = f"{math.degrees(c.value_angle):.1f}°"
        else:
            glyph = _CONSTRAINT_GLYPHS.get(c.type)
            if glyph is None:
                continue  # COINCIDENT: nessun glifo
        # i vincoli a due linee mostrano il glifo su entrambe
        targets = (c.a, c.b) if c.type in C.LINE_LINE_TYPES else (c.a,)
        for line_id in targets:
            endpoints = lines.get(line_id)
            if endpoints is None:
                continue
            pa = points.get(endpoints[0])
            pb = points.get(endpoints[1])
            if pa is None or pb is None:
                continue
            mid = mw @ Vector(((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, 0.0))
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, mid)
            if screen is None:
                continue
            offset = stacked.get(line_id, 0)
            stacked[line_id] = offset + 1
            blf.position(font, screen.x + 7, screen.y + 7 + offset * 16, 0)
            blf.draw(font, glyph)


def register():
    global _handle, _handle_labels
    if bpy.app.background:
        return  # niente viewport in headless: lasciare gli handler spenti
    _handle = bpy.types.SpaceView3D.draw_handler_add(
        _draw_sketches, (), 'WINDOW', 'POST_VIEW')
    _handle_labels = bpy.types.SpaceView3D.draw_handler_add(
        _draw_constraint_labels, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    global _handle, _handle_labels
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, 'WINDOW')
        _handle = None
    if _handle_labels is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle_labels, 'WINDOW')
        _handle_labels = None
