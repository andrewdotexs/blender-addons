"""Pannelli e menu di Sketch CAD."""

import bpy

from . import convert
from .core import constraints as C
from .core import solver


class SKETCHCAD_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sketch"
    bl_label = "Sketch CAD"

    def draw(self, context):
        layout = self.layout
        layout.operator("sketch_cad.new_sketch", icon='ADD')

        obj = context.active_object
        if obj is None or not obj.sketch_cad.is_sketch:
            layout.label(text="Nessuno sketch attivo", icon='INFO')
            return

        data = obj.sketch_cad
        box = layout.box()
        box.label(text=obj.name, icon='GREASEPENCIL')
        box.label(text=f"{len(data.points)} punti, {len(data.lines)} linee")
        box.operator("sketch_cad.draw_line", icon='IPO_LINEAR')
        box.operator("sketch_cad.move_point", icon='EMPTY_ARROWS')

        n_selected = (sum(1 for p in data.points if p.selected)
                      + sum(1 for l in data.lines if l.selected))
        row = box.row(align=True)
        row.operator("sketch_cad.select", icon='RESTRICT_SELECT_OFF')
        sub = row.row(align=True)
        sub.enabled = n_selected > 0
        sub.operator("sketch_cad.delete_selected", text="", icon='TRASH')
        if n_selected:
            box.label(text=f"{n_selected} entità selezionate")

        cons = layout.box()
        cons.label(text="Vincoli", icon='CONSTRAINT')
        if not solver.available():
            cons.label(text="Solver non disponibile", icon='ERROR')
        else:
            row = cons.row(align=True)
            row.operator("sketch_cad.constrain_horizontal", text="H")
            row.operator("sketch_cad.constrain_vertical", text="V")
            row.operator("sketch_cad.constrain_distance", text="Distanza")
            row = cons.row(align=True)
            row.operator("sketch_cad.constrain_parallel", text="Parallele")
            row.operator("sketch_cad.constrain_perpendicular", text="Perpend.")
            row = cons.row(align=True)
            row.operator("sketch_cad.constrain_equal", text="Uguali")
            row.operator("sketch_cad.constrain_angle", text="Angolo")
        for c in data.constraints:
            row = cons.row(align=True)
            row.label(text=C.LABELS.get(c.type, c.type))
            if c.type == C.DISTANCE:
                row.prop(c, "value", text="")
            elif c.type == C.ANGLE:
                row.prop(c, "value_angle", text="")
            op = row.operator("sketch_cad.remove_constraint", text="", icon='X')
            op.constraint_id = c.id

        solid = layout.box()
        n_profiles = len(obj.data.polygons)
        label = "1 profilo chiuso" if n_profiles == 1 else f"{n_profiles} profili chiusi"
        solid.label(text=label, icon='MESH_DATA')
        solid.operator("sketch_cad.extrude", icon='MOD_SOLIDIFY')

        mod = obj.modifiers.get(convert.MODIFIER_NAME)
        if mod is not None and mod.type == 'NODES' and mod.node_group is not None:
            identifier = convert.depth_prop_identifier(mod.node_group)
            if identifier is not None:
                solid.prop(mod, f'["{identifier}"]', text="Profondità")


_classes = (
    SKETCHCAD_PT_main,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
