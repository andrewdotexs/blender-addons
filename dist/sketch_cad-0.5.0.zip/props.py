"""Persistenza nel .blend: PropertyGroup su Object e sync col modello core.

I PropertyGroup sono lo storage (salvato nel .blend, integrato con l'undo);
SketchModel è la rappresentazione runtime su cui lavorano operatori e solver.
load_model/save_model fanno la conversione completa.
"""

import math

import bpy

from .core.constraints import ANGLE, DISTANCE, Constraint
from .core.model import Line, Point, SketchModel

# True mentre save_model riscrive le collection: gli update callback delle
# property non devono reagire alle nostre stesse scritture.
_suspend_updates = False


def _on_constraint_value_update(self, context):
    """L'utente ha cambiato il valore di un vincolo dal pannello: re-solve.

    Se il nuovo valore rende il sistema irrisolvibile la geometria resta
    all'ultima soluzione valida (il valore mostrato non viene ripristinato:
    l'utente vede che la geometria non segue e corregge).
    """
    if _suspend_updates:
        return
    obj = self.id_data
    if obj is None or not obj.sketch_cad.is_sketch:
        return
    from . import convert  # import locale: convert importa già props
    convert.resolve_and_update(obj)


class SketchPointProp(bpy.types.PropertyGroup):
    id: bpy.props.IntProperty()
    co: bpy.props.FloatVectorProperty(size=2)
    selected: bpy.props.BoolProperty(default=False)


class SketchLineProp(bpy.types.PropertyGroup):
    id: bpy.props.IntProperty()
    a: bpy.props.IntProperty()
    b: bpy.props.IntProperty()
    selected: bpy.props.BoolProperty(default=False)


class SketchConstraintProp(bpy.types.PropertyGroup):
    id: bpy.props.IntProperty()
    type: bpy.props.StringProperty()
    a: bpy.props.IntProperty()
    b: bpy.props.IntProperty()
    value: bpy.props.FloatProperty(
        min=0.0, subtype='DISTANCE', update=_on_constraint_value_update)
    # l'angolo viaggia in radianti nei props (subtype ANGLE → UI in gradi),
    # in gradi nel core (convenzione SolveSpace)
    value_angle: bpy.props.FloatProperty(
        subtype='ANGLE', update=_on_constraint_value_update)


class SketchCadObjectData(bpy.types.PropertyGroup):
    is_sketch: bpy.props.BoolProperty(default=False)
    schema_version: bpy.props.IntProperty(default=1)
    next_id: bpy.props.IntProperty(default=1)
    points: bpy.props.CollectionProperty(type=SketchPointProp)
    lines: bpy.props.CollectionProperty(type=SketchLineProp)
    constraints: bpy.props.CollectionProperty(type=SketchConstraintProp)


def load_model(obj) -> SketchModel:
    data = obj.sketch_cad
    model = SketchModel()
    for p in data.points:
        model.points[p.id] = Point(p.id, p.co[0], p.co[1])
        if p.selected:
            model.selection.add(p.id)
    for line in data.lines:
        model.lines[line.id] = Line(line.id, line.a, line.b)
        if line.selected:
            model.selection.add(line.id)
    for c in data.constraints:
        value = math.degrees(c.value_angle) if c.type == ANGLE else c.value
        model.constraints[c.id] = Constraint(c.id, c.type, c.a, c.b, value)
    model.next_id = max(data.next_id, 1)
    return model


def save_model(model: SketchModel, obj) -> None:
    global _suspend_updates
    _suspend_updates = True
    try:
        data = obj.sketch_cad
        data.points.clear()
        data.lines.clear()
        data.constraints.clear()
        for p in model.points.values():
            item = data.points.add()
            item.id = p.id
            item.co = (p.u, p.v)
            item.selected = p.id in model.selection
        for line in model.lines.values():
            item = data.lines.add()
            item.id = line.id
            item.a = line.a
            item.b = line.b
            item.selected = line.id in model.selection
        for c in model.constraints.values():
            item = data.constraints.add()
            item.id = c.id
            item.type = c.type
            item.a = c.a
            item.b = c.b
            if c.type == DISTANCE:
                item.value = c.value
            elif c.type == ANGLE:
                item.value_angle = math.radians(c.value)
        data.next_id = model.next_id
    finally:
        _suspend_updates = False


_classes = (
    SketchPointProp,
    SketchLineProp,
    SketchConstraintProp,
    SketchCadObjectData,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.sketch_cad = bpy.props.PointerProperty(type=SketchCadObjectData)


def unregister():
    del bpy.types.Object.sketch_cad
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
