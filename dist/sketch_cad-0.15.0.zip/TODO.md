# TODO

## Bug (priorità alta)

- ✅ **Risolto (Slice 10)** — Come vedi nell'immagine, ho disegnato un primo segmento, poi, partendo dal suo punto medio, ne ho disegnato un altro. Se provo a disegnare un segmento dalla metà del segmento già diviso non riesco (il segmento in rosso è quello che avrei voluto disegnare)
  → *ora esiste lo snap "su linea": si può partire da un punto qualsiasi di un segmento (marker azzurro piccolo), con vincolo "Punto su linea" automatico*
![bug001](..\static\images\bug001.png)

- ✅ **Risolto (Slice 10)** — Quando si inserisce un vincolo che comprende un segmento creato a partire dal punto medio di un altro segmento, questo non reta agganciato al punto medio (vedi cerchi in rosso)
  → *lo snap al punto medio ora crea il vincolo "Punto medio": il punto resta agganciato anche quando il solver muove la linea*
![bug002a](..\static\images\bug002a.png)
![bug002b](..\static\images\bug002b.png)

- ✅ **Risolto (Slice 10)** — Quando disegno una linea partendo dal punto medio di un segmento e poi successivamento muovo il vertice, questo non resta agganciato e si muove liberamente.
  → *stesso fix: il vincolo "Punto medio" tiene il punto al suo posto durante il drag*

- Quando creo un profilo chiuso nello sketch e poi lo estrudo, tornando allo scketch non è più evidenziata l'area del profilo chiuso
![bug003](..\static\images\bug003.png)

- Quando disegno un segmento e poi nedisegno un altro partendo dal punto medio di quello precedente

## Migliorie (priorità media)

- ✅ **Risolto (Slice 10)** — Aggiungere lo snap dei vertici anche quando si spostano tramite la funzione "Muovi punto"
  → *magnetismo verso punti e punti medi durante il drag; al rilascio su uno snap viene creato il vincolo (Coincidenti / Punto medio)*

- ✅ **Risolto (541ddd7)** — Visualizzare le quote anche per il cerchio e l'arco quando si seleziona "Raggio"
  → *era un bug del filtro overlay: le quote raggio ora si disegnano (linea radiale + testo R…)*

- ⏳ Aggiungere le curve come elemento nativo dello sketch
  → *slice dedicato da pianificare: py-slvs supporta le cubiche Bezier (addCubic + tangenze), ma tocca entità, profili, trim e tool*

- Ingrandire il font delle dimensioni

## Nuove funzionalità (**prima di implementarle ragioniamo assieme**) (priorità bassa)

- ✅ **Risolto (Slice 11 + 12)** — Aggiungere la gestione parametrica con la possibilità di assegnare lo stesso parametro a più dimensioni della geometria
  → *tabella parametri per scena (pannello "Parametri"); le quote si legano dal dialog Modifica quota; cambio → propagazione a tutti gli sketch. Con le espressioni: quote tipo `base*2+0.5` e parametri derivati (`doppio = base*2`) con dipendenze e cicli gestiti*

- ✅ **Risolto (Slice 13)** — Implementare la conversione da scketch a mesh di Blender nativa. Le modifiche fatte sullo sketch dovranno riflettersi sulla mesh nativa. Tutte le operazioni di modifica eseguite sulla mesh nativa, dovranno poter essere modificate (nei loro parametri) e/o cancellate (ritornando alla situazione pre-modifica)
  → *"Crea mesh collegata": oggetto mesh che segue lo sketch in tempo reale (modifiche sketch → riflesse); le operazioni sulla mesh = modificatori Blender (parametrici e cancellabili by design). "Consolida": bake esplicito a mesh pura per l'edit mode libero. Nota concordata: le modifiche manuali in edit mode non sono riparametrizzabili (limite di Blender, non aggirabile) — per quelle si consolida prima*

- Implemetare snap evoluto: per esempio snap su lati e vertici quando si effettua un nuovo sketch su una faccia di un solito esistente (parliamone)

- Possibilità di disegnare linee ausiliarie, che non fanno parte della geometria, devono servire solo come guide o punti di snap per agganciare / allineare altre parti dello sketch o allineare più geometri nello stesso sketch 

- Parliamo di altre funzionalità utili di un CAD che è possibile e vale la pena implementare in questo adddon