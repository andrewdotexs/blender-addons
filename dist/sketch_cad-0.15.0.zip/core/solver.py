"""Adapter verso il solver geometrico SolveSpace (py-slvs).

py_slvs arriva come wheel bundled nell'extension (manifest) o via pip nei
test; l'import è guardato così il resto dell'addon funziona anche senza.
A ogni solve il sistema viene ricostruito da zero: con le entità di uno
sketch è economico e azzera i problemi di sincronizzazione degli handle.
"""

from dataclasses import dataclass, field

try:
    from py_slvs import slvs
except ImportError:  # wheel non installata: solver disattivo
    slvs = None

from . import constraints as C
from .model import SketchModel

_GROUP_FIXED = 1   # workplane
_GROUP_SKETCH = 2  # entità da risolvere

_MESSAGES = {
    0: "ok",
    1: "vincoli inconsistenti",
    2: "il solver non converge",
    3: "troppe incognite",
}


@dataclass
class SolveResult:
    ok: bool
    code: int
    dof: int
    failed: list[int] = field(default_factory=list)  # id dei vincoli falliti

    @property
    def message(self) -> str:
        return _MESSAGES.get(self.code, f"errore solver {self.code}")


def available() -> bool:
    return slvs is not None


def solve(model: SketchModel, dragged: dict[int, tuple[float, float]] | None = None) -> SolveResult:
    """Risolve i vincoli aggiornando le coordinate dei punti in place.

    dragged: {point_id: (u, v)} — punti che l'utente sta trascinando:
    partono dalla posizione richiesta e vengono ancorati con WHERE_DRAGGED,
    quindi si spostano solo se i vincoli lo impongono.

    Se la risoluzione fallisce il modello NON viene modificato.
    """
    if slvs is None:
        raise RuntimeError(
            "py-slvs non disponibile: reinstalla l'extension con la wheel inclusa")
    dragged = dragged or {}

    system = slvs.System()
    workplane = system.addWorkplane(
        system.addPoint3dV(0.0, 0.0, 0.0, _GROUP_FIXED),
        system.addNormal3dV(1.0, 0.0, 0.0, 0.0, _GROUP_FIXED),
        _GROUP_FIXED,
    )

    point_handles: dict[int, int] = {}
    for p in model.points.values():
        u, v = dragged.get(p.id, (p.u, p.v))
        point_handles[p.id] = system.addPoint2dV(workplane, u, v, _GROUP_SKETCH)
    for pid in dragged:
        handle = point_handles.get(pid)
        if handle is not None:
            system.addWhereDragged(handle, workplane, _GROUP_SKETCH)

    # line entities solo per le linee riferite da vincoli che le richiedono
    needed_lines: set[int] = set()
    for c in model.constraints.values():
        if c.type in C.LINE_LINE_TYPES:
            needed_lines.add(c.a)
            needed_lines.add(c.b)
        elif c.type in C.POINT_LINE_TYPES:
            needed_lines.add(c.b)
    line_handles: dict[int, int] = {}
    for lid in needed_lines:
        line = model.lines[lid]
        line_handles[lid] = system.addLineSegment(
            point_handles[line.a], point_handles[line.b], _GROUP_SKETCH)

    # archi: entity sempre presenti — l'equazione interna |c-s| == |c-e|
    # mantiene la coerenza geometrica durante drag e solve.
    # cerchi: entity (con Distance per il raggio) solo se vincolati.
    circular_handles: dict[int, int] = {}
    radius_handles: dict[int, int] = {}  # circle id -> Distance entity
    for arc in model.arcs.values():
        circular_handles[arc.id] = system.addArcOfCircle(
            workplane, point_handles[arc.center],
            point_handles[arc.start], point_handles[arc.end], _GROUP_SKETCH)
    needed_circles = {
        c.a for c in model.constraints.values()
        if c.type in C.CIRCULAR_TYPES and c.a in model.circles
    } | {
        c.b for c in model.constraints.values()
        if c.type in C.POINT_CIRCULAR_TYPES and c.b in model.circles
    }
    if needed_circles:
        normal2d = system.addNormal2d(workplane, _GROUP_SKETCH)
        for cid in needed_circles:
            circle = model.circles[cid]
            # addCircle (non la variante V): la Distance entity resta nostra
            # e il raggio risolto si rilegge da lì
            dist = system.addDistanceV(circle.radius, _GROUP_SKETCH)
            radius_handles[cid] = dist
            circular_handles[cid] = system.addCircle(
                point_handles[circle.center], normal2d, dist, _GROUP_SKETCH)

    constraint_ids: dict[int, int] = {}  # handle slvs -> id vincolo nostro
    for c in model.constraints.values():
        handle = _add_constraint(
            system, workplane, model, point_handles, line_handles,
            circular_handles, c)
        constraint_ids[handle] = c.id

    code = system.solve(_GROUP_SKETCH, True)
    ok = code == 0
    if ok:
        for pid, handle in point_handles.items():
            point = model.points[pid]
            point.u = system.getParam(system.getEntityParam(handle, 0)).val
            point.v = system.getParam(system.getEntityParam(handle, 1)).val
        for cid, dist in radius_handles.items():
            model.circles[cid].radius = system.getParam(
                system.getEntityParam(dist, 0)).val
    failed = [constraint_ids[h] for h in system.Failed if h in constraint_ids]
    return SolveResult(ok, code, system.Dof, failed)


def _add_constraint(system, workplane, model, point_handles, line_handles,
                    circular_handles, c) -> int:
    """Traduce un nostro vincolo in un vincolo SolveSpace, ritorna l'handle."""
    if c.type == C.COINCIDENT:
        return system.addPointsCoincident(
            point_handles[c.a], point_handles[c.b], workplane, _GROUP_SKETCH)

    if c.type == C.RADIUS:
        # SolveSpace ragiona in diametri
        return system.addDiameter(c.value * 2.0, circular_handles[c.a], _GROUP_SKETCH)

    if c.type == C.MIDPOINT:
        return system.addMidPoint(
            point_handles[c.a], line_handles[c.b], workplane, _GROUP_SKETCH)
    if c.type == C.POINT_ON_LINE:
        return system.addPointOnLine(
            point_handles[c.a], line_handles[c.b], workplane, _GROUP_SKETCH)
    if c.type == C.POINT_ON_CIRCLE:
        return system.addPointOnCircle(
            point_handles[c.a], circular_handles[c.b], _GROUP_SKETCH)

    if c.type in C.LINE_LINE_TYPES:
        la, lb = line_handles[c.a], line_handles[c.b]
        if c.type == C.PARALLEL:
            return system.addParallel(la, lb, workplane, _GROUP_SKETCH)
        if c.type == C.PERPENDICULAR:
            return system.addPerpendicular(la, lb, workplane, _GROUP_SKETCH)
        if c.type == C.EQUAL_LENGTH:
            return system.addEqualLength(la, lb, workplane, _GROUP_SKETCH)
        # ANGLE: gradi, senza flag supplementare
        return system.addAngle(c.value, False, la, lb, workplane, _GROUP_SKETCH)

    line = model.lines[c.a]
    pa, pb = point_handles[line.a], point_handles[line.b]
    if c.type == C.HORIZONTAL:
        return system.addPointsHorizontal(pa, pb, workplane, _GROUP_SKETCH)
    if c.type == C.VERTICAL:
        return system.addPointsVertical(pa, pb, workplane, _GROUP_SKETCH)
    if c.type == C.DISTANCE:
        return system.addPointsDistance(c.value, pa, pb, workplane, _GROUP_SKETCH)
    raise ValueError(f"Tipo vincolo sconosciuto: {c.type}")
