"""Picking screen-space delle entità sketch e proiezione mouse → piano."""

import math
from dataclasses import dataclass

from bpy_extras import view3d_utils
from mathutils import Vector
from mathutils.geometry import intersect_line_plane

from .core import dims, geom
from .core import snap as snap_core

GRID_STEP = 0.1  # passo della griglia (snap con Ctrl), in unità modello


def mouse_to_plane(context, event, obj):
    """Proietta il mouse sul piano XY locale dello sketch → (u, v) o None."""
    region = context.region
    rv3d = context.region_data
    coord = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

    mw = obj.matrix_world
    plane_co = mw.translation
    plane_no = mw.col[2].to_3d().normalized()
    hit = intersect_line_plane(origin, origin + direction, plane_co, plane_no)
    if hit is None or (hit - origin).dot(direction) <= 0.0:
        return None  # vista parallela al piano, o piano dietro la camera
    local = mw.inverted() @ hit
    return (local.x, local.y)


def point_under_mouse(context, event, obj, model, max_px=14.0, exclude=None):
    """Id del punto del modello entro max_px pixel dal mouse, o None.

    exclude: insieme opzionale di id punto da ignorare.
    """
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for p in model.points.values():
        if exclude is not None and p.id in exclude:
            continue
        world = mw @ Vector((p.u, p.v, 0.0))
        screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
        if screen is None:
            continue
        d = (screen - mouse).length
        if d < best_d:
            best = p.id
            best_d = d
    return best


def line_under_mouse(context, event, obj, model, max_px=10.0, exclude=None):
    """Id della linea del modello entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for line in model.lines.values():
        if exclude is not None and line.id in exclude:
            continue
        pa = model.points.get(line.a)
        pb = model.points.get(line.b)
        if pa is None or pb is None:
            continue
        sa = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((pa.u, pa.v, 0.0)))
        sb = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((pb.u, pb.v, 0.0)))
        if sa is None or sb is None:
            continue
        d = _dist_point_segment(mouse, sa, sb)
        if d < best_d:
            best = line.id
            best_d = d
    return best


def midpoint_under_mouse(context, event, obj, model, max_px=10.0, exclude=None):
    """(line_id, (u, v)) del midpoint di linea entro max_px dal mouse, o None.

    exclude: insieme opzionale di id linea da ignorare.
    """
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for line in model.lines.values():
        if exclude is not None and line.id in exclude:
            continue
        pa = model.points.get(line.a)
        pb = model.points.get(line.b)
        if pa is None or pb is None:
            continue
        mid = ((pa.u + pb.u) / 2, (pa.v + pb.v) / 2)
        screen = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((mid[0], mid[1], 0.0)))
        if screen is None:
            continue
        d = (screen - mouse).length
        if d < best_d:
            best = (line.id, mid)
            best_d = d
    return best


def line_projection_under_mouse(context, event, obj, model, max_px=10.0,
                                exclude=None):
    """(line_id, (u, v)) della proiezione del mouse sulla linea più vicina.

    La proiezione è clampata al segmento; None se nessuna linea è
    entro max_px pixel.
    """
    line_id = line_under_mouse(context, event, obj, model, max_px, exclude)
    if line_id is None:
        return None
    co = mouse_to_plane(context, event, obj)
    if co is None:
        return None
    line = model.lines[line_id]
    pa = model.points[line.a]
    pb = model.points[line.b]
    dx, dy = pb.u - pa.u, pb.v - pa.v
    length2 = dx * dx + dy * dy
    if length2 < 1e-18:
        return None
    t = ((co[0] - pa.u) * dx + (co[1] - pa.v) * dy) / length2
    t = min(max(t, 0.0), 1.0)
    return line_id, (pa.u + dx * t, pa.v + dy * t)


def circular_under_mouse(context, event, obj, model, max_px=10.0, exclude=None):
    """Id del cerchio o arco entro max_px pixel dal mouse, o None."""
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world

    def polyline_distance(pts2d, closed):
        screen_pts = []
        for u, v in pts2d:
            s = view3d_utils.location_3d_to_region_2d(
                region, rv3d, mw @ Vector((u, v, 0.0)))
            if s is None:
                return None
            screen_pts.append(s)
        if closed:
            screen_pts.append(screen_pts[0])
        return min(_dist_point_segment(mouse, a, b)
                   for a, b in zip(screen_pts, screen_pts[1:]))

    best = None
    best_d = max_px
    for circle in model.circles.values():
        if exclude is not None and circle.id in exclude:
            continue
        center = model.points.get(circle.center)
        if center is None or circle.radius < 1e-9:
            continue
        d = polyline_distance(
            geom.circle_points((center.u, center.v), circle.radius, 32), True)
        if d is not None and d < best_d:
            best, best_d = circle.id, d
    for arc in model.arcs.values():
        if exclude is not None and arc.id in exclude:
            continue
        center = model.points.get(arc.center)
        start = model.points.get(arc.start)
        end = model.points.get(arc.end)
        if center is None or start is None or end is None:
            continue
        d = polyline_distance(
            geom.arc_points((center.u, center.v), (start.u, start.v),
                            (end.u, end.v)), False)
        if d is not None and d < best_d:
            best, best_d = arc.id, d
    return best


@dataclass
class SnapResult:
    co: tuple[float, float]
    kind: str | None              # tipo di snap (core.snap) o None = libero
    point_id: int | None = None   # per POINT: il punto esistente agganciato
    targets: list | None = None   # entità per i vincoli automatici


_MODEL_PRIORITY = {snap_core.INTERSECTION: 0, snap_core.MID: 1,
                   snap_core.ARC_MID: 1, snap_core.QUADRANT: 1}


def snap_position(context, event, obj, model, *, max_px=12.0,
                  exclude_points=None, exclude_entities=None,
                  grid=False, grid_step=GRID_STEP):
    """Posizione agganciata sotto il mouse con priorità CAD.

    None se il mouse non interseca il piano dello sketch. Priorità:
    punto esistente → intersezione → punto medio/quadrante/metà arco →
    proiezione su linea/cerchio → griglia (se grid) → posizione libera.
    """
    co = mouse_to_plane(context, event, obj)
    if co is None:
        return None

    pid = point_under_mouse(context, event, obj, model, max_px,
                            exclude=exclude_points)
    if pid is not None:
        p = model.points[pid]
        return SnapResult((p.u, p.v), snap_core.POINT, point_id=pid)

    # candidati del modello (intersezioni, midpoint, quadranti…)
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_key = None
    threshold = max_px * 0.85
    for cand in snap_core.candidates(model, exclude=exclude_entities):
        screen = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((cand.co[0], cand.co[1], 0.0)))
        if screen is None:
            continue
        d = (screen - mouse).length
        if d >= threshold:
            continue
        key = (_MODEL_PRIORITY.get(cand.kind, 2), d)
        if best_key is None or key < best_key:
            best, best_key = cand, key
    if best is not None:
        return SnapResult(best.co, best.kind, targets=best.targets)

    hit = line_projection_under_mouse(context, event, obj, model,
                                      max_px * 0.75, exclude=exclude_entities)
    if hit is not None:
        line_id, projection = hit
        return SnapResult(projection, snap_core.EDGE,
                          targets=[('LINE', line_id)])

    cid = circular_under_mouse(context, event, obj, model, max_px * 0.75,
                               exclude=exclude_entities)
    if cid is not None:
        if cid in model.circles:
            circle = model.circles[cid]
            center = model.points[circle.center]
            radius = circle.radius
            entity_kind = 'CIRCLE'
        else:
            arc = model.arcs[cid]
            center = model.points[arc.center]
            start = model.points[arc.start]
            radius = math.hypot(start.u - center.u, start.v - center.v)
            entity_kind = 'ARC'
        dx, dy = co[0] - center.u, co[1] - center.v
        dist = math.hypot(dx, dy)
        if dist > 1e-9 and radius > 1e-9:
            projection = (center.u + dx / dist * radius,
                          center.v + dy / dist * radius)
            return SnapResult(projection, snap_core.ON_CIRCLE,
                              targets=[(entity_kind, cid)])

    if grid:
        return SnapResult(
            (round(co[0] / grid_step) * grid_step,
             round(co[1] / grid_step) * grid_step),
            snap_core.GRID)

    return SnapResult(co, None)


def dimension_under_mouse(context, event, obj, model, max_px=18.0, types=None):
    """Id del vincolo la cui quota (testo) è entro max_px dal mouse, o None.

    types: insieme opzionale di tipi di vincolo ammessi.
    """
    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    best_d = max_px
    for cid, layout in dims.iter_layouts(model):
        if types is not None and model.constraints[cid].type not in types:
            continue
        world = mw @ Vector((layout.text_pos[0], layout.text_pos[1], 0.0))
        screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
        if screen is None:
            continue
        d = (screen - mouse).length
        if d < best_d:
            best = cid
            best_d = d
    return best


def _dist_point_segment(p, a, b):
    ab = b - a
    if ab.length_squared == 0.0:
        return (p - a).length
    t = max(0.0, min(1.0, (p - a).dot(ab) / ab.length_squared))
    return (p - (a + ab * t)).length


@dataclass
class SnapResult:
    co: tuple[float, float]   # posizione finale nel piano dello sketch
    kind: str | None          # tipo di snap (core.snap) o None = libero
    point_id: int | None      # punto esistente agganciato (kind == POINT)
    targets: list | None      # entità per i vincoli automatici


# priorità: il tipo conta più della distanza (stile OSNAP)
_CANDIDATE_PRIORITY = {
    snap_core.INTERSECTION: 0,
    snap_core.MID: 1,
    snap_core.ARC_MID: 1,
    snap_core.QUADRANT: 1,
}


def snap_position(context, event, obj, model, *, max_px=12.0,
                  exclude_points=None, exclude_entities=None,
                  grid=False, grid_step=GRID_STEP):
    """Posizione agganciata sotto il mouse, con priorità CAD.

    Priorità: punto esistente → intersezione → midpoint/quadrante/metà
    arco → proiezione su linea/cerchio → griglia (se grid). Ritorna None
    se il mouse non interseca il piano dello sketch.
    """
    co = mouse_to_plane(context, event, obj)
    if co is None:
        return None

    pid = point_under_mouse(context, event, obj, model, max_px,
                            exclude=exclude_points)
    if pid is not None:
        p = model.points[pid]
        return SnapResult((p.u, p.v), snap_core.POINT, pid, None)

    region = context.region
    rv3d = context.region_data
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    mw = obj.matrix_world
    best = None
    threshold = max_px * 0.85
    for cand in snap_core.candidates(model, exclude=exclude_entities):
        screen = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((cand.co[0], cand.co[1], 0.0)))
        if screen is None:
            continue
        d = (screen - mouse).length
        if d >= threshold:
            continue
        key = (_CANDIDATE_PRIORITY.get(cand.kind, 2), d)
        if best is None or key < best[0]:
            best = (key, cand)
    if best is not None:
        cand = best[1]
        return SnapResult(cand.co, cand.kind, None, cand.targets)

    hit = line_projection_under_mouse(context, event, obj, model,
                                      max_px * 0.75, exclude=exclude_entities)
    if hit is not None:
        line_id, proj = hit
        return SnapResult(proj, snap_core.EDGE, None, [('LINE', line_id)])

    circ_id = circular_under_mouse(context, event, obj, model, max_px * 0.75,
                                   exclude=exclude_entities)
    if circ_id is not None:
        if circ_id in model.circles:
            circle = model.circles[circ_id]
            center = model.points[circle.center]
            radius = circle.radius
            entity = ('CIRCLE', circ_id)
        else:
            arc = model.arcs[circ_id]
            center = model.points[arc.center]
            start = model.points[arc.start]
            radius = math.hypot(start.u - center.u, start.v - center.v)
            entity = ('ARC', circ_id)
        dx, dy = co[0] - center.u, co[1] - center.v
        dist = math.hypot(dx, dy)
        if dist > 1e-9 and radius > 1e-9:
            proj = (center.u + dx / dist * radius, center.v + dy / dist * radius)
            return SnapResult(proj, snap_core.ON_CIRCLE, None, [entity])

    if grid:
        snapped = (round(co[0] / grid_step) * grid_step,
                   round(co[1] / grid_step) * grid_step)
        return SnapResult(snapped, snap_core.GRID, None, None)

    return SnapResult(co, None, None, None)
