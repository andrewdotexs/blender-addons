"""Disegno overlay degli sketch nella viewport 3D (modulo gpu).

Gli sketch non hanno geometria mesh visibile (Slice 1): tutto ciò che si
vede in viewport passa da qui. Per ora i batch vengono ricostruiti a ogni
redraw — con le quantità di entità di uno sketch è irrilevante; la cache
con dirty flag arriverà quando servirà.
"""

import math

import blf
import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from . import props
from .core import constraints as C
from .core import dims, geom

COL_LINE_ACTIVE = (0.92, 0.92, 0.92, 1.0)
COL_LINE_OTHER = (0.55, 0.55, 0.55, 0.5)
COL_POINT = (0.85, 0.85, 0.88, 1.0)
COL_SELECTED = (1.0, 0.55, 0.12, 1.0)
COL_RUBBER = (0.35, 0.7, 1.0, 0.9)
COL_SNAP = (0.3, 1.0, 0.45, 1.0)
COL_LABEL = (1.0, 0.62, 0.1, 1.0)
COL_DIM = (0.45, 0.75, 1.0, 0.95)  # quote: linee e testo
FONT_SIZE = 16.0  # dimensione del testo di quote e glifi vincolo

# glifi ASCII-safe (niente simboli unicode: dipendono dal font UI)
_CONSTRAINT_GLYPHS = {
    C.HORIZONTAL: "H",
    C.VERTICAL: "V",
    C.PARALLEL: "//",
    C.PERPENDICULAR: "90°",
    C.EQUAL_LENGTH: "=",
}

_handle = None
_handle_labels = None


def draw_lines(coords, color, width=2.0):
    """Disegna segmenti (coppie di Vector world) con spessore in pixel."""
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    shader.uniform_float("lineWidth", width)
    shader.uniform_float("color", color)
    batch.draw(shader)


def draw_points(coords, color, size=6.0):
    """Disegna punti (Vector world) con dimensione in pixel."""
    gpu.state.point_size_set(size)
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_sketches():
    context = bpy.context
    sketches = [o for o in context.visible_objects if o.sketch_cad.is_sketch]
    if not sketches:
        return

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')  # lo sketch resta visibile attraverso le mesh

    active = context.active_object
    for obj in sketches:
        data = obj.sketch_cad
        mw = obj.matrix_world
        is_active = obj == active
        local_points = {p.id: (p.co[0], p.co[1]) for p in data.points}
        world_points = {pid: mw @ Vector((u, v, 0.0))
                        for pid, (u, v) in local_points.items()}

        line_coords = []
        line_coords_selected = []

        def add_polyline(pts2d, selected, closed=False):
            target = line_coords_selected if (is_active and selected) else line_coords
            n = len(pts2d)
            last = n if closed else n - 1
            for i in range(last):
                pa, pb = pts2d[i], pts2d[(i + 1) % n]
                target.append(mw @ Vector((pa[0], pa[1], 0.0)))
                target.append(mw @ Vector((pb[0], pb[1], 0.0)))

        for line in data.lines:
            a = world_points.get(line.a)
            b = world_points.get(line.b)
            if a is None or b is None:
                continue
            target = line_coords_selected if (is_active and line.selected) else line_coords
            target += [a, b]

        for circle in data.circles:
            center = local_points.get(circle.center)
            if center is None or circle.radius < 1e-9:
                continue
            add_polyline(geom.circle_points(center, circle.radius, 48),
                         circle.selected, closed=True)

        for arc in data.arcs:
            center = local_points.get(arc.center)
            start = local_points.get(arc.start)
            end = local_points.get(arc.end)
            if center is None or start is None or end is None:
                continue
            add_polyline(geom.arc_points(center, start, end), arc.selected)

        if line_coords:
            draw_lines(line_coords, COL_LINE_ACTIVE if is_active else COL_LINE_OTHER, 2.0)
        if line_coords_selected:
            draw_lines(line_coords_selected, COL_SELECTED, 3.0)

        if is_active and world_points:
            normal_pts = [world_points[p.id] for p in data.points if not p.selected]
            selected_pts = [world_points[p.id] for p in data.points if p.selected]
            if normal_pts:
                draw_points(normal_pts, COL_POINT, 6.0)
            if selected_pts:
                draw_points(selected_pts, COL_SELECTED, 9.0)

        # linee di quota (estensioni, misura, tacchette, archi)
        if is_active and any(c.type in dims.DIMENSIONED_TYPES
                             for c in data.constraints):
            model = props.load_model(obj)
            dim_coords = []
            for _cid, layout in dims.iter_layouts(model):
                for start, end in layout.segments:
                    dim_coords.append(mw @ Vector((start[0], start[1], 0.0)))
                    dim_coords.append(mw @ Vector((end[0], end[1], 0.0)))
            if dim_coords:
                draw_lines(dim_coords, COL_DIM, 1.5)

    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.blend_set('NONE')


def _draw_constraint_labels():
    """Glifi dei vincoli (H/V, valore distanza) al midpoint della linea."""
    context = bpy.context
    obj = context.active_object
    if obj is None or not obj.sketch_cad.is_sketch:
        return
    data = obj.sketch_cad
    if not data.constraints:
        return
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return

    mw = obj.matrix_world
    points = {p.id: (p.co[0], p.co[1]) for p in data.points}
    lines = {l.id: (l.a, l.b) for l in data.lines}

    font = 0
    blf.size(font, FONT_SIZE)
    blf.color(font, *COL_LABEL)
    stacked: dict[int, int] = {}  # più vincoli sulla stessa linea: impila i glifi
    for c in data.constraints:
        if c.type in (C.DISTANCE, C.ANGLE):
            continue  # disegnati come quote complete più sotto
        glyph = _CONSTRAINT_GLYPHS.get(c.type)
        if glyph is None:
            continue  # COINCIDENT: nessun glifo
        # i vincoli a due linee mostrano il glifo su entrambe
        targets = (c.a, c.b) if c.type in C.LINE_LINE_TYPES else (c.a,)
        for line_id in targets:
            endpoints = lines.get(line_id)
            if endpoints is None:
                continue
            pa = points.get(endpoints[0])
            pb = points.get(endpoints[1])
            if pa is None or pb is None:
                continue
            mid = mw @ Vector(((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, 0.0))
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, mid)
            if screen is None:
                continue
            offset = stacked.get(line_id, 0)
            stacked[line_id] = offset + 1
            blf.position(font, screen.x + 7, screen.y + 7 + offset * 16, 0)
            blf.draw(font, glyph)

    _draw_dimension_texts(obj, region, rv3d, font)


def _draw_dimension_texts(obj, region, rv3d, font):
    """Testo delle quote: allineato alla linea di misura, mai capovolto."""
    data = obj.sketch_cad
    if not any(c.type in dims.DIMENSIONED_TYPES for c in data.constraints):
        return
    mw = obj.matrix_world
    model = props.load_model(obj)
    blf.color(font, *COL_DIM)
    for _cid, layout in dims.iter_layouts(model):
        tx, ty = layout.text_pos
        screen = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((tx, ty, 0.0)))
        if screen is None:
            continue
        width, height = blf.dimensions(font, layout.text)

        if layout.text_dir is None:
            blf.position(font, screen.x - width / 2, screen.y - height / 2, 0)
            blf.draw(font, layout.text)
            continue

        # angolo del testo in screen space, dalla proiezione della direzione
        du, dv = layout.text_dir
        screen2 = view3d_utils.location_3d_to_region_2d(
            region, rv3d, mw @ Vector((tx + du * 0.05, ty + dv * 0.05, 0.0)))
        angle = 0.0
        if screen2 is not None and (screen2 - screen).length > 0.5:
            angle = math.atan2(screen2.y - screen.y, screen2.x - screen.x)
            if angle > math.pi / 2:
                angle -= math.pi
            elif angle <= -math.pi / 2:
                angle += math.pi
        cos_a, sin_a = math.cos(angle), math.sin(angle)
        blf.enable(font, blf.ROTATION)
        blf.rotation(font, angle)
        # centrato lungo la quota, 5 px sopra la linea di misura
        blf.position(font,
                     screen.x - cos_a * width / 2 - sin_a * 5,
                     screen.y - sin_a * width / 2 + cos_a * 5, 0)
        blf.draw(font, layout.text)
        blf.disable(font, blf.ROTATION)


def register():
    global _handle, _handle_labels
    if bpy.app.background:
        return  # niente viewport in headless: lasciare gli handler spenti
    _handle = bpy.types.SpaceView3D.draw_handler_add(
        _draw_sketches, (), 'WINDOW', 'POST_VIEW')
    _handle_labels = bpy.types.SpaceView3D.draw_handler_add(
        _draw_constraint_labels, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    global _handle, _handle_labels
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, 'WINDOW')
        _handle = None
    if _handle_labels is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle_labels, 'WINDOW')
        _handle_labels = None
