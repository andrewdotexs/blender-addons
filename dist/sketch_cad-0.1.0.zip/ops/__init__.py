"""Operatori di Sketch CAD."""

from . import draw, sketch

_modules = (
    sketch,
    draw,
)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
