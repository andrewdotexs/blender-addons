"""Pannelli e menu di Sketch CAD."""

import bpy


class SKETCHCAD_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sketch"
    bl_label = "Sketch CAD"

    def draw(self, context):
        layout = self.layout
        layout.operator("sketch_cad.new_sketch", icon='ADD')

        obj = context.active_object
        if obj is None or not obj.sketch_cad.is_sketch:
            layout.label(text="Nessuno sketch attivo", icon='INFO')
            return

        data = obj.sketch_cad
        box = layout.box()
        box.label(text=obj.name, icon='GREASEPENCIL')
        box.label(text=f"{len(data.points)} punti, {len(data.lines)} linee")
        box.operator("sketch_cad.draw_line", icon='IPO_LINEAR')


_classes = (
    SKETCHCAD_PT_main,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
