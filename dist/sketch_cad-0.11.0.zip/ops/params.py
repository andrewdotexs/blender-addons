"""Gestione dei parametri di scena (tabella nome → valore)."""

import bpy

from .. import props


def _sketches(scene):
    return [obj for obj in scene.objects if obj.sketch_cad.is_sketch]


class SKETCHCAD_OT_add_param(bpy.types.Operator):
    bl_idname = "sketch_cad.add_param"
    bl_label = "Aggiungi parametro"
    bl_description = "Aggiunge un parametro di scena utilizzabile dalle quote"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        params = context.scene.sketch_cad_params
        existing = {p.name for p in params}
        n = 1
        while f"param{n}" in existing:
            n += 1
        item = params.add()
        item.name = f"param{n}"
        item.value = 1.0
        return {'FINISHED'}


class SKETCHCAD_OT_remove_param(bpy.types.Operator):
    bl_idname = "sketch_cad.remove_param"
    bl_label = "Rimuovi parametro"
    bl_description = (
        "Rimuove il parametro; le quote legate tornano a valore fisso "
        "(la geometria non cambia)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    param_name: bpy.props.StringProperty(options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        params = scene.sketch_cad_params
        index = next((i for i, p in enumerate(params)
                      if p.name == self.param_name), None)
        if index is None:
            return {'CANCELLED'}

        unbound = 0
        for obj in _sketches(scene):
            model = props.load_model(obj)
            count = model.unbind_parameter(self.param_name)
            if count:
                props.save_model(model, obj)
                unbound += count
        params.remove(index)

        if unbound:
            self.report({'INFO'},
                        f"Parametro rimosso: {unbound} quote tornate a valore fisso")
        return {'FINISHED'}


class SKETCHCAD_OT_rename_param(bpy.types.Operator):
    bl_idname = "sketch_cad.rename_param"
    bl_label = "Rinomina parametro"
    bl_description = "Rinomina il parametro aggiornando tutte le quote legate"
    bl_options = {'REGISTER', 'UNDO'}

    old_name: bpy.props.StringProperty(options={'HIDDEN'})
    new_name: bpy.props.StringProperty(name="Nuovo nome")

    def invoke(self, context, event):
        self.new_name = self.old_name
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        new = self.new_name.strip()
        if not new.isidentifier():
            self.report({'ERROR'},
                        "Nome non valido: lettere, numeri e _ senza spazi "
                        "(servirà per le espressioni)")
            return {'CANCELLED'}
        if new == self.old_name:
            return {'CANCELLED'}
        if any(p.name == new for p in scene.sketch_cad_params):
            self.report({'ERROR'}, f"Esiste già un parametro '{new}'")
            return {'CANCELLED'}
        target = next((p for p in scene.sketch_cad_params
                       if p.name == self.old_name), None)
        if target is None:
            return {'CANCELLED'}

        target.name = new
        for obj in _sketches(scene):
            model = props.load_model(obj)
            if model.rename_parameter(self.old_name, new):
                props.save_model(model, obj)
        return {'FINISHED'}


_classes = (
    SKETCHCAD_OT_add_param,
    SKETCHCAD_OT_remove_param,
    SKETCHCAD_OT_rename_param,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
